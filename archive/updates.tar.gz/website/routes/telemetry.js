const express = require('express');
const router = express.Router();
const axios = require('axios');

// Middleware to check if user is authenticated
function requireAuth(req, res, next) {
    if (req.session && req.session.userId) {
        next();
    } else {
        res.status(401).send('Unauthorized');
    }
}

// Telemetry dashboard page (requires auth)
router.get('/dashboard', requireAuth, async (req, res) => {
    try {
        const response = await axios.get('http://localhost:3000/dashboard');
        res.send(response.data);
    } catch (error) {
        console.error('Telemetry proxy error:', error.message);
        res.status(500).send(`
            <html>
                <head>
                    <title>Telemetry Error</title>
                    <style>
                        body { font-family: system-ui; background: #1a1a2e; color: #e0e0e0; padding: 40px; text-align: center; }
                        .error { background: rgba(231, 76, 60, 0.2); border: 1px solid #e74c3c; padding: 20px; border-radius: 8px; max-width: 600px; margin: 0 auto; }
                    </style>
                </head>
                <body>
                    <div class="error">
                        <h2>❌ Telemetry Server Error</h2>
                        <p>Cannot connect to telemetry server on port 3000</p>
                        <p><strong>Error:</strong> ${error.message}</p>
                        <p><a href="/admin/dashboard.html" style="color: #3498db;">← Back to Admin</a></p>
                    </div>
                </body>
            </html>
        `);
    }
});

// Proxy API requests to telemetry server
router.use('/api', requireAuth, async (req, res) => {
    try {
        const url = `http://localhost:3000${req.originalUrl.replace('/telemetry', '')}`;
        const response = await axios({
            method: req.method,
            url,
            data: req.body,
            headers: {
                'Content-Type': 'application/json'
            }
        });
        res.json(response.data);
    } catch (error) {
        console.error('Telemetry API proxy error:', error.message);
        res.status(error.response?.status || 500).json({ 
            error: 'Telemetry API error',
            message: error.message 
        });
    }
});

module.exports = router;

