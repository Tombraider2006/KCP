/**
 * Сервер телеметрии - принимает и хранит статистику приложений
 * Установка: npm install express sqlite3 express-rate-limit basic-auth
 */

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const http = require('http');

const app = express();
app.set('trust proxy', 1); // Fix for X-Forwarded-For when behind reverse proxy (Traefik)
const PORT = process.env.PORT || 3000;

// Кэш IP → Country для минимизации запросов к GeoIP API
const ipCountryCache = new Map();

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.static('public'));

// Rate limiting для API
const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 минут
    max: 100 // максимум 100 запросов
});

// База данных SQLite
const dbPath = path.join(__dirname, 'telemetry.db');
const db = new sqlite3.Database(dbPath);

// Создание таблиц
db.serialize(() => {
    // Таблица инсталляций
    db.run(`
        CREATE TABLE IF NOT EXISTS installations (
            id TEXT PRIMARY KEY,
            version TEXT,
            platform TEXT,
            arch TEXT,
            locale TEXT,
            country TEXT,
            ip_address TEXT,
            install_date INTEGER,
            first_seen INTEGER,
            last_seen INTEGER,
            sessions_total INTEGER DEFAULT 0,
            printers_current INTEGER DEFAULT 0,
            printers_max INTEGER DEFAULT 0,
            printers_klipper INTEGER DEFAULT 0,
            printers_bambu INTEGER DEFAULT 0,
            analytics_views INTEGER DEFAULT 0,
            exports_count INTEGER DEFAULT 0,
            current_theme TEXT DEFAULT 'dark',
            web_server_enabled INTEGER DEFAULT 0,
            total_uptime_seconds INTEGER DEFAULT 0
        )
    `);
    
    // Таблица событий удалена для оптимизации - все данные хранятся в installations
    
    // Таблица использования функций
    db.run(`
        CREATE TABLE IF NOT EXISTS feature_usage (
            installation_id TEXT,
            feature_name TEXT,
            usage_count INTEGER DEFAULT 0,
            last_used INTEGER,
            PRIMARY KEY(installation_id, feature_name),
            FOREIGN KEY(installation_id) REFERENCES installations(id)
        )
    `);
    
    // Миграция: добавляем поле locale если его нет
    db.run(`
        ALTER TABLE installations ADD COLUMN locale TEXT
    `, (err) => {
        if (err && !err.message.includes('duplicate column')) {
            console.error('Migration error:', err.message);
        }
    });
    
    // Миграция: добавляем поле country если его нет
    db.run(`
        ALTER TABLE installations ADD COLUMN country TEXT
    `, (err) => {
        if (err && !err.message.includes('duplicate column')) {
            console.error('Migration error:', err.message);
        }
    });
    
    // Миграция: добавляем поле ip_address если его нет
    db.run(`
        ALTER TABLE installations ADD COLUMN ip_address TEXT
    `, (err) => {
        if (err && !err.message.includes('duplicate column')) {
            console.error('Migration error:', err.message);
        }
    });
    
    // Миграция: добавляем поле current_theme если его нет
    db.run(`
        ALTER TABLE installations ADD COLUMN current_theme TEXT DEFAULT 'dark'
    `, (err) => {
        if (err && !err.message.includes('duplicate column')) {
            console.error('Migration error:', err.message);
        }
    });
    
    // Миграция: добавляем поле web_server_enabled если его нет
    db.run(`
        ALTER TABLE installations ADD COLUMN web_server_enabled INTEGER DEFAULT 0
    `, (err) => {
        if (err && !err.message.includes('duplicate column')) {
            console.error('Migration error:', err.message);
        }
    });
    
    // Миграция: добавляем поле total_uptime_seconds если его нет
    db.run(`
        ALTER TABLE installations ADD COLUMN total_uptime_seconds INTEGER DEFAULT 0
    `, (err) => {
        if (err && !err.message.includes('duplicate column')) {
            console.error('Migration error:', err.message);
        }
    });
    
    // Создаем индексы для ускорения запросов
    db.run(`CREATE INDEX IF NOT EXISTS idx_installations_last_seen ON installations(last_seen)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_installations_version ON installations(version)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_installations_platform ON installations(platform)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_installations_country ON installations(country)`);
    
    console.log('✅ Database initialized');
});

// ===== GEOIP ФУНКЦИОНАЛ =====

/**
 * Определение страны по IP через ip-api.com
 * @param {string} ip - IP адрес клиента
 * @returns {Promise<string|null>} - Код страны (RU, US, DE и т.д.) или null
 */
async function getCountryByIP(ip) {
    // Пропускаем локальные IP
    if (ip === '127.0.0.1' || ip === '::1' || ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.')) {
        return null;
    }
    
    // Проверяем кэш
    if (ipCountryCache.has(ip)) {
        return ipCountryCache.get(ip);
    }
    
    try {
        const response = await new Promise((resolve, reject) => {
            http.get(`http://ip-api.com/json/${ip}?fields=status,country,countryCode`, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => resolve(JSON.parse(data)));
            }).on('error', reject);
        });
        
        if (response.status === 'success' && response.countryCode) {
            const country = response.countryCode;
            ipCountryCache.set(ip, country);
            console.log(`[GeoIP] ${ip} → ${country} (${response.country})`);
            return country;
        }
    } catch (error) {
        console.error('[GeoIP] Error:', error.message);
    }
    
    return null;
}

// Auth removed - access only from admin panel (https://tomich.fun/admin)
// No authentication needed on telemetry itself

// ============================================================================
// API ENDPOINTS
// ============================================================================

/**
 * POST /api/telemetry - принять данные телеметрии
 */
app.post('/api/telemetry', apiLimiter, async (req, res) => {
    const data = req.body;
    
    // Валидация
    if (!data.id || !data.version || !data.metrics) {
        return res.status(400).json({ error: 'Invalid data' });
    }
    
    // Получаем IP клиента
    const clientIP = req.headers['x-forwarded-for']?.split(',')[0].trim() || 
                     req.headers['x-real-ip'] || 
                     req.connection.remoteAddress || 
                     req.socket.remoteAddress;
    
    console.log('[Telemetry] Received from:', data.id.substring(0, 8), 'version:', data.version, 'IP:', clientIP);
    
    const now = Date.now();
    
    // Определяем страну по IP (асинхронно, не блокируем ответ)
    let country = null;
    try {
        country = await getCountryByIP(clientIP);
    } catch (error) {
        console.error('[GeoIP] Failed to get country:', error.message);
    }
    
    // Обновляем или создаем запись инсталляции
    db.run(`
        INSERT INTO installations (
            id, version, platform, arch, locale, country, ip_address, install_date, first_seen, last_seen,
            sessions_total, printers_current, printers_max, 
            printers_klipper, printers_bambu, analytics_views, exports_count,
            current_theme, web_server_enabled, total_uptime_seconds
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            version = excluded.version,
            platform = excluded.platform,
            arch = excluded.arch,
            locale = excluded.locale,
            country = COALESCE(excluded.country, country),
            ip_address = excluded.ip_address,
            last_seen = excluded.last_seen,
            sessions_total = excluded.sessions_total,
            printers_current = excluded.printers_current,
            printers_max = CASE WHEN excluded.printers_max > printers_max THEN excluded.printers_max ELSE printers_max END,
            printers_klipper = excluded.printers_klipper,
            printers_bambu = excluded.printers_bambu,
            analytics_views = excluded.analytics_views,
            exports_count = excluded.exports_count,
            current_theme = excluded.current_theme,
            web_server_enabled = excluded.web_server_enabled,
            total_uptime_seconds = total_uptime_seconds + excluded.total_uptime_seconds
    `, [
        data.id,
        data.version,
        data.platform,
        data.arch,
        data.locale || null,
        country,
        clientIP,
        data.installDate,
        now,
        now,
        data.metrics.sessions || 0,
        data.metrics.currentPrinters || 0,
        data.metrics.maxPrinters || 0,
        data.metrics.printersKlipper || 0,
        data.metrics.printersBambu || 0,
        data.metrics.analyticsViews || 0,
        data.metrics.exportsCount || 0,
        data.currentTheme || 'dark',
        data.webServerEnabled ? 1 : 0,
        data.metrics.sessionUptime || 0
    ], (err) => {
        if (err) {
            console.error('[DB] Error saving installation:', err);
        }
    });
    
    // События больше не сохраняются отдельно - вся информация в installations
    
    // Обновляем использование функций
    if (data.metrics.featureUsage) {
        const features = data.metrics.featureUsage;
        for (const [featureName, count] of Object.entries(features)) {
            db.run(`
                INSERT INTO feature_usage (installation_id, feature_name, usage_count, last_used)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(installation_id, feature_name) DO UPDATE SET
                    usage_count = excluded.usage_count,
                    last_used = excluded.last_used
            `, [data.id, featureName, count, now]);
        }
    }
    
    res.json({ success: true, message: 'Telemetry received' });
});

/**
 * GET /api/stats - получить общую статистику (для веб-панели)
 */
app.get('/api/stats', (req, res) => {
    const stats = {};
    
    // Общее количество инсталляций
    db.get('SELECT COUNT(*) as total FROM installations', (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        stats.totalInstallations = row.total;
        
        // Активные за последние 7 дней
        const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
        db.get('SELECT COUNT(*) as active FROM installations WHERE last_seen > ?', [weekAgo], (err, row) => {
            stats.activeInstallations = row.active;
            
            // Средние значения
            db.get(`
                SELECT 
                    AVG(printers_current) as avg_printers,
                    AVG(printers_max) as avg_max_printers,
                    SUM(printers_klipper) as total_klipper,
                    SUM(printers_bambu) as total_bambu,
                    AVG(sessions_total) as avg_sessions,
                    SUM(analytics_views) as total_analytics_views,
                    SUM(exports_count) as total_exports,
                    SUM(CASE WHEN current_theme = 'light' THEN 1 ELSE 0 END) as light_theme_users,
                    SUM(CASE WHEN current_theme = 'dark' THEN 1 ELSE 0 END) as dark_theme_users,
                    SUM(CASE WHEN web_server_enabled = 1 THEN 1 ELSE 0 END) as web_server_users,
                    AVG(total_uptime_seconds) as avg_uptime_seconds
                FROM installations
            `, (err, row) => {
                stats.avgPrinters = Math.round(row.avg_printers * 10) / 10;
                stats.avgMaxPrinters = Math.round(row.avg_max_printers * 10) / 10;
                stats.totalKlipper = row.total_klipper;
                stats.totalBambu = row.total_bambu;
                stats.avgSessions = Math.round(row.avg_sessions);
                stats.totalAnalyticsViews = row.total_analytics_views;
                stats.totalExports = row.total_exports;
                stats.lightThemeUsers = row.light_theme_users || 0;
                stats.darkThemeUsers = row.dark_theme_users || 0;
                stats.webServerUsers = row.web_server_users || 0;
                stats.avgUptimeHours = Math.round((row.avg_uptime_seconds || 0) / 3600 * 10) / 10;
                
                // Распределение по версиям
                db.all('SELECT version, COUNT(*) as count FROM installations GROUP BY version ORDER BY count DESC', (err, rows) => {
                    stats.versionDistribution = rows;
                    
                    // Распределение по платформам
                    db.all('SELECT platform, COUNT(*) as count FROM installations GROUP BY platform', (err, rows) => {
                        stats.platformDistribution = rows;
                        
                        // Распределение по локалям/странам
                        db.all('SELECT locale, COUNT(*) as count FROM installations WHERE locale IS NOT NULL GROUP BY locale ORDER BY count DESC', (err, rows) => {
                            stats.localeDistribution = rows;
                            
                            // Распределение по странам (GeoIP)
                            db.all('SELECT country, COUNT(*) as count FROM installations WHERE country IS NOT NULL GROUP BY country ORDER BY count DESC', (err, rows) => {
                                stats.countryDistribution = rows;
                                
                                // Топ функций
                                db.all(`
                                    SELECT feature_name, SUM(usage_count) as total_usage
                                    FROM feature_usage
                                    GROUP BY feature_name
                                    ORDER BY total_usage DESC
                                    LIMIT 20
                                `, (err, rows) => {
                                    stats.topFeatures = rows;
                                    
                                    // Распределение по количеству принтеров
                                    db.all(`
                                        SELECT printers_current, COUNT(*) as count
                                        FROM installations
                                        WHERE printers_current > 0
                                        GROUP BY printers_current
                                        ORDER BY printers_current
                                    `, (err, rows) => {
                                        stats.printersDistribution = rows;
                                        
                                        res.json(stats);
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
});

/**
 * GET /api/installations - список всех инсталляций
 */
app.get('/api/installations', (req, res) => {
    db.all(`
        SELECT 
            id, version, platform, arch, locale, country, ip_address,
            datetime(install_date/1000, 'unixepoch') as install_date,
            datetime(first_seen/1000, 'unixepoch') as first_seen,
            datetime(last_seen/1000, 'unixepoch') as last_seen,
            sessions_total, printers_current, printers_max,
            printers_klipper, printers_bambu,
            analytics_views, exports_count
        FROM installations
        ORDER BY last_seen DESC
        LIMIT 1000
    `, (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// ============================================================================
// WEB INTERFACE
// ============================================================================

/**
 * GET / - API info (public)
 */
app.get('/', (req, res) => {
    res.json({
        name: '📊 3D Printer Control Panel - Telemetry API',
        version: '1.0.0',
        endpoints: {
            'POST /api/telemetry': 'Send telemetry data',
            'POST /api/session': 'Update session data',
            'GET /api/stats': 'Get statistics',
            'GET /api/installations': 'Get installations',
            'GET /dashboard': 'Web dashboard'
        },
        dashboard: 'https://tomich.fun/admin → Telemetry',
        note: 'API access on port 3000. Dashboard embedded in admin panel.'
    });
});

/**
 * GET /dashboard - Web dashboard (for embedding in admin panel)
 */
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Обработка ошибок
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`
    ┌─────────────────────────────────────────────┐
    │  📊 Telemetry Server                        │
    │                                             │
    │  🌐 Server:  http://localhost:${PORT}       │
    │  📡 API:     http://localhost:${PORT}/api   │
    │  📁 Database: ${dbPath}                     │
    │                                             │
    │  🔒 No auth - access from admin panel only  │
    │  🌐 https://tomich.fun/admin                │
    └─────────────────────────────────────────────┘
    `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, closing database...');
    db.close(() => {
        console.log('Database closed');
        process.exit(0);
    });
});


