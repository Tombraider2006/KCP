# WordPress Backup & Restore Guide

## 📋 Описание

Скрипты для создания полного бекапа WordPress (файлы + база данных) и быстрого отката на исходную версию.

## 📁 Файлы

- `wordpress-backup.sh` - создание бекапа на сервере
- `wordpress-restore.sh` - восстановление из бекапа

## 🚀 Использование

### Установка скриптов на сервере

```bash
# Подключение к серверу
ssh root@tomich.fun

# Создание директории для бекапов
mkdir -p /opt/wordpress-backups

# Копирование скриптов на сервер (из локальной машины)
scp server-backup/wordpress-backup.sh root@tomich.fun:/opt/
scp server-backup/wordpress-restore.sh root@tomich.fun:/opt/

# Делаем скрипты исполняемыми
ssh root@tomich.fun "chmod +x /opt/wordpress-backup.sh /opt/wordpress-restore.sh"
```

### Создание бекапа

```bash
# На сервере
ssh root@tomich.fun

# Запуск бекапа
/opt/wordpress-backup.sh
```

**Что создается:**

- `wp-content.tar.gz` - все файлы темы и плагинов
- `database.sql.gz` - дамп базы данных MySQL
- `wp-config.php` - конфигурация WordPress
- Финальный архив: `wordpress-backup_YYYYMMDD_HHMMSS.tar.gz`

**Расположение:** `/opt/wordpress-backups/`

**Автоочистка:** Старые бекапы (старше 30 дней) удаляются автоматически.

### Восстановление из бекапа

```bash
# На сервере
ssh root@tomich.fun

# Просмотр доступных бекапов
ls -lh /opt/wordpress-backups/wordpress-backup_*.tar.gz

# Восстановление (укажите имя файла)
/opt/wordpress-restore.sh wordpress-backup_20251103_120000.tar.gz

# Или с полным путем
/opt/wordpress-restore.sh /opt/wordpress-backups/wordpress-backup_20251103_120000.tar.gz
```

**Что восстанавливается:**

- ✅ Все файлы `wp-content/` (темы, плагины, загрузки)
- ✅ База данных MySQL
- ⚠️ `wp-config.php` копируется как `.backup` (требует ручной проверки)

**Важно:** Скрипт запрашивает подтверждение перед восстановлением (10 секунд для отмены).

## 🔄 Быстрый откат на исходную версию

### Вариант 1: Откат из последнего бекапа

```bash
ssh root@tomich.fun

# Найти последний бекап
LATEST_BACKUP=$(ls -t /opt/wordpress-backups/wordpress-backup_*.tar.gz | head -1)

# Восстановить
/opt/wordpress-restore.sh "${LATEST_BACKUP}"
```

### Вариант 2: Откат из конкретного бекапа

```bash
ssh root@tomich.fun

# Просмотр всех бекапов с датами
ls -lht /opt/wordpress-backups/wordpress-backup_*.tar.gz

# Восстановление конкретного бекапа
/opt/wordpress-restore.sh wordpress-backup_20251103_120000.tar.gz
```

### Вариант 3: Откат из локального бекапа (server-backup/wordpress-clean)

Если нужно восстановить из локальной версии в `server-backup/wordpress-clean`:

```bash
# На локальной машине - создаем архив
cd server-backup/wordpress-clean
tar -czf wordpress-clean-backup.tar.gz wp-content/

# Загружаем на сервер
scp wordpress-clean-backup.tar.gz root@tomich.fun:/tmp/

# На сервере - восстанавливаем вручную
ssh root@tomich.fun
docker cp /tmp/wordpress-clean-backup.tar.gz wordpress-wordpress-1:/tmp/
docker exec wordpress-wordpress-1 bash -c "cd /var/www/html && rm -rf wp-content && tar -xzf /tmp/wordpress-clean-backup.tar.gz && chown -R www-data:www-data wp-content"
docker restart wordpress-wordpress-1
```

## 📝 Ручные команды для отката

Если скрипт недоступен, можно выполнить вручную:

### 1. Восстановление файлов

```bash
# Распаковать архив
tar -xzf /opt/wordpress-backups/wordpress-backup_YYYYMMDD_HHMMSS.tar.gz -C /tmp/

# Скопировать wp-content в контейнер
docker cp /tmp/wordpress-backup_YYYYMMDD_HHMMSS/wp-content.tar.gz wordpress-wordpress-1:/tmp/
docker exec wordpress-wordpress-1 bash -c "cd /var/www/html && rm -rf wp-content && tar -xzf /tmp/wp-content-backup.tar.gz && chown -R www-data:www-data wp-content"

# Перезапустить контейнер
docker restart wordpress-wordpress-1
```

### 2. Восстановление базы данных

```bash
# Найти контейнер MySQL
DB_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i mysql | head -1)

# Получить параметры БД из wp-config
DB_NAME=$(docker exec wordpress-wordpress-1 grep -E "^define\s*\(\s*['\"]DB_NAME" /var/www/html/wp-config.php | sed "s/.*['\"]\([^'\"]*\)['\"].*/\1/")
DB_USER=$(docker exec wordpress-wordpress-1 grep -E "^define\s*\(\s*['\"]DB_USER" /var/www/html/wp-config.php | sed "s/.*['\"]\([^'\"]*\)['\"].*/\1/")
DB_PASS=$(docker exec wordpress-wordpress-1 grep -E "^define\s*\(\s*['\"]DB_PASSWORD" /var/www/html/wp-config.php | sed "s/.*['\"]\([^'\"]*\)['\"].*/\1/")

# Распаковать дамп
gunzip -c /tmp/wordpress-backup_YYYYMMDD_HHMMSS/database.sql.gz > /tmp/database.sql

# Восстановить БД
docker exec -e MYSQL_PWD=${DB_PASS} -i ${DB_CONTAINER} mysql -u${DB_USER} ${DB_NAME} < /tmp/database.sql
```

## ⚙️ Автоматизация (Cron)

Для автоматического создания бекапов ежедневно:

```bash
ssh root@tomich.fun

# Редактировать crontab
crontab -e

# Добавить строку (бекап каждый день в 3:00)
0 3 * * * /opt/wordpress-backup.sh >> /var/log/wordpress-backup.log 2>&1
```

## 🔍 Проверка бекапов

```bash
ssh root@tomich.fun

# Просмотр всех бекапов с размерами
ls -lht /opt/wordpress-backups/wordpress-backup_*.tar.gz

# Проверка содержимого бекапа (без распаковки)
tar -tzf /opt/wordpress-backups/wordpress-backup_YYYYMMDD_HHMMSS.tar.gz
```

## ⚠️ Важные замечания

1. **Перед восстановлением:** Всегда проверяйте, что контейнеры запущены

   ```bash
   docker ps | grep wordpress
   docker ps | grep mysql
   ```

2. **wp-config.php:** При восстановлении `wp-config.php` копируется как `.backup`. Проверьте, что параметры БД совпадают перед использованием.

3. **Права доступа:** После восстановления файлов права устанавливаются автоматически (`www-data:www-data`).

4. **Проверка сайта:** После отката проверьте сайт:
   - https://tomich.fun
   - https://tomich.fun/wp-admin

5. **База данных:** При восстановлении БД текущие данные **полностью заменяются**!

## 🆘 Проблемы и решения

### Ошибка: "WordPress container not found"

```bash
# Проверить имя контейнера
docker ps --format '{{.Names}}' | grep wordpress

# Запустить контейнер
docker start wordpress-wordpress-1
```

### Ошибка: "MySQL container not found"

```bash
# Найти контейнер БД
docker ps --format '{{.Names}}' | grep -i mysql
docker ps --format '{{.Names}}' | grep -i db

# Запустить контейнер
docker start <container-name>
```

### Ошибка прав доступа

```bash
# Исправить права вручную
docker exec wordpress-wordpress-1 chown -R www-data:www-data /var/www/html/wp-content
```

## 📚 Дополнительная информация

- Локальная копия WordPress темы: `server-backup/wordpress-clean/`
- Сервер: `root@tomich.fun`
- Путь WordPress на сервере: `/opt/wordpress/` (в Docker контейнере)
- Директория бекапов: `/opt/wordpress-backups/`
