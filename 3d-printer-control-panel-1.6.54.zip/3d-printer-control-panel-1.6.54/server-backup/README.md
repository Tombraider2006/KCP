# Server Backup

Этот каталог содержит бэкап серверных компонентов системы 3DCP.

## Структура

### 3dpc-telemetry-clean/

Серверная часть системы лицензирования и Telegram бота:

- `server.js` - основной сервер Express
- `bot-admin.html` - админка бота
- `package.json` - зависимости
- `ecosystem.config.js` - конфигурация PM2
- `nginx.conf` - конфигурация Nginx
- `docker-compose.yml` - конфигурация Docker

### wordpress-clean/

WordPress тема для сайта:

- `page-license.php` - страница лицензирования
- Другие файлы темы

## Скрипты бекапа WordPress

### wordpress-backup.sh

Скрипт для создания полного бекапа WordPress на сервере (файлы + база данных).

**Использование:**

```bash
# На сервере
ssh root@tomich.fun
/opt/wordpress-backup.sh
```

**Что создается:**

- `wp-content.tar.gz` - все файлы темы и плагинов
- `database.sql.gz` - дамп базы данных MySQL
- `wp-config.php` - конфигурация WordPress
- Финальный архив: `wordpress-backup_YYYYMMDD_HHMMSS.tar.gz`

**Расположение бекапов:** `/opt/wordpress-backups/`

### wordpress-restore.sh

Скрипт для восстановления WordPress из бекапа.

**Использование:**

```bash
# На сервере
ssh root@tomich.fun

# Просмотр доступных бекапов
ls -lh /opt/wordpress-backups/wordpress-backup_*.tar.gz

# Восстановление
/opt/wordpress-restore.sh wordpress-backup_20251103_120000.tar.gz
```

**Подробная инструкция:** См. `WORDPRESS_BACKUP_GUIDE.md`

## Архивы

- `3dpc-telemetry-clean.tar.gz` - архив серверной части (без node_modules)
- `wordpress-backup.tar.gz` - архив WordPress темы

## Восстановление

Для восстановления на сервере:

```bash
# Восстановление 3dpc-telemetry
cd /opt
tar -xzf 3dpc-telemetry-clean.tar.gz

# Восстановление WordPress (новый способ - через скрипт)
ssh root@tomich.fun
/opt/wordpress-restore.sh wordpress-backup_YYYYMMDD_HHMMSS.tar.gz
```

## Примечания

- node_modules исключены из бэкапа для экономии места
- После восстановления нужно выполнить `yarn install` в папке 3dpc-telemetry
- PM2 процессы нужно перезапустить после восстановления
- Бекапы WordPress хранятся на сервере в `/opt/wordpress-backups/`
- Старые бекапы WordPress (старше 30 дней) удаляются автоматически
