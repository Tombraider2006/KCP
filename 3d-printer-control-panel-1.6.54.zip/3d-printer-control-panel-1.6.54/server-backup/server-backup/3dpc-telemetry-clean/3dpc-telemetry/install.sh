#!/bin/bash
# Автоматическая установка Telemetry Server
# Использование: sudo bash install.sh

set -e  # Остановка при ошибке

echo "================================================"
echo "  📊 3D Printer Control Panel - Telemetry Server"
echo "  Автоматическая установка"
echo "================================================"
echo ""

# Проверка прав root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Запустите скрипт с sudo: sudo bash install.sh"
    exit 1
fi

# Конфигурация
read -p "Введите домен (или нажмите Enter для localhost): " DOMAIN
DOMAIN=${DOMAIN:-localhost}

read -p "Введите порт [3000]: " PORT
PORT=${PORT:-3000}

read -p "Введите логин админа [admin]: " ADMIN_USER
ADMIN_USER=${ADMIN_USER:-admin}

read -sp "Введите пароль админа: " ADMIN_PASSWORD
echo ""

if [ -z "$ADMIN_PASSWORD" ]; then
    echo "❌ Пароль не может быть пустым"
    exit 1
fi

INSTALL_DIR="/opt/3dpc-telemetry"

echo ""
echo "📋 Конфигурация:"
echo "  Директория: $INSTALL_DIR"
echo "  Порт: $PORT"
echo "  Домен: $DOMAIN"
echo "  Логин: $ADMIN_USER"
echo ""

read -p "Продолжить установку? (y/n) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Отменено"
    exit 0
fi

echo ""
echo "🔄 Обновление системы..."
apt update -qq

echo "📦 Установка Node.js 18..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt install -y nodejs
fi

NODE_VERSION=$(node --version)
echo "✅ Node.js установлен: $NODE_VERSION"

echo "📦 Установка PM2..."
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
fi
echo "✅ PM2 установлен"

echo "📁 Создание директории..."
mkdir -p $INSTALL_DIR
cd $INSTALL_DIR

echo "📦 Установка dotenv..."
npm install dotenv --save

echo "⚙️ Создание .env файла..."
cat > .env << EOF
PORT=$PORT
ADMIN_USER=$ADMIN_USER
ADMIN_PASSWORD=$ADMIN_PASSWORD
NODE_ENV=production
EOF

chmod 600 .env
echo "✅ .env создан"

echo "📦 Установка зависимостей..."
npm install --production --silent

echo "🚀 Запуск через PM2..."
pm2 delete 3dpc-telemetry 2>/dev/null || true
pm2 start server.js --name 3dpc-telemetry

echo "💾 Настройка автозапуска..."
pm2 startup systemd -u root --hp /root
pm2 save

echo "🔥 Настройка файрвола..."
if command -v ufw &> /dev/null; then
    ufw allow $PORT/tcp
    echo "✅ Порт $PORT открыт в UFW"
fi

# Nginx (опционально)
if [ "$DOMAIN" != "localhost" ]; then
    echo ""
    read -p "Установить Nginx для домена $DOMAIN? (y/n) " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "📦 Установка Nginx..."
        apt install -y nginx
        
        echo "⚙️ Настройка Nginx..."
        cat > /etc/nginx/sites-available/telemetry << EOF
server {
    listen 80;
    server_name $DOMAIN;

    location / {
        proxy_pass http://localhost:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF
        
        ln -sf /etc/nginx/sites-available/telemetry /etc/nginx/sites-enabled/
        nginx -t && systemctl reload nginx
        echo "✅ Nginx настроен"
        
        # SSL
        read -p "Установить SSL сертификат? (требует домен) (y/n) " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            echo "📦 Установка Certbot..."
            apt install -y certbot python3-certbot-nginx
            
            echo "🔒 Получение SSL сертификата..."
            certbot --nginx -d $DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN
            echo "✅ SSL настроен"
        fi
    fi
fi

# Создание скрипта бэкапа
echo "💾 Создание скрипта бэкапа..."
cat > $INSTALL_DIR/backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/opt/3dpc-telemetry/backups"
mkdir -p $BACKUP_DIR
DATE=$(date +%Y%m%d_%H%M%S)
cp /opt/3dpc-telemetry/telemetry.db $BACKUP_DIR/telemetry_$DATE.db
find $BACKUP_DIR -name "telemetry_*.db" -mtime +30 -delete
echo "Backup created: telemetry_$DATE.db"
EOF

chmod +x $INSTALL_DIR/backup.sh

# Добавление в cron
echo "⏰ Настройка автоматического бэкапа..."
(crontab -l 2>/dev/null; echo "0 3 * * * $INSTALL_DIR/backup.sh") | crontab -

echo ""
echo "================================================"
echo "  ✅ Установка завершена!"
echo "================================================"
echo ""
echo "📊 Статус сервера:"
pm2 status

echo ""
echo "🌐 Доступ:"
if [ "$DOMAIN" != "localhost" ]; then
    echo "  URL: http://$DOMAIN"
else
    echo "  URL: http://localhost:$PORT"
fi
echo "  Логин: $ADMIN_USER"
echo "  Пароль: ******"
echo ""

echo "🔍 Полезные команды:"
echo "  pm2 logs 3dpc-telemetry   - Логи"
echo "  pm2 restart 3dpc-telemetry - Перезапуск"
echo "  pm2 status                 - Статус"
echo ""

echo "📝 Следующие шаги:"
echo "  1. Откройте веб-панель и проверьте доступ"
echo "  2. Обновите URL в src/telemetry.js приложения"
echo "  3. Пересоберите и выпустите новую версию"
echo ""

echo "✅ Готово!"

