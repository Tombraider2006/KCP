# 📊 Telemetry Server - Быстрая установка

## 🚀 Самый простой способ (автоматическая установка)

### Шаг 1: Загрузите файлы на сервер

**С локальной машины выполните:**

```bash
cd server-telemetry
chmod +x deploy.sh
bash deploy.sh root@your-server-ip
```

Скрипт автоматически:

- ✅ Проверит подключение
- ✅ Упакует все файлы
- ✅ Загрузит на сервер
- ✅ Распакует в `/opt/3dpc-telemetry`

### Шаг 2: Подключитесь к серверу

```bash
ssh root@your-server-ip
```

### Шаг 3: Запустите автоустановку

```bash
cd /opt/3dpc-telemetry
sudo bash install.sh
```

Скрипт спросит:

1. **Домен** (или localhost)
2. **Порт** (по умолчанию 3000)
3. **Логин** администратора
4. **Пароль** администратора

И автоматически:

- ✅ Установит Node.js
- ✅ Установит зависимости
- ✅ Настроит PM2
- ✅ Настроит автозапуск
- ✅ Настроит Nginx (опционально)
- ✅ Установит SSL (опционально)
- ✅ Настроит бэкапы

### Шаг 4: Готово! 🎉

Откройте в браузере:

- **С доменом:** `http://your-domain.com`
- **Без домена:** `http://your-server-ip:3000`

Войдите с логином и паролем, которые указали.

---

## 🔧 Альтернативный способ (ручная установка)

### Вариант 1: Через SCP

```bash
# На локальной машине
scp -r server-telemetry/* root@your-server-ip:/opt/3dpc-telemetry/

# Подключитесь к серверу
ssh root@your-server-ip

# Установите
cd /opt/3dpc-telemetry
sudo bash install.sh
```

### Вариант 2: Через Git

```bash
# На сервере
git clone your-repo-url /opt/3dpc-telemetry
cd /opt/3dpc-telemetry/server-telemetry
sudo bash install.sh
```

### Вариант 3: Вручную (полная инструкция)

См. [INSTALLATION.md](INSTALLATION.md) для детальной ручной установки.

---

## 📝 После установки

### Обновите URL в приложении

Откройте `src/telemetry.js` и измените:

```javascript
this.config = {
  serverUrl: 'https://your-domain.com/api/telemetry',
  // или
  serverUrl: 'http://your-server-ip:3000/api/telemetry',
  // ...
};
```

### Пересоберите приложение

```bash
npm run build
```

### Выпустите обновление

Пользователи автоматически начнут отправлять телеметрию.

---

## 🔍 Проверка работы

### На сервере:

```bash
# Статус
pm2 status

# Логи
pm2 logs 3dpc-telemetry

# Тест API
curl -X POST http://localhost:3000/api/telemetry \
  -H "Content-Type: application/json" \
  -d '{"id":"test","version":"1.0.0","metrics":{}}'
```

### В браузере:

Откройте веб-панель и проверьте статистику.

---

## 🛠️ Полезные команды

```bash
# PM2
pm2 logs 3dpc-telemetry      # Логи в реальном времени
pm2 restart 3dpc-telemetry   # Перезапуск
pm2 stop 3dpc-telemetry      # Остановка
pm2 status                   # Статус всех процессов

# База данных
sqlite3 /opt/3dpc-telemetry/telemetry.db "SELECT COUNT(*) FROM installations;"

# Nginx (если установлен)
systemctl status nginx
systemctl reload nginx
nginx -t  # Проверка конфигурации

# Бэкап вручную
/opt/3dpc-telemetry/backup.sh
```

---

## 🔄 Обновление

```bash
# Загрузите новые файлы
bash deploy.sh root@your-server-ip

# На сервере
cd /opt/3dpc-telemetry
npm install
pm2 restart 3dpc-telemetry
```

---

## 🆘 Помощь

### Проблема: Не могу подключиться к серверу

```bash
# Проверьте SSH
ssh root@your-server-ip

# Проверьте порты
telnet your-server-ip 22
```

### Проблема: Скрипт не выполняется

```bash
# Добавьте права на выполнение
chmod +x install.sh deploy.sh
```

### Проблема: Данные не отображаются

```bash
# Проверьте базу данных
sqlite3 /opt/3dpc-telemetry/telemetry.db
> SELECT COUNT(*) FROM installations;
> .quit
```

---

## 📞 Когда нужны данные доступа

Если нужна помощь с установкой:

1. Предоставьте IP сервера
2. Предоставьте SSH доступ (временный)
3. Укажите желаемый домен (если есть)

Или используйте автоматические скрипты выше! 🚀

---

## 📚 Документация

- [INSTALLATION.md](INSTALLATION.md) - Детальная инструкция
- [../docs/TELEMETRY_SYSTEM.md](../docs/TELEMETRY_SYSTEM.md) - Полная документация
- [../docs/INDEX.md](../docs/INDEX.md) - Общий индекс

---

**Вопросы?** Просто запустите `bash install.sh` и следуйте инструкциям! 🎯
