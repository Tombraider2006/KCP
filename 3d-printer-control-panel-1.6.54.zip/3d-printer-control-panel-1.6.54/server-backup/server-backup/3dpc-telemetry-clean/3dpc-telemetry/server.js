/**
 * Сервер телеметрии + лицензирования
 * Установка: npm install express sqlite3 express-rate-limit basic-auth node-telegram-bot-api dotenv
 */

require('dotenv').config();

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const http = require('http');
const crypto = require('crypto');
const TelegramBot = require('node-telegram-bot-api');

const app = express();
app.set('trust proxy', 1); // Fix for X-Forwarded-For when behind reverse proxy (Traefik)
const PORT = process.env.PORT || 3000;

// ====================================================================
// ШИФРОВАНИЕ - совпадает с клиентом (diagnostics.js)
// ====================================================================
const ENCRYPTION_KEY = Buffer.from('3DPC-T3l3m3try-K3y-2025-S3cur3-V1.5.36', 'utf-8').subarray(
  0,
  32,
);
const ENCRYPTION_IV_SALT = '3DPC-IV-Salt';

/**
 * Расшифровывает данные от клиента
 */
function decryptData(encryptedPacket) {
  try {
    const iv = Buffer.from(encryptedPacket.iv, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', ENCRYPTION_KEY, iv);

    let decrypted = decipher.update(encryptedPacket.encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return JSON.parse(decrypted);
  } catch (error) {
    console.error('[Decrypt] Error:', error.message);
    return null;
  }
}

// Кэш IP → Country для минимизации запросов к GeoIP API
const ipCountryCache = new Map();

// ====================================================================
// TELEGRAM BOT CONFIGURATION
// ====================================================================
let TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
let ADMIN_TELEGRAM_ID = process.env.ADMIN_TELEGRAM_ID;
let NOTIFICATION_CHANNEL_ID = process.env.NOTIFICATION_CHANNEL_ID;
let OWNER_NAME = process.env.OWNER_NAME || 'Администратор';
const LICENSE_ENCRYPTION_KEY =
  process.env.LICENSE_ENCRYPTION_KEY || 'bWci5vMAFrQV4CqxYKHTu72139tXP8pG';

let bot = null;

// Функция инициализации бота
function initBot() {
  // Останавливаем существующего бота если есть
  if (bot) {
    try {
      bot.stopPolling();
      console.log('[Bot] Stopping existing bot...');
    } catch (e) {
      console.error('[Bot] Error stopping bot:', e.message);
    }
    bot = null;
  }

  // Обновляем конфигурацию из переменных окружения
  TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  ADMIN_TELEGRAM_ID = process.env.ADMIN_TELEGRAM_ID;
  NOTIFICATION_CHANNEL_ID = process.env.NOTIFICATION_CHANNEL_ID;
  OWNER_NAME = process.env.OWNER_NAME || 'Администратор';

  if (!TELEGRAM_BOT_TOKEN || !ADMIN_TELEGRAM_ID) {
    console.log('⚠️ Telegram Bot not configured (missing TELEGRAM_BOT_TOKEN or ADMIN_TELEGRAM_ID)');
    return;
  }

  try {
    bot = new TelegramBot(TELEGRAM_BOT_TOKEN, { polling: true });
    console.log('✅ Telegram Bot initialized for licensing');

    // Обработка команды /start
    bot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      const username = msg.from.username ? '@' + msg.from.username : null;

      if (!username) {
        bot.sendMessage(
          chatId,
          '❌ У вас не установлен Telegram username. Установите его в настройках Telegram и попробуйте снова.',
        );
        return;
      }

      // Сохраняем пользователя в БД телеметрии (для связи HWID → Telegram)
      db.run(`
                CREATE TABLE IF NOT EXISTS telegram_users (
                    telegram_username TEXT PRIMARY KEY,
                    chat_id INTEGER NOT NULL,
                    first_seen INTEGER NOT NULL,
                    last_seen INTEGER NOT NULL
                )
            `);

      db.run(`
                CREATE TABLE IF NOT EXISTS hwid_telegram_mapping (
                    hwid TEXT PRIMARY KEY,
                    telegram_username TEXT NOT NULL,
                    registered_at INTEGER NOT NULL,
                    last_seen INTEGER NOT NULL,
                    platform TEXT,
                    version TEXT
                )
            `);

      const now = Date.now();
      db.run(
        `
                INSERT OR REPLACE INTO telegram_users (telegram_username, chat_id, first_seen, last_seen)
                VALUES (?, ?, COALESCE((SELECT first_seen FROM telegram_users WHERE telegram_username = ?), ?), ?)
            `,
        [username, chatId, username, now, now],
      );

      bot.sendMessage(
        chatId,
        `
🔐 <b>Добро пожаловать в 3DCP Licensing Bot!</b>

Этот бот используется для автоматической выдачи лицензий на <b>3D Printer Control Panel (3DCP)</b>.

📝 <b>Доступные тарифы:</b>
🆓 <b>FREE:</b> до 10 принтеров — навсегда бесплатно
⏱️ <b>TRIAL:</b> 14 дней без ограничений (бесплатно)
👑 <b>PROFESSIONAL:</b> полная лицензия

✅ Ваш username зарегистрирован: <b>${username}</b>

<b>Команды:</b>
/my_licenses — показать ваши текущие лицензии

Используйте кнопки ниже для запроса лицензии:
            `,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '📋 Мои лицензии', callback_data: 'my_licenses' }],
              [{ text: '⏱️ Trial (14 дней)', callback_data: 'request_trial' }],
              [{ text: '👑 Professional', callback_data: 'request_professional' }],
              [{ text: '📚 Помощь', callback_data: 'show_help' }],
            ],
          },
        },
      );

      console.log(`[Bot] User registered: ${username} (chat_id: ${chatId})`);
    });

    // Обработка команды /my_licenses для проверки текущих лицензий
    bot.onText(/\/my_licenses/, (msg) => {
      const chatId = msg.chat.id;
      const username = msg.from.username ? '@' + msg.from.username : null;

      if (!username) {
        bot.sendMessage(
          chatId,
          '❌ У вас не установлен Telegram username. Установите его в настройках Telegram и попробуйте снова.',
        );
        return;
      }

      // Получаем HWID пользователя
      db.get(
        `
                SELECT hwid FROM hwid_telegram_mapping 
                WHERE telegram_username = ? 
                ORDER BY last_seen DESC 
                LIMIT 1
            `,
        [username],
        (err, hwidRow) => {
          if (err || !hwidRow) {
            bot.sendMessage(
              chatId,
              `
❌ <b>Hardware ID не найден!</b>

Для проверки лицензий вам нужно:
1️⃣ Открыть приложение 3DCP
2️⃣ Зайти в раздел "🔐 Лицензия"
3️⃣ Ваш Hardware ID автоматически зарегистрируется
4️⃣ После этого попробуйте команду снова

<i>Hardware ID регистрируется автоматически при открытии окна лицензирования в приложении.</i>
                    `,
              { parse_mode: 'HTML' },
            );
            return;
          }

          const hwid = hwidRow.hwid;

          // Получаем все активные лицензии для этого HWID
          db.all(
            `
                    SELECT license_key, plan, expires_at, created_at 
                    FROM licenses 
                    WHERE hwid = ? AND status = 'active' 
                    ORDER BY created_at DESC
                `,
            [hwid],
            (err, licenses) => {
              if (err) {
                console.error('[Bot] License query error:', err);
                bot.sendMessage(chatId, '❌ Ошибка при получении лицензий. Попробуйте позже.');
                return;
              }

              if (!licenses || licenses.length === 0) {
                bot.sendMessage(
                  chatId,
                  `
📋 <b>Ваши лицензии</b>

У вас нет активных лицензий.

<b>Hardware ID:</b> <code>${hwid}</code>

Для получения лицензии используйте кнопки ниже:
                        `,
                  {
                    parse_mode: 'HTML',
                    reply_markup: {
                      inline_keyboard: [
                        [{ text: '⏱️ Trial (14 дней)', callback_data: 'request_trial' }],
                        [{ text: '👑 Professional', callback_data: 'request_professional' }],
                      ],
                    },
                  },
                );
                return;
              }

              let message = `📋 <b>Ваши лицензии</b>\n\n<b>Hardware ID:</b> <code>${hwid}</code>\n\n`;

              licenses.forEach((license, index) => {
                const planName =
                  license.plan === 'trial'
                    ? '⏱️ Trial'
                    : license.plan === 'professional'
                      ? '👑 Professional'
                      : license.plan;

                const expDate = license.expires_at ? new Date(license.expires_at) : null;
                const daysLeft = expDate
                  ? Math.ceil((expDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
                  : null;

                let statusMessage = '';
                if (expDate) {
                  if (daysLeft > 0) {
                    statusMessage = `Действителен до: ${expDate.toLocaleDateString('ru-RU')} (${daysLeft} ${daysLeft === 1 ? 'день' : daysLeft < 5 ? 'дня' : 'дней'})`;
                  } else {
                    statusMessage = 'Истек';
                  }
                } else {
                  statusMessage = 'Бессрочная';
                }

                message += `${index + 1}. <b>${planName}</b>\n`;
                message += `<code>${license.license_key}</code>\n`;
                message += `Статус: ${statusMessage}\n\n`;
              });

              message += `💡 <b>Совет:</b> Сохраните эти ключи! Если удалите чат с ботом, вы сможете восстановить их через этот HWID.`;

              bot.sendMessage(chatId, message, { parse_mode: 'HTML' });
            },
          );
        },
      );
    });

    // Обработка команды /hwid для ручной регистрации Hardware ID
    bot.onText(/\/hwid (.+)/, (msg, match) => {
      const chatId = msg.chat.id;
      const username = msg.from.username ? '@' + msg.from.username : null;
      const hwid = match[1].trim().toUpperCase();

      if (!username) {
        bot.sendMessage(
          chatId,
          '❌ У вас не установлен Telegram username. Установите его в настройках Telegram и попробуйте снова.',
        );
        return;
      }

      // Проверяем формат HWID (например: BD1C-B7C6-C01D-0640-F6CA-59E3-E0F9-3442)
      const hwidPattern = /^[A-F0-9]{4}(-[A-F0-9]{4}){7}$/;
      if (!hwidPattern.test(hwid)) {
        bot.sendMessage(
          chatId,
          `
❌ <b>Неверный формат Hardware ID!</b>

Hardware ID должен быть в формате:
<code>XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX</code>

Пример:
<code>BD1C-B7C6-C01D-0640-F6CA-59E3-E0F9-3442</code>

Скопируйте его из приложения (раздел "🔐 Лицензия") и отправьте снова.
                `,
          { parse_mode: 'HTML' },
        );
        return;
      }

      // Сохраняем HWID в базу данных
      const now = Date.now();
      db.run(
        `
                INSERT OR REPLACE INTO hwid_telegram_mapping (hwid, telegram_username, registered_at, last_seen, platform, version)
                VALUES (?, ?, COALESCE((SELECT registered_at FROM hwid_telegram_mapping WHERE hwid = ?), ?), ?, 'Manual', 'Unknown')
            `,
        [hwid, username, hwid, now, now],
        (err) => {
          if (err) {
            console.error('[Bot] HWID registration error:', err);
            bot.sendMessage(chatId, '❌ Ошибка при регистрации Hardware ID. Попробуйте позже.');
          } else {
            bot.sendMessage(
              chatId,
              `
✅ <b>Hardware ID успешно зарегистрирован!</b>

<b>Ваш Hardware ID:</b>
<code>${hwid}</code>

<b>Telegram:</b> ${username}

Теперь вы можете запросить лицензию, используя кнопки ниже:
                    `,
              {
                parse_mode: 'HTML',
                reply_markup: {
                  inline_keyboard: [
                    [{ text: '⏱️ Trial (14 дней)', callback_data: 'request_trial' }],
                    [{ text: '👑 Professional', callback_data: 'request_professional' }],
                    [{ text: '📚 Помощь', callback_data: 'show_help' }],
                  ],
                },
              },
            );
            console.log(`[Bot] HWID registered manually: ${hwid} → ${username}`);
          }
        },
      );
    });

    // Обработчик обычных текстовых сообщений (для HWID без команды)
    bot.on('message', (msg) => {
      // Пропускаем команды (они обрабатываются отдельно)
      if (msg.text && msg.text.startsWith('/')) {
        return;
      }

      const chatId = msg.chat.id;
      const username = msg.from.username ? '@' + msg.from.username : null;
      const text = msg.text ? msg.text.trim().toUpperCase() : '';

      if (!username) {
        return; // Игнорируем сообщения без username
      }

      // Проверяем, похоже ли это на HWID
      const hwidPattern = /^[A-F0-9]{4}(-[A-F0-9]{4}){7}$/;

      if (hwidPattern.test(text)) {
        // Это валидный HWID!
        const hwid = text;
        const now = Date.now();

        db.run(
          `
                    INSERT OR REPLACE INTO hwid_telegram_mapping (hwid, telegram_username, registered_at, last_seen, platform, version)
                    VALUES (?, ?, COALESCE((SELECT registered_at FROM hwid_telegram_mapping WHERE hwid = ?), ?), ?, 'Manual', 'Unknown')
                `,
          [hwid, username, hwid, now, now],
          (err) => {
            if (err) {
              console.error('[Bot] HWID registration error:', err);
              bot.sendMessage(chatId, '❌ Ошибка при регистрации Hardware ID. Попробуйте позже.');
            } else {
              bot.sendMessage(
                chatId,
                `
✅ <b>Hardware ID успешно зарегистрирован!</b>

<b>Ваш Hardware ID:</b>
<code>${hwid}</code>

<b>Telegram:</b> ${username}

Теперь вы можете запросить лицензию, используя кнопки ниже:
                        `,
                {
                  parse_mode: 'HTML',
                  reply_markup: {
                    inline_keyboard: [
                      [{ text: '⏱️ Trial (14 дней)', callback_data: 'request_trial' }],
                      [{ text: '👑 Professional', callback_data: 'request_professional' }],
                      [{ text: '📚 Помощь', callback_data: 'show_help' }],
                    ],
                  },
                },
              );
              console.log(`[Bot] HWID registered via text message: ${hwid} → ${username}`);
            }
          },
        );
      } else if (text.length > 20 && text.includes('-')) {
        // Похоже на попытку ввести HWID, но формат неверный
        bot.sendMessage(
          chatId,
          `
❌ <b>Неверный формат Hardware ID!</b>

Hardware ID должен быть в формате:
<code>XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX</code>

Пример:
<code>BD1C-B7C6-C01D-0640-F6CA-59E3-E0F9-3442</code>

Скопируйте его из приложения (раздел "🔐 Лицензия") и отправьте снова.
                `,
          { parse_mode: 'HTML' },
        );
      }
      // Игнорируем остальные сообщения
    });

    // Обработчик кнопок
    bot.on('callback_query', async (callbackQuery) => {
      const msg = callbackQuery.message;
      const chatId = msg.chat.id;
      const username = callbackQuery.from.username ? '@' + callbackQuery.from.username : null;
      const data = callbackQuery.data;

      // Отвечаем на callback чтобы убрать "часики"
      bot.answerCallbackQuery(callbackQuery.id);

      // ========================================
      // ОБРАБОТКА АДМИНСКИХ КНОПОК (Одобрить/Отклонить)
      // ========================================
      if (data.startsWith('approve_') || data.startsWith('reject_')) {
        const parts = data.split('_');
        const action = parts[0]; // approve или reject

        // Проверяем формат callback_data
        let plan, hwid, clientChatId;
        if (parts.length >= 4) {
          // Старый формат: approve_plan_hwid_chatId
          plan = parts[1];
          hwid = parts[2];
          clientChatId = parts[3];
        } else if (parts.length === 3 && parts[1] === 'req') {
          // Новый формат: approve_req_requestId
          const reqId = parts[2];

          // Получаем данные из БД по request_id
          db.get(
            `SELECT plan, hwid, chat_id FROM license_requests WHERE id = ?`,
            [reqId],
            (err, reqData) => {
              if (err || !reqData) {
                bot.sendMessage(chatId, '❌ Ошибка: запрос не найден');
                return;
              }

              plan = reqData.plan;
              hwid = reqData.hwid;
              clientChatId = reqData.chat_id;

              processAdminAction(action, plan, hwid, clientChatId, username, chatId);
            },
          );
          return;
        } else {
          bot.sendMessage(chatId, '❌ Ошибка: неверный формат команды');
          return;
        }

        processAdminAction(action, plan, hwid, clientChatId, username, chatId);
        return;
      }

      // Функция обработки админского действия
      function processAdminAction(action, plan, hwid, clientChatId, username, chatId) {
        if (action === 'approve') {
          // Генерируем ключ
          const crypto = require('crypto');
          const keyPart1 = crypto.randomBytes(4).toString('hex').toUpperCase();
          const keyPart2 = crypto.randomBytes(4).toString('hex').toUpperCase();
          const keyPart3 = crypto.randomBytes(4).toString('hex').toUpperCase();
          const keyPart4 = crypto.randomBytes(4).toString('hex').toUpperCase();
          const keyPart5 = crypto.randomBytes(4).toString('hex').toUpperCase();
          const key = `3DCP-${keyPart1}-${keyPart2}-${keyPart3}-${keyPart4}-${keyPart5}`;

          // Определяем срок действия
          let expiresAt = null;
          if (plan === 'trial') {
            expiresAt = Date.now() + 14 * 24 * 60 * 60 * 1000; // 14 дней
          } else if (false) {
            expiresAt = Date.now() + 90 * 24 * 60 * 60 * 1000; // 3 месяца
          } else if (plan === 'professional') {
            expiresAt = Date.now() + 365 * 24 * 60 * 60 * 1000; // 1 год
          }
          // professional - пожизненная (null)

          // Сохраняем ключ в БД
          db.run(
            `
                        INSERT INTO licenses (license_key, hwid, plan, status, created_at, expires_at, admin_notes)
                        VALUES (?, ?, ?, 'active', ?, ?, ?)
                    `,
            [key, hwid, plan, Date.now(), expiresAt, `Approved by ${username} via Telegram Bot`],
          );

          // Отправляем ключ клиенту
          bot.sendMessage(
            clientChatId,
            `
🎉 <b>Ваша лицензия одобрена!</b>

<b>Лицензионный ключ:</b>
<code>${key}</code>

<b>Тарифный план:</b> ${plan.toUpperCase()}
${expiresAt ? `<b>Действителен до:</b> ${new Date(expiresAt).toLocaleDateString('ru-RU')}` : '<b>Действителен:</b> Бессрочно'}

📝 <b>Как активировать:</b>
1. Откройте приложение 3DCP
2. Перейдите в раздел "🔐 Лицензия"
3. Вкладка "🔑 Активация"
4. Скопируйте ключ выше и вставьте в поле
5. Нажмите "Активировать"

✅ Готово! Приятного использования!
                    `,
            { parse_mode: 'HTML' },
          );

          // Уведомление админу
          bot.sendMessage(
            chatId,
            `✅ Лицензия ${plan.toUpperCase()} для HWID ${hwid} одобрена!\n\nКлюч отправлен клиенту.`,
            { parse_mode: 'HTML' },
          );

          console.log(`[Bot] License approved: ${plan} → ${hwid} by ${username}`);
        } else if (action === 'reject') {
          // Отправляем отклонение клиенту
          bot.sendMessage(
            clientChatId,
            `
❌ <b>Ваш запрос лицензии отклонен</b>

К сожалению, ваш запрос на лицензию ${plan.toUpperCase()} не был одобрен.

Если у вас есть вопросы, свяжитесь с администратором: ${OWNER_NAME || 'администратор'}
                    `,
            { parse_mode: 'HTML' },
          );

          // Уведомление админу
          bot.sendMessage(
            chatId,
            `❌ Запрос лицензии ${plan.toUpperCase()} для HWID ${hwid} отклонен.`,
          );

          console.log(`[Bot] License rejected: ${plan} → ${hwid} by ${username}`);
        }

        return; // Завершаем обработку админской кнопки
      }

      // ========================================
      // ОБРАБОТКА КНОПОК КЛИЕНТОВ (Запрос лицензии)
      // ========================================

      if (!username) {
        bot.sendMessage(chatId, '❌ У вас не установлен Telegram username.');
        return;
      }

      // Получаем последний HWID пользователя
      db.get(
        `
                SELECT hwid, platform, version 
                FROM hwid_telegram_mapping 
                WHERE telegram_username = ? 
                ORDER BY last_seen DESC 
                LIMIT 1
            `,
        [username],
        (err, row) => {
          if (data === 'enter_hwid') {
            // Пользователь хочет ввести HWID вручную
            bot.sendMessage(
              chatId,
              `
⌨️ <b>Ввод Hardware ID</b>

Скопируйте ваш Hardware ID из приложения (раздел "🔐 Лицензия") и отправьте его следующим сообщением.

<b>Формат:</b>
<code>XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX</code>

<b>Пример:</b>
<code>BD1C-B7C6-C01D-0640-F6CA-59E3-E0F9-3442</code>

Просто скопируйте и отправьте мне.
                    `,
              { parse_mode: 'HTML' },
            );
            return;
          }

          if (data === 'my_licenses') {
            // Вызываем ту же логику что и для команды /my_licenses
            const hwid = row.hwid;

            // Получаем все активные лицензии для этого HWID
            db.all(
              `
                        SELECT license_key, plan, expires_at, created_at 
                        FROM licenses 
                        WHERE hwid = ? AND status = 'active' 
                        ORDER BY created_at DESC
                    `,
              [hwid],
              (err, licenses) => {
                if (err) {
                  console.error('[Bot] License query error:', err);
                  bot.sendMessage(chatId, '❌ Ошибка при получении лицензий. Попробуйте позже.');
                  return;
                }

                if (!licenses || licenses.length === 0) {
                  bot.sendMessage(
                    chatId,
                    `
📋 <b>Ваши лицензии</b>

У вас нет активных лицензий.

<b>Hardware ID:</b> <code>${hwid}</code>

Для получения лицензии используйте кнопки ниже:
                            `,
                    {
                      parse_mode: 'HTML',
                      reply_markup: {
                        inline_keyboard: [
                          [{ text: '⏱️ Trial (14 дней)', callback_data: 'request_trial' }],
                          [{ text: '👑 Professional', callback_data: 'request_professional' }],
                        ],
                      },
                    },
                  );
                  return;
                }

                let message = `📋 <b>Ваши лицензии</b>\n\n<b>Hardware ID:</b> <code>${hwid}</code>\n\n`;

                licenses.forEach((license, index) => {
                  const planName =
                    license.plan === 'trial'
                      ? '⏱️ Trial'
                      : license.plan === 'professional'
                        ? '👑 Professional'
                        : license.plan;

                  const expDate = license.expires_at ? new Date(license.expires_at) : null;
                  const daysLeft = expDate
                    ? Math.ceil((expDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
                    : null;

                  let statusMessage = '';
                  if (expDate) {
                    if (daysLeft > 0) {
                      statusMessage = `Действителен до: ${expDate.toLocaleDateString('ru-RU')} (${daysLeft} ${daysLeft === 1 ? 'день' : daysLeft < 5 ? 'дня' : 'дней'})`;
                    } else {
                      statusMessage = 'Истек';
                    }
                  } else {
                    statusMessage = 'Бессрочная';
                  }

                  message += `${index + 1}. <b>${planName}</b>\n`;
                  message += `<code>${license.license_key}</code>\n`;
                  message += `Статус: ${statusMessage}\n\n`;
                });

                message += `💡 <b>Совет:</b> Сохраните эти ключи! Если удалите чат с ботом, вы сможете восстановить их через этот HWID.`;

                bot.sendMessage(chatId, message, { parse_mode: 'HTML' });
              },
            );
            return;
          }

          if (data === 'show_help') {
            bot.sendMessage(
              chatId,
              `
📚 <b>Как получить лицензию:</b>

1️⃣ Скачайте и установите 3DCP
2️⃣ Откройте приложение
3️⃣ Нажмите кнопку "🔐 Лицензия"
4️⃣ Ваш Hardware ID автоматически зарегистрируется
5️⃣ Нажмите кнопку в этом чате для запроса лицензии
6️⃣ Для платных тарифов администратор свяжется для уточнения оплаты
7️⃣ После оплаты ключ автоматически придет в этот чат!

<b>🔍 Проверка лицензий:</b>
• Нажмите "📋 Мои лицензии" или напишите /my_licenses
• Увидите все ваши активные лицензии
• Полные ключи и сроки действия
• Полезно если случайно удалили чат с ботом

<b>💡 ВАЖНО:</b>
• Перед запросом лицензии обязательно откройте приложение хотя бы один раз
• Это нужно для регистрации вашего Hardware ID
• Сохраняйте ключи лицензий в надежном месте

⚠️ <b>DISCLAIMER:</b>
Принтеры Bambu Lab имеют закрытую прошивку. Их работа с программой НЕ ГАРАНТИРОВАНА и может быть прекращена в любой момент по независящим от нас причинам.
                    `,
              { parse_mode: 'HTML' },
            );
            return;
          }

          if (!row || !row.hwid) {
            bot.sendMessage(
              chatId,
              `
❌ <b>Hardware ID не найден!</b>

Для запроса лицензии вам нужно:
1️⃣ Открыть приложение 3DCP
2️⃣ Зайти в раздел "🔐 Лицензия"
3️⃣ Ваш Hardware ID автоматически зарегистрируется
4️⃣ После этого вернитесь сюда и нажмите кнопку снова

<i>Hardware ID регистрируется автоматически при открытии окна лицензирования в приложении.</i>

<b>Или введите его вручную:</b>
Нажмите кнопку ниже и отправьте ваш Hardware ID из приложения.
                    `,
              {
                parse_mode: 'HTML',
                reply_markup: {
                  inline_keyboard: [
                    [{ text: '⌨️ Ввести HWID вручную', callback_data: 'enter_hwid' }],
                  ],
                },
              },
            );
            return;
          }

          const hwid = row.hwid;
          const platform = row.platform || 'Unknown';
          const version = row.version || 'Unknown';

          // Определяем тип запроса
          let plan = '';
          let planName = '';
          if (data === 'request_trial') {
            plan = 'trial';
            planName = '⏱️ TRIAL (14 дней)';
            // plan = 'standard'; // удален
            // planName = '💎 STANDARD (3 месяца)'; // удален
          } else if (data === 'request_professional') {
            plan = 'professional';
            planName = '👑 PROFESSIONAL (1 год)';
          }

          if (plan === 'trial') {
            // Автовыдача TRIAL: один раз на Telegram и один раз на HWID (без await)
            db.get(
              `SELECT license_key, expires_at FROM licenses WHERE plan = 'trial' AND hwid = ? LIMIT 1`,
              [hwid],
              (err, hwidTrial) => {
                if (err) {
                  console.error('[Bot] Trial check (hwid) error:', err);
                  bot.sendMessage(chatId, '❌ Ошибка выдачи Trial. Попробуйте позже.', {
                    parse_mode: 'HTML',
                  });
                  return;
                }
                db.get(
                  `
                            SELECT l.license_key, l.expires_at
                            FROM licenses l
                            JOIN hwid_telegram_mapping m ON m.hwid = l.hwid
                            WHERE l.plan = 'trial' AND m.telegram_username = ?
                            LIMIT 1
                        `,
                  [username],
                  (err2, userTrial) => {
                    if (err2) {
                      console.error('[Bot] Trial check (user) error:', err2);
                      bot.sendMessage(chatId, '❌ Ошибка выдачи Trial. Попробуйте позже.', {
                        parse_mode: 'HTML',
                      });
                      return;
                    }
                    if (hwidTrial || userTrial) {
                      const existingLicense = hwidTrial || userTrial;
                      const exp = existingLicense.expires_at
                        ? new Date(existingLicense.expires_at).toLocaleDateString('ru-RU')
                        : '—';
                      const licenseKey = existingLicense.license_key || 'неизвестен';

                      bot.sendMessage(
                        chatId,
                        `
❌ <b>Trial уже выдавался ранее</b>

Для вашего аккаунта или HWID Trial лицензия уже была выдана.

<b>Ваш ключ лицензии:</b>
<code>${licenseKey}</code>

<b>Действителен до:</b> ${exp}

💡 <b>Совет:</b> Сохраните этот ключ! Если удалите чат с ботом, вы сможете восстановить его через этот HWID.

Вы можете приобрести полную лицензию:
• 💎 Standard (удален)
• 👑 Professional
                                `,
                        { parse_mode: 'HTML' },
                      );
                      return;
                    }
                    // Генерация Trial ключа
                    const crypto = require('crypto');
                    const key = `3DCP-${crypto.randomBytes(4).toString('hex').toUpperCase()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
                    const expiresAt = Date.now() + 14 * 24 * 60 * 60 * 1000;
                    db.run(
                      `
                                INSERT INTO licenses (license_key, hwid, plan, status, created_at, expires_at, admin_notes)
                                VALUES (?, ?, 'trial', 'active', ?, ?, 'Auto-issued via bot')
                            `,
                      [key, hwid, Date.now(), expiresAt],
                      (insErr) => {
                        if (insErr) {
                          console.error('[Bot] Trial insert error:', insErr);
                          bot.sendMessage(chatId, '❌ Ошибка выдачи Trial. Попробуйте позже.', {
                            parse_mode: 'HTML',
                          });
                          return;
                        }
                        bot.sendMessage(
                          chatId,
                          `
🎁 <b>Trial лицензия выдана автоматически!</b>

<b>Лицензионный ключ:</b>
<code>${key}</code>

<b>Действителен до:</b> ${new Date(expiresAt).toLocaleDateString('ru-RU')}

Активируйте в приложении: Раздел "🔐 Лицензия" → "🔑 Активация".
                                `,
                          { parse_mode: 'HTML' },
                        );

                        // Уведомляем админа о выданной Trial лицензии (тихо)
                        if (ADMIN_TELEGRAM_ID) {
                          bot.sendMessage(
                            ADMIN_TELEGRAM_ID,
                            `
🎁 <b>Trial лицензия выдана автоматически</b>

<b>Пользователь:</b> ${username}
<b>HWID:</b> <code>${hwid.substring(0, 24)}...</code>
<b>Ключ:</b> <code>${key}</code>
<b>Действителен до:</b> ${new Date(expiresAt).toLocaleDateString('ru-RU')}

🤖 Выдано автоматически без звука
                                    `,
                            {
                              parse_mode: 'HTML',
                              disable_notification: true,
                            },
                          );
                        }
                      },
                    );
                  },
                );
              },
            );
          } else {
            // Платные планы — сначала проверяем существующие лицензии
            db.get(
              `SELECT license_key, plan, expires_at FROM licenses WHERE hwid = ? AND plan = 'professional' AND status = 'active' LIMIT 1`,
              [hwid],
              (err, existingLicense) => {
                if (err) {
                  console.error('[Bot] License check error:', err);
                  // В случае ошибки просто отправляем запрос
                  sendLicenseRequest();
                  return;
                }

                if (existingLicense) {
                  // У пользователя уже есть активная лицензия
                  const expDate = existingLicense.expires_at
                    ? new Date(existingLicense.expires_at)
                    : null;
                  const daysLeft = expDate
                    ? Math.ceil((expDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
                    : null;

                  let statusMessage = '';
                  if (expDate) {
                    if (daysLeft > 0) {
                      statusMessage = `Действителен до: ${expDate.toLocaleDateString('ru-RU')} (${daysLeft} ${daysLeft === 1 ? 'день' : daysLeft < 5 ? 'дня' : 'дней'})`;
                    } else {
                      statusMessage = 'Истек';
                    }
                  } else {
                    statusMessage = 'Бессрочная';
                  }

                  const existingPlanName = '👑 Professional';

                  bot.sendMessage(
                    chatId,
                    `
❌ <b>У вас уже есть активная лицензия!</b>

<b>Текущая лицензия:</b> ${existingPlanName}
<b>Ключ лицензии:</b>
<code>${existingLicense.license_key}</code>

<b>Статус:</b> ${statusMessage}

💡 <b>Совет:</b> Сохраните этот ключ! Если удалите чат с ботом, вы сможете восстановить его через этот HWID.

Если вам нужна новая лицензия или продление, свяжитесь с администратором напрямую.
                            `,
                    { parse_mode: 'HTML' },
                  );
                  return;
                }

                // Лицензии нет - отправляем запрос
                sendLicenseRequest();
              },
            );

            function sendLicenseRequest() {
              bot.sendMessage(
                chatId,
                `
📨 <b>Запрос лицензии отправлен!</b>

<b>Тарифный план:</b> ${planName}
<b>Hardware ID:</b> <code>${hwid}</code>
<b>Платформа:</b> ${platform}
<b>Версия:</b> ${version}

⏳ Администратор свяжется с вами для уточнения способа оплаты. После оплаты ключ автоматически придет в этот чат!
                        `,
                { parse_mode: 'HTML' },
              );
            }
          }

          // Отправляем уведомление админу (для платных планов)
          const adminMessage = `
🔔 <b>Новый запрос лицензии</b>

<b>Тариф:</b> ${planName}
<b>Пользователь:</b> ${username}
<b>Hardware ID:</b> <code>${hwid}</code>
<b>Платформа:</b> ${platform}
<b>Версия:</b> ${version}
<b>Chat ID:</b> <code>${chatId}</code>
                `;

          // Генерируем короткий request_id (максимум 8 символов для callback_data)
          const reqId = Math.random().toString(36).slice(2, 10).toUpperCase();
          db.run(
            `INSERT INTO license_requests (id, plan, hwid, chat_id, created_at) VALUES (?, ?, ?, ?, ?)`,
            [reqId, plan, hwid, chatId, Date.now()],
          );
          const adminButtons = {
            inline_keyboard: [
              [
                { text: '✅ Одобрить', callback_data: `approve_req_${reqId}` },
                { text: '❌ Отклонить', callback_data: `reject_req_${reqId}` },
              ],
            ],
          };

          // Отправляем админу (для всех планов кроме trial)
          if (ADMIN_TELEGRAM_ID && plan !== 'trial') {
            bot
              .sendMessage(ADMIN_TELEGRAM_ID, adminMessage, {
                parse_mode: 'HTML',
                reply_markup: adminButtons,
                // Убираем disable_notification для платных лицензий - админ должен получать уведомления со звуком
              })
              .catch((err) => {
                console.error('[Bot] Failed to send admin notification:', err.message);
              });
          }

          // Отправляем в канал (если настроен)
          if (NOTIFICATION_CHANNEL_ID && plan !== 'trial') {
            bot
              .sendMessage(NOTIFICATION_CHANNEL_ID, adminMessage, {
                parse_mode: 'HTML',
                reply_markup: adminButtons,
              })
              .catch((err) => {
                console.error('[Bot] Failed to send channel notification:', err.message);
              });
          }

          console.log(`[Bot] License request: ${username} → ${plan} (HWID: ${hwid})`);
        },
      );
    });
  } catch (error) {
    console.error('⚠️ Telegram Bot initialization failed:', error.message);
    console.error('Licensing features will not be available. Check TELEGRAM_BOT_TOKEN in .env');
  }
}

// Инициализируем бота при старте
initBot();

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.static('public'));

// Rate limiting для API
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 минут
  max: 200, // максимум 200 запросов с одного IP за 15 минут
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/api/', apiLimiter);

// ====================================================================
// ACTIVATE LICENSE (always returns JSON)
// ====================================================================
// API endpoint для получения всех лицензий (для админки)
app.get('/api/license/all', webInterfaceAuth, (req, res) => {
  try {
    db.all(
      `
            SELECT 
                l.license_key as id,
                l.license_key,
                l.hwid,
                l.plan,
                l.status,
                l.created_at,
                l.expires_at,
                l.admin_notes,
                htm.telegram_username
            FROM licenses l
            LEFT JOIN hwid_telegram_mapping htm ON l.hwid = htm.hwid
            ORDER BY l.created_at DESC
        `,
      (err, licenses) => {
        if (err) {
          console.error('[License All] DB error:', err.message);
          return res.status(500).json({ error: 'Database error' });
        }

        res.json(licenses || []);
      },
    );
  } catch (error) {
    console.error('[License All] Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// API endpoint для получения всех запросов лицензий (для админки)
app.get('/api/license/requests', webInterfaceAuth, (req, res) => {
  try {
    db.all(
      `
            SELECT 
                lr.id,
                lr.plan,
                lr.hwid,
                lr.status,
                lr.created_at,
                lr.admin_notes,
                htm.telegram_username
            FROM license_requests lr
            LEFT JOIN hwid_telegram_mapping htm ON lr.hwid = htm.hwid
            ORDER BY lr.created_at DESC
        `,
      (err, requests) => {
        if (err) {
          console.error('[License Requests] DB error:', err.message);
          return res.status(500).json({ error: 'Database error' });
        }

        res.json(requests || []);
      },
    );
  } catch (error) {
    console.error('[License Requests] Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// API endpoint для проверки лицензий (для админки)
app.get('/api/license/check/:hwid', (req, res) => {
  try {
    const hwid = req.params.hwid;
    console.log(`[License Check] Checking licenses for HWID: ${hwid}`);

    // HWID уже в правильном формате с дефисами
    console.log(`[License Check] Using HWID as is: ${hwid}`);

    db.all(
      `
            SELECT license_key, plan, expires_at, created_at, status 
            FROM licenses 
            WHERE hwid = ? 
            ORDER BY created_at DESC
        `,
      [hwid],
      (err, licenses) => {
        if (err) {
          console.error('[License Check] DB error:', err.message);
          return res.status(500).json({ error: 'Database error' });
        }

        res.json({
          success: true,
          licenses: licenses || [],
          count: licenses ? licenses.length : 0,
        });
      },
    );
  } catch (error) {
    console.error('[License Check] Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/license/activate', (req, res) => {
  try {
    const { key, hwid, version, platform } = req.body || {};
    res.setHeader('Content-Type', 'application/json');

    console.log(
      `[License Activation] Attempt: ${key?.substring(0, 15)}..., HWID: ${hwid?.substring(0, 16)}...`,
    );

    if (!key || !hwid) {
      console.log('[License Activation] Missing key or hwid');
      return res.status(400).json({ success: false, message: 'Missing key or hwid' });
    }

    // Нормализуем ключ (убираем пробелы, приводим к верхнему регистру)
    const normalizedKey = key.trim().toUpperCase();

    // Нормализуем HWID (убираем дефисы, приводим к верхнему регистру)
    const normalizedHWID = hwid.replace(/-/g, '').toUpperCase();

    db.get(
      `SELECT license_key, hwid, plan, expires_at, status FROM licenses WHERE license_key = ? LIMIT 1`,
      [normalizedKey],
      (err, row) => {
        if (err) {
          console.error('[License Activation] DB error:', err.message);
          return res.status(500).json({ success: false, message: 'Ошибка базы данных' });
        }

        if (!row) {
          console.log(`[License Activation] License not found: ${normalizedKey}`);
          return res
            .status(404)
            .json({
              success: false,
              message: 'Лицензия не найдена. Проверьте правильность ключа.',
            });
        }

        if (row.status !== 'active') {
          console.log(
            `[License Activation] License not active: ${normalizedKey}, status: ${row.status}`,
          );
          return res.status(403).json({ success: false, message: 'Лицензия неактивна' });
        }

        // Нормализуем HWID из базы данных
        const dbHWID = row.hwid.replace(/-/g, '').toUpperCase();

        if (dbHWID !== normalizedHWID) {
          console.log(
            `[License Activation] HWID mismatch: expected ${normalizedHWID}, got ${dbHWID}`,
          );
          return res
            .status(403)
            .json({ success: false, message: 'Лицензия привязана к другому компьютеру' });
        }

        if (row.expires_at && Date.now() > row.expires_at) {
          console.log(
            `[License Activation] License expired: ${new Date(row.expires_at).toISOString()}`,
          );
          return res.status(403).json({ success: false, message: 'Срок действия лицензии истек' });
        }

        console.log(`[License Activation] Success: ${normalizedKey} → ${row.plan}`);
        return res.json({
          success: true,
          plan: row.plan,
          expiresAt: row.expires_at || null,
          message: 'Лицензия успешно активирована!',
        });
      },
    );
  } catch (error) {
    console.error('[License Activation] Error:', error);
    res.setHeader('Content-Type', 'application/json');
    return res.status(500).json({ success: false, message: 'Внутренняя ошибка сервера' });
  }
});

// База данных SQLite
const dbPath = path.join(__dirname, 'telemetry.db');
const db = new sqlite3.Database(dbPath);

// Создание таблиц
db.serialize(() => {
  // Таблица инсталляций
  db.run(`
        CREATE TABLE IF NOT EXISTS installations (
            id TEXT PRIMARY KEY,
            version TEXT,
            platform TEXT,
            arch TEXT,
            locale TEXT,
            country TEXT,
            ip_address TEXT,
            install_date INTEGER,
            first_seen INTEGER,
            last_seen INTEGER,
            sessions_total INTEGER DEFAULT 0,
            printers_current INTEGER DEFAULT 0,
            printers_max INTEGER DEFAULT 0,
            printers_klipper INTEGER DEFAULT 0,
            printers_bambu INTEGER DEFAULT 0,
            analytics_views INTEGER DEFAULT 0,
            exports_count INTEGER DEFAULT 0,
            current_theme TEXT DEFAULT 'dark',
            web_server_enabled INTEGER DEFAULT 0,
            total_uptime_seconds INTEGER DEFAULT 0
        )
    `);

  // Таблица событий удалена для оптимизации - все данные хранятся в installations

  // Таблица использования функций
  db.run(`
        CREATE TABLE IF NOT EXISTS feature_usage (
            installation_id TEXT,
            feature_name TEXT,
            usage_count INTEGER DEFAULT 0,
            last_used INTEGER,
            PRIMARY KEY(installation_id, feature_name),
            FOREIGN KEY(installation_id) REFERENCES installations(id)
        )
    `);

  // Таблица лицензий (используется ботом и админкой)
  db.run(`
        CREATE TABLE IF NOT EXISTS licenses (
            license_key TEXT PRIMARY KEY,
            hwid TEXT NOT NULL,
            plan TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            expires_at INTEGER,
            admin_notes TEXT
        )
    `);

  // Таблица заявок на лицензию (для коротких callback_data)
  db.run(`
        CREATE TABLE IF NOT EXISTS license_requests (
            id TEXT PRIMARY KEY,
            plan TEXT NOT NULL,
            hwid TEXT NOT NULL,
            chat_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL
        )
    `);

  // Миграция: добавляем поле locale если его нет
  db.run(
    `
        ALTER TABLE installations ADD COLUMN locale TEXT
    `,
    (err) => {
      if (err && !err.message.includes('duplicate column')) {
        console.error('Migration error:', err.message);
      }
    },
  );

  // Миграция: добавляем поле country если его нет
  db.run(
    `
        ALTER TABLE installations ADD COLUMN country TEXT
    `,
    (err) => {
      if (err && !err.message.includes('duplicate column')) {
        console.error('Migration error:', err.message);
      }
    },
  );

  // Миграция: добавляем поле ip_address если его нет
  db.run(
    `
        ALTER TABLE installations ADD COLUMN ip_address TEXT
    `,
    (err) => {
      if (err && !err.message.includes('duplicate column')) {
        console.error('Migration error:', err.message);
      }
    },
  );

  // Миграция: добавляем поле current_theme если его нет
  db.run(
    `
        ALTER TABLE installations ADD COLUMN current_theme TEXT DEFAULT 'dark'
    `,
    (err) => {
      if (err && !err.message.includes('duplicate column')) {
        console.error('Migration error:', err.message);
      }
    },
  );

  // Миграция: добавляем поле web_server_enabled если его нет
  db.run(
    `
        ALTER TABLE installations ADD COLUMN web_server_enabled INTEGER DEFAULT 0
    `,
    (err) => {
      if (err && !err.message.includes('duplicate column')) {
        console.error('Migration error:', err.message);
      }
    },
  );

  // Миграция: добавляем поле total_uptime_seconds если его нет
  db.run(
    `
        ALTER TABLE installations ADD COLUMN total_uptime_seconds INTEGER DEFAULT 0
    `,
    (err) => {
      if (err && !err.message.includes('duplicate column')) {
        console.error('Migration error:', err.message);
      }
    },
  );

  // ===== НОВЫЕ КОЛОНКИ v1.5.36 =====

  // Умные розетки
  db.run(`ALTER TABLE installations ADD COLUMN smart_plugs_total INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN smart_plugs_tuya INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN smart_plugs_ha INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN automations_enabled INTEGER DEFAULT 0`, () => {});

  // Пакетные операции
  db.run(`ALTER TABLE installations ADD COLUMN batch_adds_count INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN network_scans_count INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN avg_batch_size REAL DEFAULT 0`, () => {});

  // Температуры
  db.run(`ALTER TABLE installations ADD COLUMN max_nozzle_temp INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN max_bed_temp INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN max_mcu_temp INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN overheating_events INTEGER DEFAULT 0`, () => {});

  // События
  db.run(`ALTER TABLE installations ADD COLUMN print_errors INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN emergency_shutdowns INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN successful_prints INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN manual_plug_toggles INTEGER DEFAULT 0`, () => {});

  // Модули
  db.run(`ALTER TABLE installations ADD COLUMN webserver_starts INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN webserver_uptime_total INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN analytics_opens INTEGER DEFAULT 0`, () => {});
  db.run(`ALTER TABLE installations ADD COLUMN help_pages_opened INTEGER DEFAULT 0`, () => {});

  // Создаем индексы для ускорения запросов
  db.run(`CREATE INDEX IF NOT EXISTS idx_installations_last_seen ON installations(last_seen)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_installations_version ON installations(version)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_installations_platform ON installations(platform)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_installations_country ON installations(country)`);

  console.log('✅ Database initialized with v1.5.36 extended analytics');
});

// ===== GEOIP ФУНКЦИОНАЛ =====

/**
 * Определение страны по IP через ip-api.com
 * @param {string} ip - IP адрес клиента
 * @returns {Promise<string|null>} - Код страны (RU, US, DE и т.д.) или null
 */
async function getCountryByIP(ip) {
  // Пропускаем локальные IP
  if (
    ip === '127.0.0.1' ||
    ip === '::1' ||
    ip.startsWith('192.168.') ||
    ip.startsWith('10.') ||
    ip.startsWith('172.')
  ) {
    return null;
  }

  // Проверяем кэш
  if (ipCountryCache.has(ip)) {
    return ipCountryCache.get(ip);
  }

  try {
    const response = await new Promise((resolve, reject) => {
      http
        .get(`http://ip-api.com/json/${ip}?fields=status,country,countryCode`, (res) => {
          let data = '';
          res.on('data', (chunk) => (data += chunk));
          res.on('end', () => resolve(JSON.parse(data)));
        })
        .on('error', reject);
    });

    if (response.status === 'success' && response.countryCode) {
      const country = response.countryCode;
      ipCountryCache.set(ip, country);
      console.log(`[GeoIP] ${ip} → ${country} (${response.country})`);
      return country;
    }
  } catch (error) {
    console.error('[GeoIP] Error:', error.message);
  }

  return null;
}

// Auth removed from API - but web interface protected by IP whitelist

// Middleware: Allow web interface with secret token
function webInterfaceAuth(req, res, next) {
  const token = req.query.token || req.headers['x-admin-token'];
  const secretToken = process.env.ADMIN_TOKEN || 'telemetry-secret-2024';

  // Allow with correct token
  if (token === secretToken) {
    return next();
  }

  // Also allow from localhost/Docker for direct access
  const ip = req.ip || req.connection.remoteAddress;
  if (
    ip === '127.0.0.1' ||
    ip === '::1' ||
    ip === '::ffff:127.0.0.1' ||
    ip.startsWith('172.17.') ||
    ip.startsWith('::ffff:172.17.') ||
    ip.startsWith('172.18.') ||
    ip.startsWith('::ffff:172.18.')
  ) {
    return next();
  }

  res
    .status(403)
    .send('Access denied. Web interface available only via admin panel: https://tomich.fun/admin');
}

// ============================================================================
// API ENDPOINTS
// ============================================================================

/**
 * POST /api/telemetry - принять данные телеметрии
 */
app.post('/api/telemetry', apiLimiter, async (req, res) => {
  let data = req.body;

  // РАСШИФРОВКА ДАННЫХ если пришли зашифрованными (v1.5.36+)
  if (data.encrypted && data.iv && data.version) {
    console.log('[Telemetry] Encrypted data received, decrypting...');
    const decrypted = decryptData(data);
    if (!decrypted) {
      console.error('[Telemetry] Failed to decrypt data');
      return res.status(400).json({ error: 'Decryption failed' });
    }
    data = decrypted;
    console.log('[Telemetry] Data decrypted successfully');
  }

  // Валидация
  if (!data.id || !data.version || !data.metrics) {
    return res.status(400).json({ error: 'Invalid data' });
  }

  // Получаем IP клиента
  const clientIP =
    req.headers['x-forwarded-for']?.split(',')[0].trim() ||
    req.headers['x-real-ip'] ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress;

  console.log(
    '[Telemetry] Received from:',
    data.id.substring(0, 8),
    'version:',
    data.version,
    'IP:',
    clientIP,
  );

  const now = Date.now();

  // Определяем страну по IP (асинхронно, не блокируем ответ)
  let country = null;
  try {
    country = await getCountryByIP(clientIP);
  } catch (error) {
    console.error('[GeoIP] Failed to get country:', error.message);
  }

  // Обновляем или создаем запись инсталляции
  db.run(
    `
        INSERT INTO installations (
            id, version, platform, arch, locale, country, ip_address, install_date, first_seen, last_seen,
            sessions_total, printers_current, printers_max, 
            printers_klipper, printers_bambu, analytics_views, exports_count,
            current_theme, web_server_enabled, total_uptime_seconds,
            smart_plugs_total, smart_plugs_tuya, smart_plugs_ha, automations_enabled,
            batch_adds_count, network_scans_count, avg_batch_size,
            max_nozzle_temp, max_bed_temp, max_mcu_temp, overheating_events,
            print_errors, emergency_shutdowns, successful_prints, manual_plug_toggles,
            webserver_starts, webserver_uptime_total, analytics_opens, help_pages_opened
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            version = excluded.version,
            platform = excluded.platform,
            arch = excluded.arch,
            locale = excluded.locale,
            country = COALESCE(excluded.country, country),
            ip_address = excluded.ip_address,
            last_seen = excluded.last_seen,
            sessions_total = excluded.sessions_total,
            printers_current = excluded.printers_current,
            printers_max = CASE WHEN excluded.printers_max > printers_max THEN excluded.printers_max ELSE printers_max END,
            printers_klipper = excluded.printers_klipper,
            printers_bambu = excluded.printers_bambu,
            analytics_views = excluded.analytics_views,
            exports_count = excluded.exports_count,
            current_theme = excluded.current_theme,
            web_server_enabled = excluded.web_server_enabled,
            total_uptime_seconds = total_uptime_seconds + excluded.total_uptime_seconds,
            smart_plugs_total = excluded.smart_plugs_total,
            smart_plugs_tuya = excluded.smart_plugs_tuya,
            smart_plugs_ha = excluded.smart_plugs_ha,
            automations_enabled = excluded.automations_enabled,
            batch_adds_count = excluded.batch_adds_count,
            network_scans_count = excluded.network_scans_count,
            avg_batch_size = excluded.avg_batch_size,
            max_nozzle_temp = CASE WHEN excluded.max_nozzle_temp > max_nozzle_temp THEN excluded.max_nozzle_temp ELSE max_nozzle_temp END,
            max_bed_temp = CASE WHEN excluded.max_bed_temp > max_bed_temp THEN excluded.max_bed_temp ELSE max_bed_temp END,
            max_mcu_temp = CASE WHEN excluded.max_mcu_temp > max_mcu_temp THEN excluded.max_mcu_temp ELSE max_mcu_temp END,
            overheating_events = excluded.overheating_events,
            print_errors = excluded.print_errors,
            emergency_shutdowns = excluded.emergency_shutdowns,
            successful_prints = excluded.successful_prints,
            manual_plug_toggles = excluded.manual_plug_toggles,
            webserver_starts = excluded.webserver_starts,
            webserver_uptime_total = excluded.webserver_uptime_total,
            analytics_opens = excluded.analytics_opens,
            help_pages_opened = excluded.help_pages_opened
    `,
    [
      data.id,
      data.version,
      data.platform,
      data.arch,
      data.locale || null,
      country,
      clientIP,
      data.installDate,
      now,
      now,
      data.metrics.sessions || 0,
      data.metrics.currentPrinters || 0,
      data.metrics.maxPrinters || 0,
      data.metrics.printersKlipper || 0,
      data.metrics.printersBambu || 0,
      data.metrics.analyticsViews || 0,
      data.metrics.exportsCount || 0,
      data.currentTheme || 'dark',
      data.webServerEnabled ? 1 : 0,
      data.metrics.sessionUptime || 0,
      // Новые метрики v1.5.36
      data.metrics.smartPlugs?.totalPlugsLinked || 0,
      data.metrics.smartPlugs?.tuyaPlugsCount || 0,
      data.metrics.smartPlugs?.haPlugsCount || 0,
      data.metrics.smartPlugs?.automationsEnabled || 0,
      data.metrics.batchOperations?.batchAddsCount || 0,
      data.metrics.batchOperations?.networkScansCount || 0,
      data.metrics.batchOperations?.avgPrintersPerBatch || 0,
      data.metrics.temperatures?.maxNozzleTemp || 0,
      data.metrics.temperatures?.maxBedTemp || 0,
      data.metrics.temperatures?.maxMCUTemp || 0,
      data.metrics.temperatures?.overheatingEvents || 0,
      data.metrics.events?.printErrors || 0,
      data.metrics.events?.emergencyShutdowns || 0,
      data.metrics.events?.successfulPrints || 0,
      data.metrics.events?.manualPlugToggles || 0,
      data.metrics.modules?.webServerUsageCount || 0,
      data.metrics.modules?.webServerTotalUptime || 0,
      data.metrics.modules?.analyticsOpenCount || 0,
      data.metrics.modules?.helpPagesOpened || 0,
    ],
    (err) => {
      if (err) {
        console.error('[DB] Error saving installation:', err);
      }
    },
  );

  // События больше не сохраняются отдельно - вся информация в installations

  // Обновляем использование функций
  if (data.metrics.featureUsage) {
    const features = data.metrics.featureUsage;
    for (const [featureName, count] of Object.entries(features)) {
      db.run(
        `
                INSERT INTO feature_usage (installation_id, feature_name, usage_count, last_used)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(installation_id, feature_name) DO UPDATE SET
                    usage_count = excluded.usage_count,
                    last_used = excluded.last_used
            `,
        [data.id, featureName, count, now],
      );
    }
  }

  res.json({ success: true, message: 'Telemetry received' });
});

/**
 * GET /api/stats - получить общую статистику (для веб-панели)
 */
app.get('/api/stats', (req, res) => {
  const stats = {};

  // Общее количество инсталляций
  db.get('SELECT COUNT(*) as total FROM installations', (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    stats.totalInstallations = row.total;

    // Активные за последние 7 дней
    const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    db.get(
      'SELECT COUNT(*) as active FROM installations WHERE last_seen > ?',
      [weekAgo],
      (err, row) => {
        stats.activeInstallations = row.active;

        // Средние значения
        db.get(
          `
                SELECT 
                    AVG(printers_current) as avg_printers,
                    AVG(printers_max) as avg_max_printers,
                    SUM(printers_klipper) as total_klipper,
                    SUM(printers_bambu) as total_bambu,
                    AVG(sessions_total) as avg_sessions,
                    SUM(analytics_views) as total_analytics_views,
                    SUM(exports_count) as total_exports,
                    SUM(CASE WHEN current_theme = 'light' THEN 1 ELSE 0 END) as light_theme_users,
                    SUM(CASE WHEN current_theme = 'dark' THEN 1 ELSE 0 END) as dark_theme_users,
                    SUM(CASE WHEN web_server_enabled = 1 THEN 1 ELSE 0 END) as web_server_users,
                    AVG(total_uptime_seconds) as avg_uptime_seconds,
                    SUM(smart_plugs_total) as total_smart_plugs,
                    SUM(smart_plugs_tuya) as tuya_plugs,
                    SUM(smart_plugs_ha) as ha_plugs,
                    SUM(automations_enabled) as automations_enabled,
                    SUM(batch_adds_count) as batch_adds,
                    SUM(network_scans_count) as network_scans,
                    AVG(avg_batch_size) as avg_batch_size,
                    MAX(max_nozzle_temp) as max_nozzle_temp,
                    MAX(max_bed_temp) as max_bed_temp,
                    MAX(max_mcu_temp) as max_mcu_temp,
                    SUM(overheating_events) as overheating_events,
                    SUM(successful_prints) as successful_prints,
                    SUM(print_errors) as print_errors,
                    SUM(emergency_shutdowns) as emergency_shutdowns,
                    SUM(manual_plug_toggles) as manual_plug_toggles,
                    SUM(webserver_starts) as webserver_starts,
                    SUM(analytics_opens) as analytics_opens,
                    SUM(help_pages_opened) as help_pages_opens
                FROM installations
            `,
          (err, row) => {
            stats.avgPrinters = Math.round(row.avg_printers * 10) / 10;
            stats.avgMaxPrinters = Math.round(row.avg_max_printers * 10) / 10;
            stats.totalKlipper = row.total_klipper;
            stats.totalBambu = row.total_bambu;
            stats.avgSessions = Math.round(row.avg_sessions);
            stats.totalAnalyticsViews = row.total_analytics_views;
            stats.totalExports = row.total_exports;
            stats.lightThemeUsers = row.light_theme_users || 0;
            stats.darkThemeUsers = row.dark_theme_users || 0;
            stats.webServerUsers = row.web_server_users || 0;
            stats.avgUptimeHours = Math.round(((row.avg_uptime_seconds || 0) / 3600) * 10) / 10;

            // === НОВЫЕ МЕТРИКИ v1.5.36 ===
            stats.totalSmartPlugs = row.total_smart_plugs || 0;
            stats.tuyaPlugs = row.tuya_plugs || 0;
            stats.haPlugs = row.ha_plugs || 0;
            stats.automationsEnabled = row.automations_enabled || 0;
            stats.batchAdds = row.batch_adds || 0;
            stats.networkScans = row.network_scans || 0;
            stats.avgBatchSize = Math.round((row.avg_batch_size || 0) * 10) / 10;
            stats.maxNozzleTemp = row.max_nozzle_temp || 0;
            stats.maxBedTemp = row.max_bed_temp || 0;
            stats.maxMCUTemp = row.max_mcu_temp || 0;
            stats.overheatingEvents = row.overheating_events || 0;
            stats.successfulPrints = row.successful_prints || 0;
            stats.printErrors = row.print_errors || 0;
            stats.emergencyShutdowns = row.emergency_shutdowns || 0;
            stats.manualPlugToggles = row.manual_plug_toggles || 0;
            stats.webServerStarts = row.webserver_starts || 0;
            stats.analyticsOpens = row.analytics_opens || 0;
            stats.helpPagesOpens = row.help_pages_opens || 0;

            // Распределение по версиям
            db.all(
              'SELECT version, COUNT(*) as count FROM installations GROUP BY version ORDER BY count DESC',
              (err, rows) => {
                stats.versionDistribution = rows;

                // Распределение по платформам
                db.all(
                  'SELECT platform, COUNT(*) as count FROM installations GROUP BY platform',
                  (err, rows) => {
                    stats.platformDistribution = rows;

                    // Распределение по локалям/странам
                    db.all(
                      'SELECT locale, COUNT(*) as count FROM installations WHERE locale IS NOT NULL GROUP BY locale ORDER BY count DESC',
                      (err, rows) => {
                        stats.localeDistribution = rows;

                        // Распределение по странам (GeoIP)
                        db.all(
                          'SELECT country, COUNT(*) as count FROM installations WHERE country IS NOT NULL GROUP BY country ORDER BY count DESC',
                          (err, rows) => {
                            stats.countryDistribution = rows;

                            // Топ функций
                            db.all(
                              `
                                    SELECT feature_name, SUM(usage_count) as total_usage
                                    FROM feature_usage
                                    GROUP BY feature_name
                                    ORDER BY total_usage DESC
                                    LIMIT 20
                                `,
                              (err, rows) => {
                                stats.topFeatures = rows;

                                // Распределение по количеству принтеров
                                db.all(
                                  `
                                        SELECT 
                                            printers_current, 
                                            COUNT(*) as count,
                                            SUM(CASE WHEN smart_plugs_total > 0 THEN 1 ELSE 0 END) as with_smart_plugs
                                        FROM installations
                                        WHERE printers_current > 0
                                        GROUP BY printers_current
                                        ORDER BY printers_current
                                    `,
                                  (err, rows) => {
                                    stats.printersDistribution = rows;

                                    // Добавляем статистику лицензий
                                    db.get(
                                      `
                                            SELECT 
                                                COUNT(*) as total_licenses,
                                                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_licenses,
                                                SUM(CASE WHEN plan = 'trial' AND status = 'active' THEN 1 ELSE 0 END) as trial_licenses,
                                                SUM(CASE WHEN plan = 'professional' AND status = 'active' THEN 1 ELSE 0 END) as professional_licenses
                                            FROM licenses
                                        `,
                                      (err, licenseRow) => {
                                        if (!err && licenseRow) {
                                          stats.totalLicenses = licenseRow.total_licenses;
                                          stats.activeLicenses = licenseRow.active_licenses;
                                          stats.trialLicenses = licenseRow.trial_licenses;
                                          stats.professionalLicenses =
                                            licenseRow.professional_licenses;
                                        } else {
                                          stats.totalLicenses = 0;
                                          stats.activeLicenses = 0;
                                          stats.trialLicenses = 0;
                                          // stats.standardLicenses = 0; // удален
                                          stats.professionalLicenses = 0;
                                        }

                                        res.json(stats);
                                      },
                                    );
                                  },
                                );
                              },
                            );
                          },
                        );
                      },
                    );
                  },
                );
              },
            );
          },
        );
      },
    );
  });
});

/**
 * GET /api/installations - список всех инсталляций
 */
app.get('/api/installations', (req, res) => {
  db.all(
    `
        SELECT 
            id, version, platform, arch, locale, country, ip_address,
            datetime(install_date/1000, 'unixepoch') as install_date,
            datetime(first_seen/1000, 'unixepoch') as first_seen,
            datetime(last_seen/1000, 'unixepoch') as last_seen,
            sessions_total, printers_current, printers_max,
            printers_klipper, printers_bambu,
            analytics_views, exports_count
        FROM installations
        ORDER BY last_seen DESC
        LIMIT 1000
    `,
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    },
  );
});

// ============================================================================
// WEB INTERFACE
// ============================================================================

/**
 * GET / - API info (protected by IP)
 */
app.get('/', webInterfaceAuth, (req, res) => {
  res.json({
    name: '📊 3D Printer Control Panel - Telemetry API',
    version: '1.0.0',
    endpoints: {
      'POST /api/telemetry': 'Send telemetry data',
      'POST /api/session': 'Update session data',
      'GET /api/stats': 'Get statistics',
      'GET /api/installations': 'Get installations',
      'GET /dashboard': 'Web dashboard',
    },
    dashboard: 'https://tomich.fun/admin → Telemetry',
    note: 'API access on port 3000. Dashboard embedded in admin panel.',
  });
});

/**
 * GET /dashboard - Web dashboard (protected by IP)
 */
app.get('/dashboard', webInterfaceAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

/**
 * GET /licensing - страница управления лицензиями (защищена middleware)
 */
app.get('/licensing', webInterfaceAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'licensing.html'));
});

/**
 * GET /bot-admin - админка Telegram Bot (защищена middleware)
 */
app.get('/bot-admin', webInterfaceAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'bot-admin.html'));
});

/**
 * GET /licensing-docs - документация системы лицензирования (защищена middleware)
 */
app.get('/licensing-docs', webInterfaceAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'licensing-docs.html'));
});

/**
 * POST /api/bot/config - сохранение настроек бота
 */
app.post('/api/bot/config', webInterfaceAuth, (req, res) => {
  try {
    const { botToken, adminId, ownerName, notificationChannel } = req.body;

    // adminId обязателен, botToken - только если еще не настроен
    if (!adminId) {
      return res.status(400).json({ error: 'Missing Admin ID' });
    }

    // Если токен не передан, используем существующий из env
    const finalBotToken = botToken || process.env.TELEGRAM_BOT_TOKEN;

    if (!finalBotToken) {
      return res.status(400).json({ error: 'Bot Token required (not configured yet)' });
    }

    // Путь к .env файлу
    const envPath = path.join(__dirname, '.env');

    // Читаем существующий .env или создаем новый
    let envContent = '';
    try {
      envContent = fs.readFileSync(envPath, 'utf8');
    } catch (error) {
      // Файл не существует, создадим новый
      envContent = '';
    }

    // Обновляем или добавляем переменные
    const lines = envContent.split('\n');
    const updatedLines = [];
    const updates = {
      TELEGRAM_BOT_TOKEN: false,
      ADMIN_TELEGRAM_ID: false,
      OWNER_NAME: false,
      NOTIFICATION_CHANNEL_ID: false,
    };

    lines.forEach((line) => {
      if (line.startsWith('TELEGRAM_BOT_TOKEN=')) {
        updatedLines.push(`TELEGRAM_BOT_TOKEN=${finalBotToken}`);
        updates.TELEGRAM_BOT_TOKEN = true;
      } else if (line.startsWith('ADMIN_TELEGRAM_ID=')) {
        updatedLines.push(`ADMIN_TELEGRAM_ID=${adminId}`);
        updates.ADMIN_TELEGRAM_ID = true;
      } else if (line.startsWith('OWNER_NAME=')) {
        if (ownerName) {
          updatedLines.push(`OWNER_NAME=${ownerName}`);
          updates.OWNER_NAME = true;
        }
      } else if (line.startsWith('NOTIFICATION_CHANNEL_ID=')) {
        if (notificationChannel) {
          updatedLines.push(`NOTIFICATION_CHANNEL_ID=${notificationChannel}`);
          updates.NOTIFICATION_CHANNEL_ID = true;
        }
      } else if (line.trim() !== '') {
        updatedLines.push(line);
      }
    });

    // Добавляем если не было
    if (!updates.TELEGRAM_BOT_TOKEN) {
      updatedLines.push(`TELEGRAM_BOT_TOKEN=${finalBotToken}`);
    }
    if (!updates.ADMIN_TELEGRAM_ID) {
      updatedLines.push(`ADMIN_TELEGRAM_ID=${adminId}`);
    }
    if (!updates.OWNER_NAME && ownerName) {
      updatedLines.push(`OWNER_NAME=${ownerName}`);
    }
    if (!updates.NOTIFICATION_CHANNEL_ID && notificationChannel) {
      updatedLines.push(`NOTIFICATION_CHANNEL_ID=${notificationChannel}`);
    }

    // Добавляем остальные обязательные переменные если их нет
    if (!envContent.includes('LICENSE_ENCRYPTION_KEY=')) {
      updatedLines.push('LICENSE_ENCRYPTION_KEY=bWci5vMAFrQV4CqxYKHTu72139tXP8pG');
    }
    if (!envContent.includes('ADMIN_TOKEN=')) {
      updatedLines.push('ADMIN_TOKEN=telemetry-secret-2024');
    }
    if (!envContent.includes('PORT=')) {
      updatedLines.push('PORT=3000');
    }

    // Сохраняем файл
    fs.writeFileSync(envPath, updatedLines.join('\n') + '\n', 'utf8');

    // Обновляем переменные окружения в памяти
    process.env.TELEGRAM_BOT_TOKEN = finalBotToken;
    process.env.ADMIN_TELEGRAM_ID = adminId;
    if (ownerName) process.env.OWNER_NAME = ownerName;
    if (notificationChannel) process.env.NOTIFICATION_CHANNEL_ID = notificationChannel;

    console.log('[Bot Config] Settings saved to .env and environment variables updated');

    // Перезапускаем бота с новыми настройками
    initBot();
    console.log('[Bot Config] Bot reinitialized with new settings');

    res.json({
      success: true,
      message: 'Настройки сохранены и применены! Бот перезапущен с новыми настройками.',
    });
  } catch (error) {
    console.error('[Bot Config] Error:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/bot/config - получение текущих настроек
 */
app.get('/api/bot/config', webInterfaceAuth, (req, res) => {
  try {
    // Возвращаем замаскированные значения для безопасности
    const config = {
      botToken: TELEGRAM_BOT_TOKEN ? TELEGRAM_BOT_TOKEN.substring(0, 10) + '...' : null,
      adminId: ADMIN_TELEGRAM_ID || null,
      ownerName: OWNER_NAME || null,
      notificationChannel: NOTIFICATION_CHANNEL_ID || null,
      botConfigured: !!(TELEGRAM_BOT_TOKEN && ADMIN_TELEGRAM_ID),
    };

    res.json(config);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /api/license/register-hwid - регистрация HWID (при открытии окна лицензирования)
 */
app.post('/api/license/register-hwid', async (req, res) => {
  try {
    const { hwid, platform, version } = req.body;

    if (!hwid) {
      return res.status(400).json({ error: 'Missing HWID' });
    }

    // Сохраняем HWID для последующей связи с Telegram
    const now = Date.now();

    db.run(
      `
            INSERT OR REPLACE INTO hwid_telegram_mapping (hwid, telegram_username, registered_at, last_seen, platform, version)
            VALUES (?, 'pending', COALESCE((SELECT registered_at FROM hwid_telegram_mapping WHERE hwid = ?), ?), ?, ?, ?)
        `,
      [hwid, hwid, now, now, platform, version],
      (err) => {
        if (err) {
          console.error('[HWID] Registration error:', err);
        } else {
          console.log(`[HWID] Registered: ${hwid.substring(0, 16)}...`);
        }
      },
    );

    res.setHeader('Content-Type', 'application/json');
    res.json({ success: true, message: 'HWID registered' });
  } catch (error) {
    console.error('[API] HWID registration error:', error);
    res.setHeader('Content-Type', 'application/json');
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /api/license/request - запрос лицензии от клиента
 */
app.post('/api/license/request', async (req, res) => {
  try {
    const { hwid, plan, email, version, platform } = req.body;

    if (!hwid || !plan) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // === ВАЛИДАЦИЯ HWID ===
    // Проверяем что HWID был зарегистрирован недавно (в последние 10 минут)
    const hwidRecord = await new Promise((resolve, reject) => {
      db.get(
        `
                SELECT * FROM hwid_telegram_mapping 
                WHERE hwid = ? AND last_seen > ?
            `,
        [hwid, Date.now() - 10 * 60 * 1000],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        },
      );
    });

    if (!hwidRecord) {
      console.warn(`[License] Invalid HWID or not registered: ${hwid.substring(0, 16)}...`);
      return res.status(403).json({
        error: 'Invalid HWID. Please open the licensing window in the application first.',
      });
    }

    // Находим Telegram username для этого HWID
    let telegram = 'unknown';

    // Ищем последнего пользователя который писал /start (в последние 10 минут)
    const recentUser = await new Promise((resolve, reject) => {
      db.get(
        `
                SELECT * FROM telegram_users 
                WHERE last_seen > ? 
                ORDER BY last_seen DESC 
                LIMIT 1
            `,
        [Date.now() - 10 * 60 * 1000],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        },
      );
    });

    if (recentUser) {
      telegram = recentUser.telegram_username;

      // Обновляем связь HWID → Telegram
      db.run(
        `
                UPDATE hwid_telegram_mapping 
                SET telegram_username = ?, last_seen = ?
                WHERE hwid = ?
            `,
        [telegram, Date.now(), hwid],
      );
    } else {
      // Telegram не найден - возвращаем ошибку клиенту
      console.warn(`[License] Telegram not found for HWID: ${hwid.substring(0, 16)}...`);
      return res.status(400).json({
        error: `Не удалось определить ваш Telegram username.\n\nВозможные причины:\n\n1️⃣ Вы не написали боту @kcp_licensing_bot команду /start\n2️⃣ У вас не установлен Telegram username\n3️⃣ Прошло больше 10 минут после /start\n\nРешение:\n• Найдите бота @kcp_licensing_bot в Telegram\n• Отправьте команду /start\n• Убедитесь что у вас установлен username (Настройки → Имя пользователя)\n• Повторите запрос лицензии в течение 10 минут\n\nЕсли проблема сохраняется:\n• Свяжитесь с администратором напрямую\n• Telegram: @Tom_Tomich\n• Укажите ваш HWID: ${hwid.substring(0, 24)}...`,
      });
    }

    console.log(
      `[License Request] HWID: ${hwid.substring(0, 16)}..., Plan: ${plan}, Telegram: ${telegram}`,
    );

    // Сохраняем запрос в БД (если есть таблица)
    // TODO: создать таблицу license_requests

    // Для Trial - автоматическая выдача без подтверждения
    if (plan === 'trial' && bot && ADMIN_TELEGRAM_ID) {
      const message = `
🎁 <b>Автоматическая выдача Trial лицензии</b>

<b>План:</b> ${getPlanName(plan)} (бесплатно)
<b>HWID:</b> <code>${hwid.substring(0, 24)}...</code>
<b>Версия:</b> ${version || 'unknown'}

🤖 Ключ будет автоматически сгенерирован и отправлен клиенту.
            `.trim();

      try {
        // Генерируем Trial ключ
        const trialKey = generateTrialKey(hwid);

        // Находим пользователя по HWID (через telegram_users)
        // Для Trial отправляем всем кто писал /start недавно
        db.all(
          `
                    SELECT * FROM telegram_users 
                    WHERE last_seen > ? 
                    ORDER BY last_seen DESC 
                    LIMIT 1
                `,
          [Date.now() - 5 * 60 * 1000],
          async (err, users) => {
            if (users && users.length > 0) {
              const user = users[0];

              await bot.sendMessage(
                user.chat_id,
                `
🎉 <b>Trial лицензия одобрена!</b>

<b>План:</b> ⏱️ Trial (14 дней)
<b>Ключ:</b> <code>${trialKey}</code>

📝 <b>Инструкция:</b>
1. Скопируйте ключ выше
2. Откройте 3DCP
3. Нажмите "🔐 Лицензия" → вкладка "Активация"
4. Вставьте ключ и активируйте

✅ Все функции разблокированы на 14 дней!
                        `,
                { parse_mode: 'HTML' },
              );

              console.log(`[Bot] Trial key sent to ${user.telegram_username}`);
            }
          },
        );

        // Уведомляем админа (БЕЗ ЗВУКА - это бесплатная лицензия)
        const notificationText = message + `\n\n✅ Trial ключ отправлен клиенту автоматически.`;

        await bot.sendMessage(ADMIN_TELEGRAM_ID, notificationText, {
          parse_mode: 'HTML',
          disable_notification: true, // Без звука для бесплатных
        });

        // Дублируем в канал если настроен
        if (NOTIFICATION_CHANNEL_ID) {
          await bot.sendMessage(NOTIFICATION_CHANNEL_ID, notificationText, {
            parse_mode: 'HTML',
            disable_notification: true,
          });
        }
      } catch (error) {
        console.error('[Bot] Trial auto-issue error:', error);
      }
    }
    // Для платных лицензий - отправляем админу на подтверждение
    else if (bot && ADMIN_TELEGRAM_ID) {
      const telegramInfo =
        telegram !== 'unknown'
          ? `<b>Telegram:</b> ${telegram}`
          : `⚠️ <b>Telegram:</b> Не определен (клиент не писал /start)`;

      const message = `
🔐 <b>Новый запрос лицензии!</b>

<b>План:</b> ${getPlanName(plan)}
${telegramInfo}
<b>Email:</b> ${email || 'не указан'}
<b>HWID:</b> <code>${hwid.substring(0, 24)}...</code>
<b>Версия:</b> ${version || 'unknown'}
<b>Платформа:</b> ${platform || 'unknown'}

💬 <b>Следующий шаг:</b> Свяжитесь с клиентом ${telegram !== 'unknown' ? telegram : 'по email'} для уточнения способа оплаты
            `.trim();

      try {
        const keyboard = {
          inline_keyboard: [
            [
              { text: '✅ Оплачено - Выдать ключ', callback_data: `approve_${hwid}_${plan}` },
              { text: '❌ Отклонить', callback_data: `reject_${hwid}` },
            ],
          ],
        };

        // Отправляем админу СО ЗВУКОМ (платная лицензия!)
        await bot.sendMessage(ADMIN_TELEGRAM_ID, message, {
          parse_mode: 'HTML',
          reply_markup: keyboard,
          // disable_notification НЕ указываем - будет со звуком
        });

        // Дублируем в канал если настроен (тоже со звуком для платных)
        if (NOTIFICATION_CHANNEL_ID) {
          await bot.sendMessage(
            NOTIFICATION_CHANNEL_ID,
            message + `\n\n👤 <b>Обрабатывает:</b> ${OWNER_NAME}`,
            {
              parse_mode: 'HTML',
              reply_markup: keyboard,
            },
          );
        }

        console.log('[Bot] Admin notified about license request (with sound)');
      } catch (error) {
        console.error('[Bot] Failed to notify admin:', error);
      }
    }

    res.json({
      success: true,
      message:
        'Запрос отправлен администратору! Ожидайте ключ в Telegram после согласования оплаты.',
      hwid: hwid,
    });
  } catch (error) {
    console.error('[API] License request error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API endpoint для получения конкретной лицензии (для редактирования)
app.get('/api/license/:id', webInterfaceAuth, (req, res) => {
  try {
    const licenseId = req.params.id;

    db.get(
      `
            SELECT 
                l.license_key as id,
                l.license_key,
                l.hwid,
                l.plan,
                l.status,
                l.created_at,
                l.expires_at,
                l.admin_notes,
                htm.telegram_username
            FROM licenses l
            LEFT JOIN hwid_telegram_mapping htm ON l.hwid = htm.hwid
            WHERE l.license_key = ?
        `,
      [licenseId],
      (err, license) => {
        if (err) {
          console.error('[License Get] DB error:', err.message);
          return res.status(500).json({ error: 'Database error' });
        }

        if (!license) {
          return res.status(404).json({ error: 'License not found' });
        }

        res.json(license);
      },
    );
  } catch (error) {
    console.error('[License Get] Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// API endpoint для обновления лицензии
app.put('/api/license/:id', webInterfaceAuth, (req, res) => {
  try {
    const licenseId = req.params.id;
    const { plan, telegram_username, status, expires_at } = req.body;

    // Валидация данных
    const validPlans = ['free', 'trial', 'professional'];
    const validStatuses = ['active', 'pending', 'expired'];

    if (plan && !validPlans.includes(plan)) {
      return res.status(400).json({ error: 'Invalid plan' });
    }

    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    // Подготавливаем поля для обновления
    const updateFields = [];
    const updateValues = [];

    if (plan !== undefined) {
      updateFields.push('plan = ?');
      updateValues.push(plan);
    }

    if (status !== undefined) {
      updateFields.push('status = ?');
      updateValues.push(status);
    }

    if (expires_at !== undefined) {
      updateFields.push('expires_at = ?');
      updateValues.push(expires_at);
    }

    if (updateFields.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    updateValues.push(licenseId);

    db.run(
      `
            UPDATE licenses 
            SET ${updateFields.join(', ')}
            WHERE license_key = ?
        `,
      updateValues,
      function (err) {
        if (err) {
          console.error('[License Update] DB error:', err.message);
          return res.status(500).json({ error: 'Database error' });
        }

        if (this.changes === 0) {
          return res.status(404).json({ error: 'License not found' });
        }

        // Обновляем telegram username в hwid_telegram_mapping если нужно
        if (telegram_username !== undefined) {
          db.run(
            `
                    UPDATE hwid_telegram_mapping 
                    SET telegram_username = ?
                    WHERE hwid = (SELECT hwid FROM licenses WHERE license_key = ?)
                `,
            [telegram_username, licenseId],
            (err) => {
              if (err) {
                console.error('[License Update] Telegram mapping error:', err.message);
              }
            },
          );
        }

        res.json({ success: true, message: 'License updated successfully' });
      },
    );
  } catch (error) {
    console.error('[License Update] Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// API endpoint для удаления лицензии
app.delete('/api/license/:id', webInterfaceAuth, (req, res) => {
  try {
    const licenseId = req.params.id;

    db.run(
      `
            DELETE FROM licenses 
            WHERE license_key = ?
        `,
      [licenseId],
      function (err) {
        if (err) {
          console.error('[License Delete] DB error:', err.message);
          return res.status(500).json({ error: 'Database error' });
        }

        if (this.changes === 0) {
          return res.status(404).json({ error: 'License not found' });
        }

        res.json({ success: true, message: 'License deleted successfully' });
      },
    );
  } catch (error) {
    console.error('[License Delete] Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

function getPlanName(plan) {
  const names = {
    trial: '⏱️ Trial (14 дней)',
    // 'standard': '💎 Standard (удален)' // удален,
    professional: '👑 Professional',
  };
  return names[plan] || plan;
}

/**
 * Генерирует Trial лицензионный ключ
 */
function generateTrialKey(hwid) {
  const now = Date.now();
  const expiresAt = now + 14 * 24 * 60 * 60 * 1000; // 14 дней

  // Создаем payload
  const payload = JSON.stringify({
    hwid: hwid,
    plan: 'trial',
    created: now,
    expires: expiresAt,
  });

  // Простое шифрование для Trial (можем использовать LICENSE_ENCRYPTION_KEY)
  const hash = crypto
    .createHash('sha256')
    .update(payload + LICENSE_ENCRYPTION_KEY)
    .digest('hex');

  // Форматируем в 3DCP-XXXX-XXXX-...
  const key =
    '3DCP-' +
    hash
      .substring(0, 20)
      .toUpperCase()
      .match(/.{1,4}/g)
      .join('-');

  return key;
}

/**
 * POST /api/bot/clear-database - очистка базы данных (для тестирования)
 */
app.post('/api/bot/clear-database', webInterfaceAuth, (req, res) => {
  try {
    console.log('[Bot] Database clear requested via web interface');

    // Очищаем все таблицы
    const tablesToClear = [
      'licenses',
      'license_requests',
      'hwid_telegram_mapping',
      'telegram_users',
      'installations',
      'feature_usage',
    ];

    let clearedCount = 0;
    let totalTables = tablesToClear.length;

    tablesToClear.forEach((table) => {
      db.run(`DELETE FROM ${table}`, (err) => {
        if (err && !err.message.includes('no such table')) {
          console.error(`[Bot] Error clearing table ${table}:`, err.message);
        } else {
          console.log(`[Bot] Table ${table} cleared`);
          clearedCount++;
        }
      });
    });

    res.json({
      success: true,
      message: `База данных очищена! Очищено ${clearedCount}/${totalTables} таблиц. Готово для тестирования.`,
      clearedTables: clearedCount,
    });
  } catch (error) {
    console.error('[Bot] Database clear error:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /api/bot/restart - перезапуск сервера через PM2
 */
app.post('/api/bot/restart', webInterfaceAuth, (req, res) => {
  try {
    res.json({
      success: true,
      message: 'Сервер перезапускается...',
    });

    console.log('[Bot] Server restart requested via web interface');

    // Перезапускаем через 1 секунду (чтобы успеть отправить ответ)
    setTimeout(() => {
      const { exec } = require('child_process');
      exec('pm2 restart 3dpc-telemetry --update-env', (error, stdout, stderr) => {
        if (error) {
          console.error('[Bot] Restart error:', error);
        } else {
          console.log('[Bot] Server restarted successfully');
        }
      });
    }, 1000);
  } catch (error) {
    console.error('[Bot] Restart error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Обработка ошибок
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Запуск сервера
app.listen(PORT, () => {
  console.log(`
    ┌─────────────────────────────────────────────┐
    │  📊 Telemetry Server                        │
    │                                             │
    │  🌐 Server:  http://localhost:${PORT}       │
    │  📡 API:     http://localhost:${PORT}/api   │
    │  📁 Database: ${dbPath}                     │
    │                                             │
    │  🔒 No auth - access from admin panel only  │
    │  🌐 https://tomich.fun/admin                │
    └─────────────────────────────────────────────┘
    `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing database...');
  db.close(() => {
    console.log('Database closed');
    process.exit(0);
  });
});
