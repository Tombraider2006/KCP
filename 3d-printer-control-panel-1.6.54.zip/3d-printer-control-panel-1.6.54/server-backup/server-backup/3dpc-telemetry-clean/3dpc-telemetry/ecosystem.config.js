module.exports = {
  apps: [
    {
      name: '3dpc-telemetry',
      script: './server.js',
      env: {
        PORT: 3000,
        ADMIN_USER: 'tom',
        ADMIN_PASSWORD: 'tolik123',
        NODE_ENV: 'production',
      },
    },
  ],
};
