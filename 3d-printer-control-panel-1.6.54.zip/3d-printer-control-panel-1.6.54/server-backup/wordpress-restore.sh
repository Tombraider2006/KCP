#!/bin/bash
# WordPress Restore Script
# Восстанавливает WordPress из бекапа (файлы + база данных)

set -e  # Остановка при ошибке

BACKUP_DIR="/opt/wordpress-backups"
WP_CONTAINER="wordpress-wordpress-1"

# Проверяем аргументы
if [ -z "$1" ]; then
    echo "Usage: $0 <backup-file.tar.gz>"
    echo ""
    echo "Available backups:"
    ls -lh ${BACKUP_DIR}/wordpress-backup_*.tar.gz 2>/dev/null || echo "No backups found"
    exit 1
fi

BACKUP_FILE="$1"

# Проверяем, что файл существует
if [ ! -f "${BACKUP_FILE}" ]; then
    # Пробуем найти в BACKUP_DIR
    if [ -f "${BACKUP_DIR}/${BACKUP_FILE}" ]; then
        BACKUP_FILE="${BACKUP_DIR}/${BACKUP_FILE}"
    else
        echo "Error: Backup file not found: $1"
        exit 1
    fi
fi

# Проверяем, что контейнер запущен
if ! docker ps --format '{{.Names}}' | grep -q "^${WP_CONTAINER}$"; then
    echo "Error: WordPress container '${WP_CONTAINER}' is not running"
    echo "Please start the container first: docker start ${WP_CONTAINER}"
    exit 1
fi

# Находим контейнер с MySQL
DB_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i mysql | head -1)
if [ -z "${DB_CONTAINER}" ]; then
    DB_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i db | head -1)
fi

if [ -z "${DB_CONTAINER}" ]; then
    echo "Error: MySQL container not found"
    exit 1
fi

TEMP_DIR=$(mktemp -d)
echo "Extracting backup to ${TEMP_DIR}..."

# Распаковываем архив
tar -xzf "${BACKUP_FILE}" -C "${TEMP_DIR}"
EXTRACTED_DIR=$(find "${TEMP_DIR}" -type d -name "wordpress-backup_*" | head -1)

if [ -z "${EXTRACTED_DIR}" ]; then
    echo "Error: Could not find backup directory in archive"
    rm -rf "${TEMP_DIR}"
    exit 1
fi

echo "=========================================="
echo "WordPress Restore Started"
echo "Date: $(date)"
echo "Backup file: ${BACKUP_FILE}"
echo "=========================================="

# ВАЖНО: Предупреждение перед восстановлением
echo ""
echo "⚠️  WARNING: This will replace current WordPress files and database!"
echo "Press Ctrl+C within 10 seconds to cancel..."
sleep 10

# 1. Восстанавливаем файлы wp-content
if [ -f "${EXTRACTED_DIR}/wp-content.tar.gz" ]; then
    echo ""
    echo "[1/3] Restoring WordPress files..."
    docker cp "${EXTRACTED_DIR}/wp-content.tar.gz" ${WP_CONTAINER}:/tmp/wp-content-backup.tar.gz
    docker exec ${WP_CONTAINER} bash -c "cd /var/www/html && rm -rf wp-content && tar -xzf /tmp/wp-content-backup.tar.gz && chown -R www-data:www-data wp-content && rm -f /tmp/wp-content-backup.tar.gz"
    echo "✓ WordPress files restored"
else
    echo "✗ Warning: wp-content.tar.gz not found in backup"
fi

# 2. Восстанавливаем базу данных
if [ -f "${EXTRACTED_DIR}/database.sql.gz" ]; then
    echo ""
    echo "[2/3] Restoring database..."
    
    # Получаем параметры подключения к БД из wp-config (более надежный парсинг)
    DB_NAME=$(docker exec ${WP_CONTAINER} php -r "require '/var/www/html/wp-config.php'; echo DB_NAME;" 2>/dev/null || echo "wordpress")
    DB_USER=$(docker exec ${WP_CONTAINER} php -r "require '/var/www/html/wp-config.php'; echo DB_USER;" 2>/dev/null || echo "wordpress")
    DB_PASS=$(docker exec ${WP_CONTAINER} php -r "require '/var/www/html/wp-config.php'; echo DB_PASSWORD;" 2>/dev/null || echo "")
    
    # Распаковываем дамп
    gunzip -c "${EXTRACTED_DIR}/database.sql.gz" > "${TEMP_DIR}/database.sql"
    
    # Восстанавливаем базу данных
    docker exec -i ${DB_CONTAINER} mysql -u${DB_USER} -p${DB_PASS} ${DB_NAME} < "${TEMP_DIR}/database.sql" 2>/dev/null || \
    docker exec -e MYSQL_PWD=${DB_PASS} -i ${DB_CONTAINER} mysql -u${DB_USER} ${DB_NAME} < "${TEMP_DIR}/database.sql"
    
    rm -f "${TEMP_DIR}/database.sql"
    echo "✓ Database restored (${DB_NAME})"
elif [ -f "${EXTRACTED_DIR}/database.sql" ]; then
    echo ""
    echo "[2/3] Restoring database (uncompressed)..."
    DB_NAME=$(docker exec ${WP_CONTAINER} grep -E "^define\s*\(\s*['\"]DB_NAME" /var/www/html/wp-config.php | sed "s/.*['\"]\([^'\"]*\)['\"].*/\1/" || echo "wordpress")
    DB_USER=$(docker exec ${WP_CONTAINER} grep -E "^define\s*\(\s*['\"]DB_USER" /var/www/html/wp-config.php | sed "s/.*['\"]\([^'\"]*\)['\"].*/\1/" || echo "wordpress")
    DB_PASS=$(docker exec ${WP_CONTAINER} grep -E "^define\s*\(\s*['\"]DB_PASSWORD" /var/www/html/wp-config.php | sed "s/.*['\"]\([^'\"]*\)['\"].*/\1/" || echo "")
    
    docker exec -i ${DB_CONTAINER} mysql -u${DB_USER} -p${DB_PASS} ${DB_NAME} < "${EXTRACTED_DIR}/database.sql" 2>/dev/null || \
    docker exec -e MYSQL_PWD=${DB_PASS} -i ${DB_CONTAINER} mysql -u${DB_USER} ${DB_NAME} < "${EXTRACTED_DIR}/database.sql"
    
    echo "✓ Database restored (${DB_NAME})"
else
    echo "✗ Warning: database.sql.gz not found in backup"
fi

# 3. Восстанавливаем wp-config.php (опционально, по запросу)
if [ -f "${EXTRACTED_DIR}/wp-config.php" ]; then
    echo ""
    echo "[3/3] wp-config.php found in backup"
    read -p "Restore wp-config.php? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        docker cp "${EXTRACTED_DIR}/wp-config.php" ${WP_CONTAINER}:/var/www/html/wp-config.php.backup
        echo "✓ wp-config.php copied to /var/www/html/wp-config.php.backup"
        echo "  (Manual restore required - check if database credentials match)"
    fi
fi

# Очистка
rm -rf "${TEMP_DIR}"

# Перезапуск контейнера для применения изменений
echo ""
echo "Restarting WordPress container..."
docker restart ${WP_CONTAINER}
sleep 5

echo ""
echo "=========================================="
echo "Restore completed successfully!"
echo "WordPress container restarted"
echo "=========================================="
echo ""
echo "⚠️  IMPORTANT: Check your WordPress site to ensure everything works correctly!"
echo "   URL: https://tomich.fun"

