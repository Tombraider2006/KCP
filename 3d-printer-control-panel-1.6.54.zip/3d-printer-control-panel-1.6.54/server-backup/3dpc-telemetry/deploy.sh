#!/bin/bash
# Скрипт для загрузки файлов на сервер и запуска установки
# Использование: bash deploy.sh root@your-server-ip

set -e

if [ -z "$1" ]; then
    echo "❌ Укажите сервер"
    echo "Использование: bash deploy.sh root@your-server-ip"
    exit 1
fi

SERVER=$1

echo "================================================"
echo "  📤 Загрузка файлов на сервер"
echo "  Сервер: $SERVER"
echo "================================================"
echo ""

# Проверка подключения
echo "🔍 Проверка подключения к серверу..."
echo "Попытка подключения (может запросить пароль)..."
if ! ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=no $SERVER "echo 'OK'" 2>/dev/null; then
    echo "❌ Не удалось подключиться к серверу"
    echo ""
    echo "Проверьте:"
    echo "  1. IP адрес правильный?"
    echo "  2. Сервер включен и доступен?"
    echo "  3. SSH порт открыт (обычно 22)?"
    echo ""
    echo "Попробуйте подключиться вручную:"
    echo "  ssh $SERVER"
    echo ""
    exit 1
fi
echo "✅ Подключение успешно"

echo ""
echo "📦 Упаковка файлов..."
cd "$(dirname "$0")"
tar -czf /tmp/telemetry-deploy.tar.gz \
    server.js \
    package.json \
    public/ \
    install.sh \
    INSTALLATION.md

echo "✅ Файлы упакованы"

echo ""
echo "📤 Загрузка на сервер..."
scp /tmp/telemetry-deploy.tar.gz $SERVER:/tmp/

echo "✅ Файлы загружены"

echo ""
echo "📂 Распаковка на сервере..."
ssh $SERVER << 'ENDSSH'
mkdir -p /opt/3dpc-telemetry
cd /opt/3dpc-telemetry
tar -xzf /tmp/telemetry-deploy.tar.gz
rm /tmp/telemetry-deploy.tar.gz
chmod +x install.sh
echo "✅ Файлы распакованы в /opt/3dpc-telemetry"
ENDSSH

echo ""
echo "================================================"
echo "  ✅ Файлы загружены на сервер!"
echo "================================================"
echo ""
echo "📝 Следующий шаг:"
echo ""
echo "  Подключитесь к серверу и запустите установку:"
echo "  $ ssh $SERVER"
echo "  $ cd /opt/3dpc-telemetry"
echo "  $ sudo bash install.sh"
echo ""
echo "Или выполните автоматически:"
echo "  $ ssh $SERVER 'cd /opt/3dpc-telemetry && sudo bash install.sh'"
echo ""

