#!/bin/bash
# Скрипт миграции серверной части на Yarn
# Использование: bash migrate-to-yarn.sh
# Запускать на сервере в директории /opt/3dpc-telemetry/

set -e

echo "================================================"
echo "  📦 Миграция серверной части на Yarn"
echo "================================================"
echo ""

# Проверка прав root
if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  Рекомендуется запустить с sudo для некоторых операций"
fi

INSTALL_DIR="/opt/3dpc-telemetry"
cd "$INSTALL_DIR" || {
    echo "❌ Директория $INSTALL_DIR не найдена"
    echo "Запустите скрипт из директории /opt/3dpc-telemetry/"
    exit 1
}

echo "📋 Текущая директория: $(pwd)"
echo ""

# Проверка Node.js
echo "🔍 Проверка Node.js..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js не установлен"
    exit 1
fi

NODE_VERSION=$(node --version)
echo "✅ Node.js: $NODE_VERSION"

if [[ $(node -p "process.version.match(/^v(\d+)/)[1]") -lt 18 ]]; then
    echo "⚠️  Внимание: Node.js версии меньше 18. Рекомендуется обновить до 18+"
fi

# Проверка и установка Yarn
echo ""
echo "🔍 Проверка Yarn..."
if ! command -v yarn &> /dev/null; then
    echo "⚠️  Yarn не найден, включаем Corepack..."
    if command -v corepack &> /dev/null; then
        corepack enable
        echo "✅ Corepack активирован"
    else
        echo "❌ Corepack не найден. Установите Node.js 16+ с Corepack"
        exit 1
    fi
fi

YARN_VERSION=$(yarn --version 2>/dev/null || echo "не установлен")
echo "✅ Yarn: $YARN_VERSION"

# Остановка PM2
echo ""
echo "🛑 Остановка PM2..."
if command -v pm2 &> /dev/null; then
    pm2 stop 3dpc-telemetry 2>/dev/null || echo "⚠️  Процесс 3dpc-telemetry не запущен"
    echo "✅ PM2 остановлен"
else
    echo "⚠️  PM2 не найден, пропускаем остановку"
fi

# Создание бэкапа
echo ""
echo "💾 Создание бэкапа..."
if [ -f "package-lock.json" ]; then
    cp package-lock.json package-lock.json.backup
    echo "✅ Бэкап package-lock.json создан"
fi

if [ -d "node_modules" ]; then
    BACKUP_DIR="node_modules_backup_$(date +%Y%m%d_%H%M%S)"
    mv node_modules "$BACKUP_DIR" 2>/dev/null || true
    echo "✅ node_modules перемещен в $BACKUP_DIR"
fi

# Удаление старых файлов
echo ""
echo "🗑️  Удаление старых файлов..."
rm -f package-lock.json
echo "✅ package-lock.json удален"

# Проверка наличия yarn.lock
if [ ! -f "yarn.lock" ]; then
    echo "❌ yarn.lock не найден! Убедитесь, что файл загружен на сервер"
    exit 1
fi

echo "✅ yarn.lock найден"

# Проверка наличия обновленного package.json
if [ ! -f "package.json" ]; then
    echo "❌ package.json не найден!"
    exit 1
fi

if ! grep -q '"packageManager": "yarn@4.0.0"' package.json; then
    echo "⚠️  package.json не содержит packageManager. Добавляем..."
    # Это временное решение - лучше загрузить обновленный файл
    echo "⚠️  Пожалуйста, убедитесь, что package.json содержит \"packageManager\": \"yarn@4.0.0\""
fi

# Установка зависимостей
echo ""
echo "📦 Установка зависимостей через Yarn..."
yarn install --production --frozen-lockfile
echo "✅ Зависимости установлены"

# Проверка работы приложения
echo ""
echo "🧪 Проверка работы приложения..."
echo "Запускаем временный тест (прервите через Ctrl+C после проверки)..."
echo ""
echo "⚠️  ВНИМАНИЕ: Приложение запустится в тестовом режиме"
echo "Нажмите Ctrl+C после проверки, чтобы продолжить миграцию"
echo ""
read -p "Продолжить с тестовым запуском? (y/n) " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Запуск теста через 3 секунды..."
    sleep 3
    
    # Запуск в фоне для теста
    timeout 10 node server.js || echo "✅ Сервер запустился (прерван по таймауту)"
    echo ""
    echo "✅ Тестовый запуск завершен"
else
    echo "⏭️  Пропущен тестовый запуск"
fi

# Запуск через PM2
echo ""
echo "🚀 Запуск через PM2..."
if command -v pm2 &> /dev/null; then
    pm2 start server.js --name 3dpc-telemetry --update-env
    pm2 save
    echo "✅ Приложение запущено через PM2"
    
    echo ""
    echo "📊 Статус PM2:"
    pm2 status
    
    echo ""
    echo "📝 Последние логи (10 строк):"
    pm2 logs 3dpc-telemetry --lines 10 --nostream
else
    echo "⚠️  PM2 не найден. Запустите приложение вручную: yarn start"
fi

# Проверка доступности
echo ""
echo "🔍 Проверка доступности сервера..."
sleep 2
if curl -s http://localhost:3000/ > /dev/null 2>&1; then
    echo "✅ Сервер отвечает на http://localhost:3000/"
else
    echo "⚠️  Сервер не отвечает. Проверьте логи: pm2 logs 3dpc-telemetry"
fi

echo ""
echo "================================================"
echo "  ✅ Миграция на Yarn завершена!"
echo "================================================"
echo ""
echo "📝 Следующие шаги:"
echo "  1. Проверьте работу админ-панели в браузере"
echo "  2. Проверьте Telegram бота (если настроен)"
echo "  3. Мониторьте логи: pm2 logs 3dpc-telemetry"
echo ""
echo "💾 Бэкапы:"
if [ -f "package-lock.json.backup" ]; then
    echo "  - package-lock.json.backup"
fi
if [ -d "node_modules_backup"* ]; then
    echo "  - node_modules_backup_*"
    echo ""
    echo "⚠️  Старые бэкапы можно удалить через 24 часа, если всё работает стабильно:"
    echo "    rm -rf node_modules_backup_*"
fi
echo ""

