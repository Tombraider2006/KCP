# 🚀 Быстрая установка для Windows

## Вариант 1: Ручная загрузка (самый простой) ⭐

### Шаг 1: Создайте архив

```powershell
# В PowerShell
cd D:\3DC\server-telemetry
Compress-Archive -Path * -DestinationPath ..\telemetry.zip -Force
```

Архив создан: `D:\3DC\telemetry.zip`

### Шаг 2: Загрузите архив на сервер

**Через WinSCP:**

1. Скачайте WinSCP: https://winscp.net/
2. Подключитесь к серверу (введите IP, логин root, пароль)
3. Перейдите в папку `/tmp/`
4. Перетащите файл `telemetry.zip` в эту папку

**Или через командную строку (если есть scp):**

```bash
scp D:\3DC\telemetry.zip root@YOUR_SERVER_IP:/tmp/
```

### Шаг 3: Подключитесь к серверу через Putty

1. Скачайте Putty: https://www.putty.org/
2. Введите IP сервера
3. Нажмите Open
4. Войдите как root с паролем

### Шаг 4: Распакуйте и установите

Выполните на сервере:

```bash
# Создайте папку
mkdir -p /opt/3dpc-telemetry

# Распакуйте
cd /opt/3dpc-telemetry
unzip /tmp/telemetry.zip

# Сделайте скрипт исполняемым
chmod +x install.sh

# Запустите установку
sudo bash install.sh
```

Следуйте инструкциям скрипта!

---

## Вариант 2: Git (если проект в репозитории)

### На сервере выполните:

```bash
# Установите git (если нет)
apt install -y git

# Клонируйте репозиторий
git clone https://github.com/your-username/your-repo.git /tmp/3dc

# Скопируйте файлы
mkdir -p /opt/3dpc-telemetry
cp -r /tmp/3dc/server-telemetry/* /opt/3dpc-telemetry/

# Установите
cd /opt/3dpc-telemetry
chmod +x install.sh
sudo bash install.sh
```

---

## Вариант 3: Прямое копирование (если есть доступ к серверу)

Если у вас есть доступ к файловой системе сервера:

1. Откройте проводник Windows
2. В адресной строке введите: `\\YOUR_SERVER_IP\share`
3. Скопируйте папку `server-telemetry`
4. Через Putty выполните установку

---

## Вариант 4: Использование Git Bash / WSL

Если у вас установлен Git Bash или WSL:

```bash
# В Git Bash или WSL
cd /mnt/d/3DC/server-telemetry  # или /d/3DC/server-telemetry в Git Bash

# Попробуйте снова
bash deploy.sh root@YOUR_SERVER_IP
```

---

## ❓ Частые проблемы

### Проблема: SSH не работает из Windows

**Решение:** Используйте Вариант 1 (WinSCP + Putty)

### Проблема: "Permission denied"

**Решение:** Проверьте:

```bash
# На сервере проверьте SSH
systemctl status ssh

# Проверьте файрвол
ufw status
ufw allow 22/tcp
```

### Проблема: Не знаю IP сервера

**Решение:** На сервере выполните:

```bash
ip addr show
# или
curl ifconfig.me
```

---

## 📋 Быстрый чеклист

- [ ] Создал архив telemetry.zip
- [ ] Загрузил на сервер в /tmp/
- [ ] Подключился к серверу через Putty
- [ ] Распаковал архив в /opt/3dpc-telemetry
- [ ] Запустил `sudo bash install.sh`
- [ ] Ввел домен, порт, логин, пароль
- [ ] Открыл веб-панель в браузере
- [ ] Проверил что все работает

---

## 🎯 Самый простой путь

1. **WinSCP** - загрузка файлов
2. **Putty** - подключение к серверу
3. **`sudo bash install.sh`** - автоустановка
4. **Готово!** 🎉

---

## 💡 Нужна помощь?

Предоставьте:

- IP адрес сервера
- Операционная система сервера
- Есть ли SSH доступ (можете подключиться через Putty?)

И я дам точные команды!
