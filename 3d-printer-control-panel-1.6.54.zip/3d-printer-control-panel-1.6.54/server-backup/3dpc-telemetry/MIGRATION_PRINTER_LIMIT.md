# Миграция: Добавление поля printer_limit

## Что изменилось

Добавлено поле `printer_limit` в таблицу лицензий для контроля количества принтеров в лицензии.

## Миграция базы данных

После обновления кода на сервере выполните SQL миграцию:

```sql
-- Добавить поле printer_limit в таблицу licenses
ALTER TABLE licenses ADD COLUMN printer_limit INTEGER DEFAULT 10;

-- Добавить поле printer_limit в таблицу license_requests
ALTER TABLE license_requests ADD COLUMN printer_limit INTEGER DEFAULT 10;

-- Обновить существующие лицензии (опционально)
-- FREE: 10 принтеров
UPDATE licenses SET printer_limit = 10 WHERE plan = 'free' AND printer_limit IS NULL;

-- TRIAL: 50 принтеров
UPDATE licenses SET printer_limit = 50 WHERE plan = 'trial' AND printer_limit IS NULL;

-- PROFESSIONAL: 100 принтеров (или любое другое значение)
UPDATE licenses SET printer_limit = 100 WHERE plan = 'professional' AND printer_limit IS NULL;
```

## Как выполнить миграцию на сервере

### Вариант 1: Через SSH

```bash
ssh root@tomich.fun
cd /opt/3dpc-telemetry
sqlite3 telemetry.db < migration.sql
```

### Вариант 2: Ручная миграция

```bash
ssh root@tomich.fun
cd /opt/3dpc-telemetry
sqlite3 telemetry.db

-- В интерактивном режиме SQLite:
ALTER TABLE licenses ADD COLUMN printer_limit INTEGER DEFAULT 10;
ALTER TABLE license_requests ADD COLUMN printer_limit INTEGER DEFAULT 10;

-- Проверить что поле добавлено:
PRAGMA table_info(licenses);
.exit
```

## Деплой обновлённого кода

```bash
# Локально (из папки проекта)
scp server-backup/3dpc-telemetry/server.js root@tomich.fun:/opt/3dpc-telemetry/

# На сервере
ssh root@tomich.fun
cd /opt/3dpc-telemetry
pm2 restart server

# Проверить логи
pm2 logs server
```

## Изменения в работе бота

**При одобрении лицензии админ теперь:**

1. Нажимает "✅ Одобрить"
2. Бот спрашивает: "Введите количество принтеров (1-999)"
3. Админ вводит число (например, `20`)
4. Бот генерирует ключ с указанным лимитом

**Автоматические лимиты по умолчанию:**

- FREE: 10 принтеров
- TRIAL: 50 принтеров (автовыдача)
- PROFESSIONAL: зависит от ввода админа

## Проверка работы

### Тест API активации:

```bash
curl -X POST http://tomich.fun:3000/api/license/activate \
  -H "Content-Type: application/json" \
  -d '{
    "key": "3DCP-XXXX-XXXX-XXXX-XXXX-XXXX",
    "hwid": "test-hwid-123"
  }'
```

Ответ должен содержать `printerLimit`:

```json
{
  "success": true,
  "plan": "professional",
  "expiresAt": 1730419200000,
  "printerLimit": 20,
  "message": "Лицензия успешно активирована!"
}
```

## Откат миграции (если что-то пошло не так)

```sql
-- SQLite не поддерживает DROP COLUMN напрямую
-- Нужно пересоздавать таблицу без этого поля (сложно)
-- Проще восстановить из бэкапа

-- Но можно обнулить значения:
UPDATE licenses SET printer_limit = NULL;
UPDATE license_requests SET printer_limit = NULL;
```

**Рекомендация:** Создайте бэкап БД перед миграцией:

```bash
ssh root@tomich.fun
cd /opt/3dpc-telemetry
cp telemetry.db telemetry.db.backup-$(date +%Y%m%d-%H%M%S)
```
