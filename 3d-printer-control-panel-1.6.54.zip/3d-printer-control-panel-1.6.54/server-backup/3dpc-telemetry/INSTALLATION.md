# 🚀 Установка Telemetry Server

## Требования

- ✅ Сервер с Linux (Ubuntu 20.04+ / Debian 10+)
- ✅ Node.js 18+ и yarn (через Corepack)
- ✅ Root доступ
- ✅ Открытый порт (по умолчанию 3000)
- ✅ Доменное имя (опционально, но рекомендуется)

---

## 📦 Шаг 1: Подготовка сервера

### Подключитесь к серверу:

```bash
ssh root@your-server-ip
```

### Обновите систему:

```bash
apt update && apt upgrade -y
```

### Установите Node.js 18:

```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs
node --version  # Проверка
corepack enable  # Включаем Yarn через Corepack
```

### Установите PM2 (менеджер процессов):

```bash
yarn global add pm2
```

---

## 📁 Шаг 2: Установка приложения

### Создайте директорию:

```bash
mkdir -p /opt/3dpc-telemetry
cd /opt/3dpc-telemetry
```

### Скопируйте файлы на сервер:

**Вариант A - Через SFTP/SCP:**
Скопируйте всю папку `server-telemetry` на сервер:

```bash
# На локальной машине:
scp -r server-telemetry/* root@your-server-ip:/opt/3dpc-telemetry/
```

**Вариант B - Через Git:**

```bash
# Создайте репозиторий и загрузите туда server-telemetry
# Затем на сервере:
git clone your-repo-url .
```

### Установите зависимости:

```bash
cd /opt/3dpc-telemetry
yarn install --production
```

---

## 🔐 Шаг 3: Настройка безопасности

### Создайте .env файл:

```bash
nano .env
```

Добавьте:

```env
PORT=3000
ADMIN_USER=your_admin_username
ADMIN_PASSWORD=your_strong_password_here
NODE_ENV=production
```

**⚠️ ВАЖНО: Используйте сильный пароль!**

### Защитите файл:

```bash
chmod 600 .env
```

### Обновите server.js для использования .env:

```bash
nano server.js
```

В начале файла добавьте:

```javascript
require('dotenv').config();
```

Установите dotenv:

```bash
yarn add dotenv
```

---

## 🚀 Шаг 4: Запуск сервера

### Запустите через PM2:

```bash
pm2 start server.js --name 3dpc-telemetry
```

### Настройте автозапуск при перезагрузке:

```bash
pm2 startup
pm2 save
```

### Проверьте статус:

```bash
pm2 status
pm2 logs 3dpc-telemetry
```

---

## 🌐 Шаг 5: Настройка Nginx (рекомендуется)

### Установите Nginx:

```bash
apt install -y nginx
```

### Создайте конфигурацию:

```bash
nano /etc/nginx/sites-available/telemetry
```

Добавьте:

```nginx
server {
    listen 80;
    server_name telemetry.yourdomain.com;  # Замените на ваш домен

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Активируйте конфигурацию:

```bash
ln -s /etc/nginx/sites-available/telemetry /etc/nginx/sites-enabled/
nginx -t  # Проверка конфигурации
systemctl reload nginx
```

---

## 🔒 Шаг 6: SSL (HTTPS)

### Установите Certbot:

```bash
apt install -y certbot python3-certbot-nginx
```

### Получите SSL сертификат:

```bash
certbot --nginx -d telemetry.yourdomain.com
```

Certbot автоматически настроит HTTPS.

### Автообновление сертификата:

```bash
certbot renew --dry-run
```

---

## 🔥 Шаг 7: Настройка файрвола

### Установите UFW:

```bash
apt install -y ufw
```

### Настройте правила:

```bash
ufw allow ssh
ufw allow http
ufw allow https
ufw enable
ufw status
```

---

## 🎯 Шаг 8: Настройка приложения

### Откройте файл telemetry.js в вашем приложении:

```javascript
// В src/telemetry.js измените URL:
this.config = {
  serverUrl: 'https://telemetry.yourdomain.com/api/telemetry',
  // или
  serverUrl: 'http://your-server-ip:3000/api/telemetry',
};
```

### Пересоберите приложение:

```bash
yarn run build
```

---

## 📊 Доступ к панели

Откройте в браузере:

- **С доменом:** https://telemetry.yourdomain.com
- **С IP:** http://your-server-ip:3000

Войдите с логином и паролем из .env файла.

---

## 🔧 Полезные команды

### PM2:

```bash
pm2 list                    # Список процессов
pm2 logs 3dpc-telemetry    # Логи
pm2 restart 3dpc-telemetry # Перезапуск
pm2 stop 3dpc-telemetry    # Остановка
pm2 delete 3dpc-telemetry  # Удаление
pm2 monit                  # Мониторинг
```

### Nginx:

```bash
systemctl status nginx     # Статус
systemctl reload nginx     # Перезагрузка
systemctl restart nginx    # Перезапуск
nginx -t                   # Проверка конфигурации
tail -f /var/log/nginx/error.log  # Логи ошибок
```

### База данных:

```bash
sqlite3 /opt/3dpc-telemetry/telemetry.db
# Внутри sqlite:
.tables                    # Список таблиц
.schema installations      # Структура таблицы
SELECT COUNT(*) FROM installations;  # Количество записей
.quit                      # Выход
```

---

## 🔄 Обновление

```bash
cd /opt/3dpc-telemetry
# Скопируйте новые файлы или git pull
yarn install
pm2 restart 3dpc-telemetry
```

---

## 🐛 Отладка

### Проверьте логи:

```bash
pm2 logs 3dpc-telemetry --lines 100
```

### Проверьте порт:

```bash
netstat -tulpn | grep 3000
```

### Проверьте процесс:

```bash
ps aux | grep node
```

### Тест API вручную:

```bash
curl -X POST http://localhost:3000/api/telemetry \
  -H "Content-Type: application/json" \
  -d '{"id":"test","version":"1.0.0","metrics":{}}'
```

---

## 📈 Мониторинг

### Настройте мониторинг PM2:

```bash
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 7
```

### Опционально - PM2 Plus (бесплатный мониторинг):

```bash
pm2 link your-secret-key your-public-key
```

Зарегистрируйтесь на: https://app.pm2.io

---

## 💾 Бэкапы

### Бэкап базы данных:

```bash
# Создайте скрипт бэкапа:
nano /opt/3dpc-telemetry/backup.sh
```

```bash
#!/bin/bash
BACKUP_DIR="/opt/3dpc-telemetry/backups"
mkdir -p $BACKUP_DIR
DATE=$(date +%Y%m%d_%H%M%S)
cp /opt/3dpc-telemetry/telemetry.db $BACKUP_DIR/telemetry_$DATE.db
# Удаляем старые бэкапы (старше 30 дней)
find $BACKUP_DIR -name "telemetry_*.db" -mtime +30 -delete
echo "Backup created: telemetry_$DATE.db"
```

```bash
chmod +x /opt/3dpc-telemetry/backup.sh
```

### Автоматический бэкап (cron):

```bash
crontab -e
```

Добавьте:

```cron
# Бэкап каждый день в 3:00
0 3 * * * /opt/3dpc-telemetry/backup.sh
```

---

## 🎉 Готово!

Ваш telemetry сервер настроен и работает!

### Проверьте:

1. ✅ Сервер запущен: `pm2 status`
2. ✅ Веб-панель доступна: `curl http://localhost:3000`
3. ✅ API работает
4. ✅ Nginx проксирует запросы
5. ✅ SSL настроен (если используете домен)
6. ✅ Файрвол настроен

### Следующие шаги:

1. Обновите URL в приложении (src/telemetry.js)
2. Пересоберите и выпустите новую версию
3. Мониторьте статистику на веб-панели
4. Анализируйте данные для Free/Pro разделения

---

## 📞 Поддержка

Если что-то не работает:

1. Проверьте логи: `pm2 logs`
2. Проверьте порты: `netstat -tulpn | grep 3000`
3. Проверьте файрвол: `ufw status`
4. Проверьте nginx: `nginx -t && systemctl status nginx`

---

**Автор:** 3D Printer Control Panel Team  
**Версия:** 1.0.0  
**Дата:** 2025-10-10
