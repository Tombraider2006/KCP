'use strict';

const BaseError = require('../errors/BaseError');

function errorHandler(err, req, res, _next) {
  const isKnown = err instanceof BaseError;
  const status = isKnown ? err.statusCode : 500;

  if (!isKnown) {
    // eslint-disable-next-line no-console
    console.error('[UnhandledError]', err);
  }

  const payload = {
    error: isKnown ? err.name : 'InternalServerError',
    message: err.message || 'Internal server error',
  };
  if (isKnown && err.details) payload.details = err.details;

  res.status(status).json(payload);
}

module.exports = errorHandler;
