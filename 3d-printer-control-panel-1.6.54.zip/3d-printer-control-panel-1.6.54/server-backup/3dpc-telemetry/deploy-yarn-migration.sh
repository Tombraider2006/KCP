#!/bin/bash
# Скрипт для загрузки файлов миграции на Yarn на сервер
# Использование: bash deploy-yarn-migration.sh root@tomich.fun

set -e

if [ -z "$1" ]; then
    echo "❌ Укажите сервер"
    echo "Использование: bash deploy-yarn-migration.sh root@tomich.fun"
    exit 1
fi

SERVER=$1

echo "================================================"
echo "  📤 Загрузка файлов миграции на Yarn"
echo "  Сервер: $SERVER"
echo "================================================"
echo ""

# Проверка подключения
echo "🔍 Проверка подключения к серверу..."
if ! ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=no $SERVER "echo 'OK'" 2>/dev/null; then
    echo "❌ Не удалось подключиться к серверу"
    exit 1
fi
echo "✅ Подключение успешно"

echo ""
echo "📦 Упаковка файлов миграции..."
cd "$(dirname "$0")"

# Проверка наличия необходимых файлов
if [ ! -f "yarn.lock" ]; then
    echo "❌ yarn.lock не найден! Выполните yarn install локально сначала"
    exit 1
fi

if [ ! -f "package.json" ]; then
    echo "❌ package.json не найден!"
    exit 1
fi

# Создаем архив с файлами для миграции
tar -czf /tmp/yarn-migration.tar.gz \
    package.json \
    yarn.lock \
    server.js \
    migrate-to-yarn.sh \
    public/ \
    2>/dev/null

echo "✅ Файлы упакованы"

echo ""
echo "📤 Загрузка на сервер..."
scp /tmp/yarn-migration.tar.gz $SERVER:/tmp/
echo "✅ Файлы загружены"

echo ""
echo "📂 Распаковка на сервере..."
ssh $SERVER << 'ENDSSH'
cd /opt/3dpc-telemetry
echo "📦 Распаковка файлов миграции..."
tar -xzf /tmp/yarn-migration.tar.gz
rm /tmp/yarn-migration.tar.gz
chmod +x migrate-to-yarn.sh
echo "✅ Файлы распакованы в /opt/3dpc-telemetry"
echo ""
echo "📋 Загруженные файлы:"
ls -lh package.json yarn.lock migrate-to-yarn.sh server.js 2>/dev/null || true
ENDSSH

echo ""
echo "================================================"
echo "  ✅ Файлы миграции загружены на сервер!"
echo "================================================"
echo ""
echo "📝 Следующий шаг:"
echo ""
echo "  Подключитесь к серверу и запустите миграцию:"
echo "  $ ssh $SERVER"
echo "  $ cd /opt/3dpc-telemetry"
echo "  $ sudo bash migrate-to-yarn.sh"
echo ""
echo "Или выполните автоматически:"
echo "  $ ssh $SERVER 'cd /opt/3dpc-telemetry && sudo bash migrate-to-yarn.sh'"
echo ""

