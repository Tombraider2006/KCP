'use strict';

const fs = require('fs');
const path = require('path');

const DEFAULT_LOCALE = 'ru';
const localesDir = path.join(__dirname, '..', 'locales');

function loadLocale(locale) {
  const filePath = path.join(localesDir, `${locale}.json`);
  try {
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw);
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn(`[i18n] Fallback to default locale due to: ${e.message}`);
    const raw = fs.readFileSync(path.join(localesDir, `${DEFAULT_LOCALE}.json`), 'utf-8');
    return JSON.parse(raw);
  }
}

const dict = loadLocale(DEFAULT_LOCALE);

function interpolate(template, vars) {
  if (!vars) return template;
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => {
    return Object.prototype.hasOwnProperty.call(vars, key) ? String(vars[key]) : '';
  });
}

function t(key, vars) {
  const segments = key.split('.');
  let ref = dict;
  for (const seg of segments) {
    if (ref && Object.prototype.hasOwnProperty.call(ref, seg)) {
      ref = ref[seg];
    } else {
      ref = null;
      break;
    }
  }
  if (typeof ref !== 'string') return key; // fallback to key
  return interpolate(ref, vars);
}

module.exports = { t };
