#!/usr/bin/env node

/**
 * Скрипт для очистки базы данных лицензирования
 * Использование: node clear-database.js
 */

const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'telemetry.db');
const db = new sqlite3.Database(dbPath);

console.log('🗑️  Очистка базы данных лицензирования...\n');

// Список таблиц для очистки
const tablesToClear = [
  'licenses',
  'license_requests',
  'hwid_telegram_mapping',
  'telegram_users',
  'installations',
  'feature_usage',
];

let clearedTables = 0;

function clearTable(tableName) {
  return new Promise((resolve, reject) => {
    db.run(`DELETE FROM ${tableName}`, (err) => {
      if (err) {
        if (err.message.includes('no such table')) {
          console.log(`✅ Таблица ${tableName} не существует (пропущена)`);
          resolve();
        } else {
          console.error(`❌ Ошибка очистки таблицы ${tableName}:`, err.message);
          reject(err);
        }
      } else {
        console.log(`✅ Таблица ${tableName} очищена`);
        resolve();
      }
    });
  });
}

async function clearAllTables() {
  try {
    for (const table of tablesToClear) {
      await clearTable(table);
      clearedTables++;
    }

    console.log(`\n🎉 Успешно очищено ${clearedTables} таблиц!`);
    console.log('\n📋 База данных готова для тестирования:');
    console.log('• Все лицензии удалены');
    console.log('• Все запросы лицензий удалены');
    console.log('• Все HWID-Telegram связи удалены');
    console.log('• Все пользователи Telegram удалены');
    console.log('• Вся телеметрия удалена');
    console.log('\n🚀 Теперь можете тестировать функционал с чистого листа!');
  } catch (error) {
    console.error('\n❌ Ошибка при очистке базы данных:', error.message);
    process.exit(1);
  } finally {
    db.close();
  }
}

// Запускаем очистку
clearAllTables();
