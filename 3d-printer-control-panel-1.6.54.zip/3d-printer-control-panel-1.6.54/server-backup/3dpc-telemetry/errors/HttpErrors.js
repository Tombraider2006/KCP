'use strict';

const BaseError = require('./BaseError');

class ValidationError extends BaseError {
  constructor(message = 'Validation error', details) {
    super(message, 400, details);
  }
}

class UnauthorizedError extends BaseError {
  constructor(message = 'Unauthorized') {
    super(message, 401);
  }
}

class ForbiddenError extends BaseError {
  constructor(message = 'Forbidden') {
    super(message, 403);
  }
}

class NotFoundError extends BaseError {
  constructor(message = 'Not found') {
    super(message, 404);
  }
}

class DatabaseError extends BaseError {
  constructor(message = 'Database error', details) {
    super(message, 500, details);
  }
}

module.exports = {
  ValidationError,
  UnauthorizedError,
  ForbiddenError,
  NotFoundError,
  DatabaseError,
};
