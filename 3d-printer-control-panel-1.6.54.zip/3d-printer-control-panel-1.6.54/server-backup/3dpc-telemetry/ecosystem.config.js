module.exports = {
  apps: [
    {
      name: '3dpc-telemetry',
      script: './server.js',
      instances: 1,
      exec_mode: 'fork',
      max_memory_restart: '200M',
      restart_delay: 5000,
      max_restarts: 1000,
      min_uptime: '10s',
      kill_timeout: 5000,
      env: {
        PORT: 3000,
        ADMIN_USER: 'tom',
        ADMIN_PASSWORD: 'tolik123',
        NODE_ENV: 'production',
      },
      error_file: './logs/error.log',
      out_file: './logs/out.log',
      log_file: './logs/combined.log',
      time: true,
    },
  ],
};
