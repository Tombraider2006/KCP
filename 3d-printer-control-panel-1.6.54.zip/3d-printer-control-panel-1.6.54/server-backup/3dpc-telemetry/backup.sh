#!/bin/bash
BACKUP_DIR="/opt/3dpc-telemetry/backups"
mkdir -p $BACKUP_DIR
DATE=$(date +%Y%m%d_%H%M%S)
cp /opt/3dpc-telemetry/telemetry.db $BACKUP_DIR/telemetry_$DATE.db
find $BACKUP_DIR -name "telemetry_*.db" -mtime +30 -delete
echo "Backup created: telemetry_$DATE.db"
