# 📦 Инструкции по миграции на Yarn на продакшн-сервере

**Дата:** 03.11.2025  
**Версия:** 1.0

---

## 🚀 Быстрый способ (автоматический)

### Шаг 1: Загрузите файлы на сервер

**На локальной машине выполните:**

```bash
cd server-backup/3dpc-telemetry
bash deploy-yarn-migration.sh root@tomich.fun
```

Скрипт автоматически:

- ✅ Упакует файлы (package.json, yarn.lock, server.js, migrate-to-yarn.sh)
- ✅ Загрузит на сервер через SCP
- ✅ Распакует в `/opt/3dpc-telemetry`

### Шаг 2: Выполните миграцию на сервере

**Подключитесь к серверу:**

```bash
ssh root@tomich.fun
cd /opt/3dpc-telemetry
sudo bash migrate-to-yarn.sh
```

Скрипт автоматически:

- ✅ Проверит Node.js и Yarn
- ✅ Остановит PM2
- ✅ Создаст бэкапы
- ✅ Удалит package-lock.json и node_modules
- ✅ Установит зависимости через yarn
- ✅ Запустит приложение через PM2
- ✅ Проверит работу сервера

---

## 🔧 Альтернативный способ (ручной)

Если автоматический скрипт не работает, выполните миграцию вручную:

### Шаг 1: Загрузите файлы на сервер

**На локальной машине:**

```bash
cd server-backup/3dpc-telemetry

# Создайте архив
tar -czf yarn-migration.tar.gz \
    package.json \
    yarn.lock \
    server.js \
    public/

# Загрузите на сервер
scp yarn-migration.tar.gz root@tomich.fun:/tmp/
```

### Шаг 2: Подключитесь к серверу

```bash
ssh root@tomich.fun
```

### Шаг 3: Выполните миграцию

```bash
# Перейдите в директорию приложения
cd /opt/3dpc-telemetry

# Распакуйте файлы
tar -xzf /tmp/yarn-migration.tar.gz
rm /tmp/yarn-migration.tar.gz

# Проверьте Node.js (должна быть версия 18+)
node --version

# Проверьте/включите Yarn
yarn --version || corepack enable

# Остановите PM2
pm2 stop 3dpc-telemetry

# Создайте бэкап package-lock.json (если есть)
[ -f package-lock.json ] && cp package-lock.json package-lock.json.backup

# Удалите старые файлы
rm -f package-lock.json
rm -rf node_modules

# Убедитесь, что yarn.lock загружен
ls -lh yarn.lock package.json

# Установите зависимости через Yarn
yarn install --production --frozen-lockfile

# Проверьте работу (опционально, прервите через Ctrl+C)
yarn start &
sleep 5
curl http://localhost:3000/ || echo "Сервер не отвечает"
pkill -f "node server.js" || true

# Запустите через PM2
pm2 start server.js --name 3dpc-telemetry --update-env
pm2 save

# Проверьте статус
pm2 status
pm2 logs 3dpc-telemetry --lines 20
```

---

## ✅ Проверка работы

После миграции проверьте:

### 1. Статус PM2

```bash
pm2 status
pm2 logs 3dpc-telemetry --lines 50
```

### 2. Доступность сервера

```bash
curl http://localhost:3000/
```

### 3. Админ-панель в браузере

Откройте:

- http://telemetry.tomich.fun:3000/?token=telemetry-secret-2024
- Проверьте работу всех разделов

### 4. Telegram бот (если настроен)

- Отправьте `/start` боту
- Проверьте работу команд

---

## 🐛 Решение проблем

### Проблема: Yarn не найден

```bash
# Включите Corepack (встроен в Node.js 16+)
corepack enable
yarn --version
```

### Проблема: package-lock.json создается заново

```bash
# Убедитесь, что package.json содержит:
# "packageManager": "yarn@4.0.0"

# Удалите package-lock.json
rm -f package-lock.json

# Добавьте в .gitignore (если используется Git)
echo "package-lock.json" >> .gitignore
```

### Проблема: PM2 не запускает приложение

```bash
# Проверьте логи
pm2 logs 3dpc-telemetry --lines 100

# Перезапустите PM2
pm2 restart 3dpc-telemetry

# Проверьте, что файлы на месте
ls -lh server.js package.json yarn.lock
```

### Проблема: Зависимости не устанавливаются

```bash
# Очистите кэш Yarn
yarn cache clean

# Удалите node_modules и установите заново
rm -rf node_modules
yarn install --production
```

### Проблема: Откат к npm

```bash
# Если нужно откатиться к npm (не рекомендуется)
cd /opt/3dpc-telemetry
pm2 stop 3dpc-telemetry
rm -rf node_modules yarn.lock
cp package-lock.json.backup package-lock.json  # если есть бэкап
npm install --production
pm2 start server.js --name 3dpc-telemetry --update-env
```

---

## 📊 Файлы для загрузки

При миграции необходимо загрузить на сервер:

1. ✅ `package.json` - с полем `"packageManager": "yarn@4.0.0"`
2. ✅ `yarn.lock` - файл блокировки зависимостей
3. ✅ `server.js` - обновленный с комментариями yarn
4. ✅ `migrate-to-yarn.sh` - скрипт миграции (опционально)
5. ✅ `public/` - публичные файлы (если изменены)

---

## ⚠️ Важные замечания

1. **Бэкапы:** Скрипт создает бэкапы `package-lock.json` и `node_modules`. Храните их минимум 24 часа для возможности отката.

2. **Время простоя:** Приложение будет недоступно на время миграции (~2-5 минут).

3. **PM2:** После миграции убедитесь, что PM2 запущен и работает стабильно.

4. **Мониторинг:** После миграции проверяйте логи в течение первых 24 часов на предмет ошибок.

---

## 📝 Чеклист миграции

- [ ] Загружены файлы на сервер (package.json, yarn.lock, server.js)
- [ ] Выполнена миграция через скрипт или вручную
- [ ] PM2 запущен и работает
- [ ] Сервер отвечает на http://localhost:3000/
- [ ] Админ-панель работает в браузере
- [ ] Telegram бот работает (если настроен)
- [ ] Логи не показывают ошибок
- [ ] Стабильная работа минимум 24 часа

---

## ✅ Миграция завершена

После успешной миграции:

1. **Удалите старые бэкапы** (через 24-48 часов, если всё работает стабильно):

   ```bash
   rm -f package-lock.json.backup
   rm -rf node_modules_backup_*
   ```

2. **Обновите документацию** на сервере (если есть):
   - Замените упоминания `npm install` на `yarn install`
   - Обновите скрипты установки

3. **Сообщите команде** о завершении миграции

---

**Вопросы?** Проверьте логи: `pm2 logs 3dpc-telemetry`
