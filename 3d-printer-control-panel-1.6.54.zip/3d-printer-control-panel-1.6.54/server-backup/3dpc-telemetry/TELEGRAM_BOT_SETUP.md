# 🤖 Настройка Telegram Bot (3 минуты)

## Быстрая настройка

### 1. Создайте бота (1 минута)

Откройте Telegram → найдите **@BotFather** → отправьте:

```
/newbot
```

Введите:

- **Имя:** KCP Licensing Bot
- **Username:** kcp_licensing_bot (или любой свободный)

**Скопируйте токен!** Формат: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`

### 2. Получите ваш Telegram ID (30 секунд)

Найдите **@userinfobot** → отправьте:

```
/start
```

**Скопируйте ID!** Формат: `123456789`

### 3. Обновите .env на сервере (1 минута)

```bash
ssh root@tomich.fun
nano /opt/3dpc-telemetry/.env
```

Создайте файл с содержимым:

```env
TELEGRAM_BOT_TOKEN=ваш_токен_от_BotFather
ADMIN_TELEGRAM_ID=ваш_id_от_userinfobot
LICENSE_ENCRYPTION_KEY=bWci5vMAFrQV4CqxYKHTu72139tXP8pG
ADMIN_TOKEN=telemetry-secret-2024
PORT=3000
```

Сохраните: `Ctrl+O`, Enter, `Ctrl+X`

### 4. Перезапустите сервер (10 секунд)

```bash
pm2 restart 3dpc-telemetry
pm2 logs 3dpc-telemetry --lines 20
```

Должны увидеть:

```
✅ Telegram Bot initialized for licensing
```

### 5. Проверка (10 секунд)

Найдите вашего бота в Telegram → отправьте `/start`

Должен ответить приветствием!

---

## ✅ Готово!

Теперь:

- Бот автоматически отправляет ключи клиентам
- Вам приходят уведомления о запросах
- Админка: http://telemetry.tomich.fun:3000/licensing?token=telemetry-secret-2024

---

## Если что-то не работает

### Ошибка: "Telegram Bot not configured"

Проверьте .env файл:

```bash
cat /opt/3dpc-telemetry/.env
```

Убедитесь что TELEGRAM_BOT_TOKEN и ADMIN_TELEGRAM_ID заполнены.

### Бот не отвечает

Проверьте логи:

```bash
pm2 logs 3dpc-telemetry --lines 50
```

Ищите строку с ошибкой про Telegram.

### Перезапуск с обновлением переменных

```bash
pm2 restart 3dpc-telemetry --update-env
```
