#!/bin/bash
# WordPress Backup Script
# Создает полный бекап WordPress: файлы + база данных

set -e  # Остановка при ошибке

BACKUP_DIR="/opt/wordpress-backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="wordpress-backup_${DATE}"
BACKUP_PATH="${BACKUP_DIR}/${BACKUP_NAME}"

# Создаем директорию для бекапов
mkdir -p "${BACKUP_PATH}"

echo "=========================================="
echo "WordPress Backup Started"
echo "Date: $(date)"
echo "Backup location: ${BACKUP_PATH}"
echo "=========================================="

# 1. Бекап файлов WordPress (wp-content)
echo ""
echo "[1/2] Backing up WordPress files..."
WP_CONTAINER="wordpress-wordpress-1"
if docker ps --format '{{.Names}}' | grep -q "^${WP_CONTAINER}$"; then
    # Создаем архив wp-content из контейнера
    docker exec ${WP_CONTAINER} tar -czf /tmp/wp-content-backup.tar.gz -C /var/www/html wp-content
    docker cp ${WP_CONTAINER}:/tmp/wp-content-backup.tar.gz "${BACKUP_PATH}/wp-content.tar.gz"
    docker exec ${WP_CONTAINER} rm -f /tmp/wp-content-backup.tar.gz
    echo "✓ WordPress files backed up"
else
    echo "✗ Warning: WordPress container '${WP_CONTAINER}' not found, skipping files backup"
fi

# 2. Бекап базы данных MySQL
echo ""
echo "[2/2] Backing up MySQL database..."
DB_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i mysql | head -1)
if [ -z "${DB_CONTAINER}" ]; then
    DB_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i db | head -1)
fi

if [ -n "${DB_CONTAINER}" ]; then
    # Получаем параметры подключения к БД из wp-config (более надежный парсинг)
    DB_NAME=$(docker exec ${WP_CONTAINER} php -r "require '/var/www/html/wp-config.php'; echo DB_NAME;" 2>/dev/null || echo "wordpress")
    DB_USER=$(docker exec ${WP_CONTAINER} php -r "require '/var/www/html/wp-config.php'; echo DB_USER;" 2>/dev/null || echo "wordpress")
    DB_PASS=$(docker exec ${WP_CONTAINER} php -r "require '/var/www/html/wp-config.php'; echo DB_PASSWORD;" 2>/dev/null || echo "")
    
    # Создаем дамп базы данных (используем переменную окружения для пароля)
    docker exec -e MYSQL_PWD="${DB_PASS}" ${DB_CONTAINER} mysqldump -u"${DB_USER}" "${DB_NAME}" > "${BACKUP_PATH}/database.sql" 2>&1
    
    # Проверяем, что дамп создан и не пустой
    if [ -f "${BACKUP_PATH}/database.sql" ] && [ -s "${BACKUP_PATH}/database.sql" ]; then
        # Сжимаем дамп
        gzip -f "${BACKUP_PATH}/database.sql"
        echo "✓ Database backed up (${DB_NAME})"
    else
        echo "✗ Warning: Database dump failed or empty"
        rm -f "${BACKUP_PATH}/database.sql"
    fi
else
    echo "✗ Warning: MySQL container not found, skipping database backup"
fi

# 3. Бекап wp-config.php
echo ""
echo "[3/3] Backing up wp-config.php..."
if docker ps --format '{{.Names}}' | grep -q "^${WP_CONTAINER}$"; then
    docker cp ${WP_CONTAINER}:/var/www/html/wp-config.php "${BACKUP_PATH}/wp-config.php" 2>/dev/null || echo "✗ Warning: Could not backup wp-config.php"
    echo "✓ wp-config.php backed up"
fi

# 4. Создаем архив всего бекапа
echo ""
echo "Creating final archive..."
cd "${BACKUP_DIR}"
tar -czf "${BACKUP_NAME}.tar.gz" "${BACKUP_NAME}/"
rm -rf "${BACKUP_NAME}"
echo "✓ Archive created: ${BACKUP_NAME}.tar.gz"

# 5. Сохраняем информацию о бекапе
cat > "${BACKUP_DIR}/latest-backup.info" <<EOF
BACKUP_DATE=${DATE}
BACKUP_NAME=${BACKUP_NAME}
BACKUP_FILE=${BACKUP_NAME}.tar.gz
BACKUP_PATH=${BACKUP_DIR}/${BACKUP_NAME}.tar.gz
EOF

# 6. Удаляем старые бекапы (старше 30 дней)
echo ""
echo "Cleaning up old backups (older than 30 days)..."
find "${BACKUP_DIR}" -name "wordpress-backup_*.tar.gz" -mtime +30 -delete
echo "✓ Old backups cleaned"

echo ""
echo "=========================================="
echo "Backup completed successfully!"
echo "Archive: ${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"
echo "Size: $(du -h "${BACKUP_DIR}/${BACKUP_NAME}.tar.gz" | cut -f1)"
echo "=========================================="

