// translations.js

// ============================================================================
// PRICING CONFIGURATION - ЦЕНТРАЛИЗОВАННОЕ УПРАВЛЕНИЕ ЦЕНАМИ
// ============================================================================
// Изменяйте только здесь - автоматически применится во всех переводах!
const PRICING_CONFIG = {
  RU: {
    // STANDARD: { price: '2990 ₽', period: '3 месяца' }, // удален
    PROFESSIONAL: { price: '9990 ₽', period: '1 год' },
  },
  EN: {
    // STANDARD: { price: '$29', period: '3 months' }, // удален
    PROFESSIONAL: { price: '$99', period: '1 year' },
  },
};

// Глобальная переменная для текущего языка
let BROWSER_LANGUAGE = 'en';

const TRANSLATIONS = {
  ru: {
    // Статусы
    ready: 'Готов',
    printing: 'Печатает',
    error: 'Ошибка',
    offline: 'Оффлайн',
    inactive: 'Неактивен',
    paused: 'На паузе',
    complete: 'Завершено',

    // Состояния
    ready_state: 'Готов к печати',
    printing_state: 'Печатает',
    paused_state: 'На паузе',
    error_state: 'Ошибка',
    complete_state: 'Печать завершена',
    cancelled_state: 'Отменено',
    standby_state: 'Ожидание',

    // Интерфейс
    title: '🖨️ 3D Printer Control Panel',
    add_printer: '➕ Добавить принтер',
    test_all: '🔗 Проверить связь',
    polling_interval: 'Интервал опроса:',
    printer_status: '📊 Статус принтеров',
    event_log: '📋 Лог событий',
    clear_log: '🗑️ Очистить',
    export_log: '📥 Экспорт',
    no_printers: 'Нет добавленных принтеров',
    add_first_printer: 'Добавить первый принтер',

    // Подсказки кнопок управления принтерами
    addManualHint: '➕ Добавить по IP',
    scanHint: '🔍 Найти в сети',
    importHint: '📥 Восстановить резервную копию',
    exportHint: '📤 Сохранить конфигурацию',
    deleteAllHint: '🗑️ Удалить все',

    // Лицензирование - заголовки
    license_btn_header: 'Лицензия',
    licensing_title: '🔐 Лицензирование 3DCP',
    license_tab_plans: '📦 Тарифы',
    license_tab_activate: '🔑 Активация',
    license_select_plan: 'Выберите тарифный план:',
    license_btn_request_trial: 'Запросить Trial',
    license_btn_request: 'Запросить лицензию',
    license_btn_activate: '🔑 Активировать лицензию',
    license_btn_close: '❌ Закрыть',
    license_badge_recommended: 'Рекомендуем',
    license_activate_title: 'Активировать лицензию:',
    license_activate_desc: 'Введите ключ, полученный от нас в Telegram или по почте',
    license_key_label: 'Лицензионный ключ:',

    // FREE Plan
    license_free_price: 'Бесплатно',
    license_free_feature1: '✅ До 10 принтеров',
    license_free_feature2: '✅ Все функции',
    license_free_feature3: '✅ Навсегда',
    license_free_active: 'Уже активна',

    // TRIAL Plan
    license_trial_badge: 'Бесплатно!',
    license_trial_price: '0 ₽',
    license_trial_feature1: '✅ Без ограничений по принтерам',
    license_trial_feature2: '✅ Все функции',
    license_trial_feature3: '✅ 14 дней с момента активации',
    license_trial_feature4: '⚠️ После окончания → FREE (10 принтеров)',

    // Статусы лицензий
    license_status_free: 'FREE версия',
    license_status_trial: 'TRIAL версия',
    // 'license_status_standard': 'STANDARD лицензия', // удален
    license_status_professional: 'PROFESSIONAL лицензия',
    license_hwid_label: 'Hardware ID:',
    license_copy_hwid: '📋 Копировать',
    license_how_to_request_title: '💡 Как запросить лицензию:',
    license_how_to_request_steps:
      '1. Нажмите <b>"Запросить лицензию"</b> на выбранном тарифе<br>2. Выберите способ связи (Telegram или Email)<br>3. Следуйте инструкциям в появившемся окне<br>4. Дождитесь ответа администратора',
    license_disclaimer_title: '⚠️ ВАЖНО - DISCLAIMER:',
    license_disclaimer_text:
      'Принтеры <b>Bambu Lab</b> имеют закрытую прошивку.<br>Их работа с программой <b>НЕ ГАРАНТИРОВАНА</b> и может быть прекращена в любой момент по независящим от нас причинам (обновления прошивки, блокировка протоколов и т.д.).<br><br>Приобретая лицензию, вы соглашаетесь с этими условиями.',

    // Авторизация Klipper
    klipper_auth_title: '🔐 Авторизация Klipper',
    klipper_auth_desc: 'Принтер требует авторизацию для подключения',
    klipper_auth_username: 'Имя пользователя:',
    klipper_auth_password: 'Пароль:',
    klipper_auth_save_creds: 'Сохранить учетные данные',
    klipper_auth_test_connection: 'Тест с авторизацией',
    klipper_auth_testing: 'Тестирование авторизации...',
    klipper_auth_cancel: 'Отмена',
    klipper_auth_success: 'Подключение успешно!',
    klipper_auth_failed: 'Ошибка авторизации. Проверьте учетные данные.',
    klipper_auth_username_placeholder: 'Введите имя пользователя',
    klipper_auth_password_placeholder: 'Введите пароль',

    // Диагностика Klipper
    klipper_diagnose_title: '🔧 Диагностика подключения',
    klipper_diagnose_testing: 'Тестирование...',
    klipper_diagnose_results: 'Результаты диагностики',
    klipper_diagnose_port_found: 'Найден рабочий порт',
    klipper_diagnose_no_ports: 'Рабочие порты не найдены',
    klipper_diagnose_web_interface: 'Веб-интерфейс доступен',
    klipper_diagnose_api_not_accessible: 'API недоступен',
    klipper_diagnose_tips: 'Советы по устранению',
    klipper_diagnose_port_7125: 'Порт 7125 (Moonraker API) недоступен снаружи',
    klipper_diagnose_port_4408: 'Порт 4408 для веб-интерфейса (Mainsail/Fluidd), не API',
    klipper_diagnose_check_moonraker: 'Проверьте Moonraker',
    klipper_diagnose_check_web: 'Проверьте веб-интерфейс',
    klipper_diagnose_port_forwarding: 'Возможно нужно настроить port forwarding для 7125',
    klipper_diagnose_tip_browser: 'Откройте в браузере для проверки Moonraker',
    klipper_diagnose_check_moonraker_running: 'Проверьте, что Moonraker запущен на принтере',
    klipper_diagnose_check_port_accessible: 'Убедитесь, что порт доступен снаружи',
    klipper_diagnose_moonraker_api: 'Moonraker API',
    klipper_diagnose_web_interface: 'Web interface',
    klipper_diagnose_testing_failed: 'Диагностика не удалась',

    // Klipper Authorization Help
    klipper_auth_help_title: 'Зачем нужна авторизация?',
    klipper_auth_help_security: 'Безопасность: Защита принтера от несанкционированного доступа',
    klipper_auth_help_remote: 'Удаленный доступ: Подключение к принтеру через интернет',
    klipper_auth_help_moonraker: 'Настройка Moonraker: Если включена авторизация в конфиге',
    klipper_auth_help_optional: 'Не всегда нужно: Многие принтеры работают без авторизации',

    // Klipper Connection Test
    klipper_connection_test: 'Проверить подключение',
    klipper_connection_success: 'Принтер подключается без авторизации!',
    klipper_connection_auth_required: 'Принтер требует авторизацию',
    klipper_connection_error: 'Ошибка подключения',
    klipper_connection_network_error: 'Сетевая ошибка: Не удается подключиться к принтеру',

    // Klipper Alert Messages
    klipper_alert_connection_error: 'Ошибка подключения',
    klipper_alert_network_error: 'Сетевая ошибка',
    klipper_alert_auth_failed: 'Ошибка авторизации',
    klipper_alert_no_token: 'Токен не получен',
    klipper_alert_login_failed: 'Ошибка входа',
    klipper_alert_troubleshooting_tips: 'Советы по устранению неполадок',
    klipper_alert_check_printer_online: '1. Проверьте, что принтер включен',
    klipper_alert_verify_ip: '2. Проверьте IP адрес',
    klipper_alert_verify_port: '3. Проверьте порт',
    klipper_alert_try_browser: '4. Попробуйте открыть в браузере',
    klipper_alert_check_firewall: '5. Проверьте настройки файрвола',
    klipper_alert_verify_moonraker: '6. Убедитесь, что Moonraker запущен',
    klipper_alert_check_port_forwarding: '7. Проверьте проброс портов (для удаленного доступа)',
    klipper_alert_check_username: '1. Проверьте имя пользователя',
    klipper_alert_check_password: '2. Проверьте пароль (специальные символы?)',
    klipper_alert_verify_login_enabled: '3. Убедитесь, что вход в Moonraker включен',
    klipper_alert_check_moonraker_config: '5. Проверьте конфигурацию Moonraker',
    klipper_alert_verify_credentials: '6. Проверьте учетные данные в Moonraker',

    // Bambu Lab ошибки
    bambu_missing_credentials: 'Отсутствуют Access Code и Serial Number. Настройте принтер.',

    // Сообщения статуса (динамические)
    license_msg_free: 'До {limit} принтеров - бесплатно',
    license_msg_free_count: 'Бесплатная версия: {count}/{max} принтеров',

    // Тарифы - цены и периоды (из PRICING_CONFIG)
    // 'license_standard_price': PRICING_CONFIG.RU.STANDARD.price, // удален
    // 'license_standard_period': PRICING_CONFIG.RU.STANDARD.period, // удален
    // 'license_standard_feature1': '✅ Без ограничений', // удален
    // 'license_standard_feature2': `✅ Лицензия на ${PRICING_CONFIG.RU.STANDARD.period}`, // удален
    // 'license_standard_feature3': '✅ Привязка к 1 ПК', // удален
    // 'license_standard_feature4': '✅ Обновления в течение периода', // удален

    license_professional_price: PRICING_CONFIG.RU.PROFESSIONAL.price,
    license_professional_period: PRICING_CONFIG.RU.PROFESSIONAL.period,
    license_professional_feature1: '✅ Все функции программы',
    license_professional_feature2: `✅ Лицензия на ${PRICING_CONFIG.RU.PROFESSIONAL.period}`,
    license_professional_feature3: '✅ Перенос на новый ПК (2 раза в год)',
    license_professional_feature4: '✅ Приоритет поддержки',

    // Модальные окна
    add_printer_modal: '➕ Добавить принтер',
    edit_printer_modal: '✏️ Изменить принтер',
    printer_name: 'Название принтера:',
    printer_type: 'Тип принтера:',
    printer_ip: 'IP адрес:',
    ip_address: 'IP адрес:',
    klipper_moonraker: 'Klipper (Moonraker)',
    bambu_lab: 'Bambu Lab',
    web_interface_port_optional: 'Порт веб-интерфейса (опционально)',
    add: 'Добавить',
    cancel: 'Отмена',
    help: 'Помощь',
    moonraker_port: 'Порт Moonraker:',
    web_port: 'Порт веб-интерфейса (опционально):',
    access_code: 'Код доступа:',
    serial_number: 'Серийный номер:',
    dev_mode_enabled: 'Режим разработчика включен на принтере',
    dev_mode_warning: '⚠️ Режим разработчика должен быть включен в настройках принтера',
    access_code_hint: 'Получите в настройках принтера → Сеть → Код доступа',
    serial_number_hint: 'Найдите на наклейке принтера или в настройках',
    add_button: 'Добавить',
    save_button: 'Сохранить',
    cancel_button: 'Отмена',

    // Информация принтера
    address: 'Адрес:',
    state: 'Состояние:',
    file: 'Файл:',
    progress: 'Прогресс:',
    temperatures: 'Температуры:',
    updated: 'Обновлено:',
    no_file: 'Нет файла',
    nozzle: 'Сопло:',
    bed: 'Стол:',
    chamber: 'Камера:',

    // Действия
    edit: '✏️ Изменить',
    test: '🔄 Проверить',
    remove: '🗑️ Удалить',

    // Сообщения
    panel_started: '🚀 3D Printer Control Panel запущен',
    add_printers_hint: '📁 Добавьте принтеры через кнопку "➕ Добавить принтер"',
    testing_connection: '🔍 Проверяем подключение к',
    http_success: 'Успешное HTTP подключение',
    http_failed: 'Не удалось подключиться по HTTP',
    websocket_connected: 'WebSocket подключен',
    websocket_disconnected: 'WebSocket отключен',
    websocket_error: 'WebSocket ошибка',
    websocket_failed: 'Не удалось установить WebSocket',
    websocket_success: 'WebSocket успешно подключен',
    mqtt_connected: 'MQTT подключен',
    mqtt_disconnected: 'MQTT отключен',
    mqtt_failed: 'Не удалось подключиться по MQTT',
    mqtt_success: 'MQTT успешно подключен',
    using_http_polling: 'использую HTTP опрос',
    connection_error: 'Ошибка подключения',
    printer_added: 'Добавлен принтер:',
    printer_updated: 'Принтер обновлен',
    printer_removed: 'Удален принтер:',
    web_interface_opening: 'Открываю веб-интерфейс',
    web_interface_error: 'Ошибка открытия веб-интерфейса',
    testing_all: '🚀 Запуск проверки всех подключений...',
    testing_complete: '✅ Проверка всех подключений завершена',
    interval_changed: '🔄 Интервал опроса изменен на',
    seconds: 'секунд',
    fill_fields: 'Пожалуйста, заполните название принтера и IP адрес',
    printer_objects_failed: 'Не удалось получить объекты принтера',
    printer_offline: 'Принтер отключен',
    no_data: 'Нет данных',
    no_connection: 'Нет подключения',
    never: 'Никогда',

    // Счетчик принтеров
    printing_count: 'Печатает',
    offline_count: 'Оффлайн',
    ready_count: 'Готовы',
    complete_count: 'Завершено',
    paused_count: 'Пауза',
    error_count: 'Ошибка',

    // Telegram Bot
    telegram_settings: '🤖 Настройки Telegram',
    bot_token: 'Токен бота:',
    chat_id: 'ID чата:',
    enable_notifications: 'Включить уведомления',
    notify_on: 'Уведомлять о:',
    print_complete: 'Завершение печати',
    print_start: 'Начало печати',
    print_error: 'Ошибка печати',
    print_paused: 'Пауза печати',
    printer_offline: 'Принтер offline',
    printer_online: 'Принтер online',
    inefficiency_event: 'Событие неэффективности',
    inefficiency_reason_saved: 'Сохранение причины неэффективности',
    inefficiency_gaps: 'Простой между заданиями (gaps)',
    inefficiency_pauses: 'Паузы во время печати',
    program_start: 'Запуск программы',
    startup_event: '🚀 Запуск программы',
    startup_version: 'Версия',
    startup_printers_count: 'Принтеров в системе',
    startup_status: 'Статус: готово к работе',
    inefficiency_notification_event: '⚠️ Неэффективность',
    operator_report_event: '📝 Отчет оператора',
    inefficiency_gap: 'Gap (перерыв между печатями)',
    inefficiency_pause: 'Pause (пауза во время печати)',
    inefficiency_type: 'Тип',
    inefficiency_duration: 'Длительность',
    inefficiency_start: 'Начало',
    inefficiency_end: 'Конец',
    inefficiency_period: 'Период',
    inefficiency_reason: 'Причина',
    event_print_complete: '✅ Печать завершена',
    event_print_error: '❌ Ошибка печати',
    event_print_paused: '⏸️ Печать на паузе',
    event_printer_offline: '🔌 Принтер отключен',
    event_printer_online: '🟢 Принтер подключен',
    event_print_start: '▶️ Печать начата',
    save: 'Сохранить',
    test_connection: 'Проверить соединение',
    telegram_saved: 'Настройки Telegram сохранены',
    enter_bot_token_chat_id: 'Введите токен бота и ID чата',
    testing_telegram: 'Проверка соединения Telegram...',
    telegram_test_success: 'Тестовое сообщение Telegram отправлено успешно!',
    telegram_test_failed: 'Не удалось отправить тестовое сообщение Telegram',
    get_bot_token_from_botfather: 'Получите у @BotFather в Telegram',
    send_start_to_bot: 'Отправьте /start вашему боту и проверьте логи',
    telegram_help: 'Помощь по настройке Telegram бота',

    // Printer Management
    manage_printers: 'Управление принтерами',
    add_manage_printers: '🔧 Добавление и управление принтерами',
    add_manually: 'Добавить вручную',
    add_manually_hint: '➕ Добавить по IP',
    start_scan: 'Сканировать',
    scan_hint: '🔍 Найти в сети',
    import_btn: 'Импорт',
    import_hint: '📥 Восстановить резервную копию',
    export_btn: 'Экспорт',
    export_hint: '📤 Сохранить конфигурацию',
    scanning_network: 'Сканирование сети...',
    found_printers: 'Найдено принтеров',
    no_printers_found: 'Принтеры не найдены в сети',
    scan_tip: 'Убедитесь, что принтеры включены и подключены к той же сети',
    scan_started: 'Сканирование сети запущено',
    scan_complete: 'Сканирование завершено',
    printers_found: 'принтер(ов) найдено',
    scan_error: 'Ошибка сканирования',
    scan_no_results: '🔍 В сети не найдено принтеров',
    scan_modal_opened: '🔍 Открыт сканер сети',
    scan_already_running: '⚠️ Сканирование уже выполняется',
    scan_not_available: '❌ Сканер сети недоступен',
    already_added: 'уже добавлен',
    requires_credentials: 'требуется код доступа и серийный номер',
    printer_info_filled: 'Информация о принтере заполнена из результатов сканирования',
    add: 'Добавить',
    close: 'Закрыть',

    // Batch add and export/import
    batch_add_selected: 'Добавить выбранные',
    batch_add_all: 'Добавить все',
    export_printers: '📤 Экспорт принтеров',
    import_printers: '📥 Импорт принтеров',
    printers_exported: 'Принтеры экспортированы',
    printers_imported: 'Принтеры импортированы',
    import_error: 'Ошибка импорта',
    export_import_hint:
      'Экспорт/импорт конфигурации принтеров для резервного копирования или переноса на другой компьютер',
    select_all: 'Выбрать все',
    deselect_all: 'Снять выбор',
    selected_count: 'Выбрано',
    batch_add_success: 'Принтеры добавлены',
    no_printers_selected: 'Принтеры не выбраны',
    import_file_invalid: 'Неверный формат файла',
    duplicate_name_suffix: '(копия)',

    // Дополнительные ключи
    printer: 'Принтер',

    // Analytics
    analytics: '📈 Аналитика',
    period: 'Период:',
    printer_filter: 'Принтер:',
    period_day: 'За день',
    period_week: 'За неделю',
    period_month: 'За месяц',
    period_custom: 'Произвольный',
    custom_from: 'С',
    custom_to: 'По',
    kpi_print_time: 'Общее время печати',
    kpi_idle_time: 'Общее время простоя',
    kpi_efficiency: 'Эффективность',
    kpi_energy_cost: 'Стоимость энергии',
    tab_efficiency: 'Эффективность',
    tab_inefficiency: 'Неэффективность',
    tab_energy: 'Энергопотребление',
    tab_details: 'Детальная статистика',
    tab_settings: 'Настройки',
    energy_details_title: 'Детали энергопотребления',
    total_consumption: 'Всего потребление',
    energy_cost: 'Стоимость энергии',
    avg_daily: 'Среднее дневное потребление',
    cost_per_kwh: 'Стоимость за 1 кВт⋅ч',
    save_cost: 'Сохранить стоимость',
    clear_analytics: 'Очистить все данные аналитики',
    analytics_saved: 'Стоимость энергии сохранена',
    analytics_cleared: 'Данные аналитики очищены',
    export_analytics: '📥 Экспортировать статистику',
    energy_settings_title: 'Настройки стоимости энергии',
    clear_data_title: '🗑️ Очистка данных',
    clear_orphaned_desc: 'Удалить данные от удаленных принтеров (рекомендуется):',
    clear_orphaned_btn: '🧹 Очистить данные от удаленных принтеров',
    clear_printer_desc: 'Или удалить данные конкретного принтера:',
    clear_printer_btn: 'Очистить',
    energy_cost_label: 'Стоимость за 1 кВтч:',
    currency_label: 'Валюта:',
    save_energy_cost: '💾 Сохранить стоимость',

    // Валюты
    currency_rub: '₽ RUB',
    currency_usd: '$ USD',
    currency_eur: '€ EUR',
    currency_kzt: '₸ KZT',
    currency_byn: 'Br BYN',
    currency_kgs: 'с KGS',
    currency_mdl: 'L MDL',
    currency_ils: '₪ ILS',
    currency_mnt: '₮ MNT',

    export_analytics_hint: 'Экспорт всех данных аналитики в JSON файл для диагностики проблем',
    analytics_exported: 'Статистика экспортирована',
    export_csv: 'Экспорт CSV',
    wattage_title: 'Мощность принтера (Вт)',
    wattage_print: 'Номинальная мощность (печать, Вт)',
    wattage_idle: 'Мощность простоя (Вт)',
    wattage_print_hint: 'Оценочная средняя мощность во время печати',
    wattage_idle_hint: 'Средняя мощность при простое (электроника/вентиляторы)',
    save_wattage: 'Сохранить мощность',
    inefficiency_periods: 'Периоды неэффективности',
    no_inefficiency: 'Нет периодов неэффективности',
    reason: 'Причина',
    enter_reason: 'Введите причину...',
    save_reason: 'Сохранить причину',
    efficiency_rules_hint: 'Эффективность: перерыв между печатями < 10 мин, паузы < 7 мин',
    confirm_delete_printer: 'Вы уверены что хотите удалить принтер',
    unknown_printer: 'Неизвестный принтер',

    // New Efficiency Tab Translations
    energy_consumption_kwh: 'Потребление энергии (кВт⋅ч)',
    hours: 'Часы',
    efficiency_overview: 'Обзор эффективности',
    efficiency_stats: 'Статистика',
    avg_efficiency: 'Средняя эффективность',
    best_day: 'Лучший день',
    worst_day: 'Худший день',
    total_days: 'Всего дней',
    efficiency_tips: 'Рекомендации',
    eff_tip_good: 'Отличная эффективность! Ваши принтеры хорошо используются.',
    eff_tip_medium: 'Хорошая эффективность, но есть возможности для улучшения.',
    eff_tip_low: 'Обнаружена низкая эффективность.',
    eff_tip_reduce_gaps: 'Уменьшите перерывы между печатями',
    eff_tip_batch: 'Рассмотрите возможность пакетной печати',
    eff_tip_check_ineff: 'Проверьте вкладку Неэффективность для деталей',
    eff_tip_schedule: 'Оптимизируйте планирование печати',
    eff_tip_minimize: 'Минимизируйте время простоя',
    no_data_available: 'Нет доступных данных',
    all_printers: 'Все принтеры',

    // Bambu Lab Info Modal
    bambu_info_modal_title: '🎋 Bambu Lab',
    bambu_info_message:
      'Принтеры Bambu Lab используют мобильное приложение <strong>Bambu Handy</strong> или <strong>Bambu Studio</strong> для управления.',
    bambu_info_no_web: 'Локальный веб-интерфейс недоступен для данного типа принтера.',
    bambu_info_help: 'Помощь',
    bambu_lab_setup_help: 'Настройка принтеров Bambu Lab',

    // Web Server
    web_server_btn_text: 'Web-сервер',
    web_server_modal_title: 'Настройки Web-сервера',
    web_server_port_label: 'Порт сервера:',
    web_server_port_hint: 'Рекомендуется: 8000-9000',
    web_server_status_checking: 'Проверка...',
    web_server_status_running: '✅ Запущен',
    web_server_status_stopped: '⭕ Остановлен',
    web_server_url_text: 'Web-интерфейс доступен по адресу:',
    web_server_clients_text: 'Подключенных клиентов:',
    web_server_what_is_it_title: 'Что это?',
    web_server_what_is_it_text:
      'Web-сервер позволяет управлять принтерами через браузер с любого устройства в вашей локальной сети. Просто откройте указанный адрес на компьютере, планшете или телефоне.',
    web_server_feature1: 'Просмотр статуса всех принтеров',
    web_server_feature2: 'Мониторинг в реальном времени',
    web_server_feature3: 'Доступ с любого устройства в сети',
    web_server_feature4: 'Не требует установки',
    web_server_btn_start: '▶️ Запустить',
    web_server_btn_stop: '🛑 Остановить',
    web_server_btn_processing: 'Обработка...',
    web_server_btn_open: 'Открыть в браузере',
    web_server_btn_help: '📖 Помощь',
    web_server_btn_close: 'Закрыть',

    // Inefficiency Comment Modal
    ineff_comment_modal_title_add: '📝 Добавить комментарий',
    ineff_comment_modal_title_edit: '✏️ Редактировать комментарий',
    ineff_comment_type_label: 'Тип:',
    ineff_comment_duration_label: 'Длительность:',
    ineff_comment_period: 'Период:',
    ineff_comment_label: 'Комментарий / Причина:',
    ineff_comment_placeholder: 'Введите причину этого периода неэффективности...',
    ineff_comment_hint:
      '💡 Пример: Замена материала, обслуживание, ожидание деталей, перерыв оператора и т.д.',
    ineff_comment_save: '💾 Сохранить комментарий',
    ineff_comment_delete: '🗑️ Удалить',
    ineff_comment_cancel: 'Отмена',
    ineff_status_no_comment: '📝 Без комментария',
    ineff_status_has_comment: '✅ Заполнено',
    ineff_btn_add_comment: '➕ Добавить комментарий',
    ineff_btn_edit_comment: '✏️ Редактировать',
    ineff_btn_view_comment: '👁️ Просмотр',
    ineff_type_gap: 'Перерыв между печатями',
    ineff_type_pause: 'Пауза во время печати',
    ineff_comment_saved: 'Комментарий сохранен',
    ineff_comment_deleted: 'Комментарий удален',

    // Clear Analytics Modal
    clear_analytics_title: '⚠️ Очистить данные аналитики',
    clear_analytics_warning1: '⚠️ Внимание! Это действие необратимо!',
    clear_analytics_warning2: 'Все данные аналитики будут безвозвратно удалены, включая:',
    clear_analytics_item1: 'История времени печати и простоя',
    clear_analytics_item2: 'Все события изменения статуса',
    clear_analytics_item3: 'Периоды неэффективности и отчёты операторов',
    clear_analytics_item4: 'Статистика энергопотребления',
    clear_analytics_warning3: 'Настройки мощности (ватты, стоимость кВт⋅ч) будут сохранены.',
    clear_analytics_confirm: 'Вы уверены, что хотите продолжить?',
    clear_analytics_yes: 'Да, очистить все данные',
    clear_analytics_no: 'Отмена',

    // Analytics Help
    analytics_help: '❓ Помощь',
    analytics_help_title: 'Справка по разделу Аналитика',
    telegram_help_title: 'Помощь по настройке Telegram бота',
    bambu_help_title: 'Настройка принтеров Bambu Lab',
    analytics_help_content: `
            <div class="help-section">
                <h4>📊 Общее описание</h4>
                <p>Раздел "Аналитика" позволяет отслеживать эффективность работы ваших 3D-принтеров, анализировать время печати, простоя и энергопотребление.</p>
            </div>
            
            <div class="help-section">
                <h4>📈 Показатели эффективности (KPI)</h4>
                <ul>
                    <li><strong>Общее время печати</strong> — суммарное время активной печати за выбранный период</li>
                    <li><strong>Общее время простоя</strong> — время, когда принтер был готов, но не печатал</li>
                    <li><strong>Эффективность</strong> — процент времени печати от общего доступного времени принтера</li>
                    <li><strong>Стоимость энергии</strong> — рассчитанная стоимость потребленной электроэнергии</li>
                </ul>
            </div>
            
            <div class="help-section">
                <h4>⚡ Вкладка "Энергопотребление"</h4>
                <p>Отображает детальную информацию об энергопотреблении:</p>
                <ul>
                    <li>Общее потребление электроэнергии в кВт⋅ч</li>
                    <li>Стоимость потребленной энергии</li>
                    <li>Среднее дневное потребление</li>
                </ul>
                <p><em>Примечание: для точных расчетов необходимо указать мощность принтера в настройках.</em></p>
            </div>
            
            <div class="help-section">
                <h4>📉 Вкладка "Неэффективность"</h4>
                <p>Показывает периоды, когда принтер работал неэффективно:</p>
                <ul>
                    <li>Длительные паузы во время печати (> 7 минут)</li>
                    <li>Длительные перерывы между печатями (> 10 минут)</li>
                </ul>
                <p>Вы можете указать причину неэффективности для каждого периода, чтобы вести учет.</p>
            </div>
            
            <div class="help-section">
                <h4>⚙️ Вкладка "Настройки"</h4>
                <p>Настройки для расчета аналитики:</p>
                <ul>
                    <li><strong>Стоимость за 1 кВт⋅ч</strong> — установите ваш тариф на электроэнергию</li>
                    <li><strong>Мощность принтера</strong> — номинальная мощность при печати и в режиме простоя</li>
                    <li><strong>Очистка данных</strong> — удаление всех накопленных данных аналитики</li>
                </ul>
            </div>
            
            <div class="help-section">
                <h4>🔍 Фильтры</h4>
                <ul>
                    <li><strong>Период</strong> — выберите временной интервал для анализа (день, неделя, месяц или произвольный)</li>
                    <li><strong>Принтер</strong> — фильтруйте данные по конкретному принтеру или просматривайте статистику по всем</li>
                </ul>
            </div>
            
            <div class="help-section">
                <h4>💾 Экспорт данных</h4>
                <p>Используйте кнопку "Экспорт CSV" для сохранения детальной статистики в формате CSV для дальнейшего анализа в Excel или других программах.</p>
            </div>
            
            <div class="help-section" style="background: #2a2a2a; padding: 15px; border-radius: 8px; border-left: 4px solid #00d4ff;">
                <h4>⚡ Как рассчитать мощность 3D принтера</h4>
                <p>Для точного расчёта энергопотребления необходимо знать мощность вашего принтера:</p>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">📋 Способ 1: Спецификация производителя</h5>
                <ul>
                    <li>Проверьте техническую документацию принтера</li>
                    <li>Посмотрите на наклейку на блоке питания (Voltage × Amperage = Watts)</li>
                    <li>Пример: 24V × 15A = 360W (номинальная мощность)</li>
                </ul>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">📊 Способ 2: Измерение ваттметром</h5>
                <ul>
                    <li><strong>Рекомендуется!</strong> Используйте бытовой ваттметр (умную розетку с измерением мощности)</li>
                    <li>Подключите принтер через ваттметр</li>
                    <li>Измерьте реальное потребление во время печати (обычно 50-70% от номинала)</li>
                    <li>Измерьте потребление в режиме ожидания (обычно 5-15W)</li>
                </ul>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">🔢 Способ 3: Расчёт по компонентам</h5>
                <p>Суммируйте мощность основных компонентов:</p>
                <ul>
                    <li><strong>Нагревательный стол:</strong> обычно 150-300W (зависит от размера)</li>
                    <li><strong>Хотенд:</strong> обычно 40-60W</li>
                    <li><strong>Шаговые моторы:</strong> 4-6 моторов × 10-20W = 40-120W</li>
                    <li><strong>Электроника:</strong> платы, дисплей ≈ 10-20W</li>
                    <li><strong>Вентиляторы:</strong> 2-5W каждый</li>
                    <li><strong>Освещение/камера:</strong> 5-10W (если есть)</li>
                </ul>
                <p><em>Пример расчёта: 200W (стол) + 50W (хотенд) + 80W (моторы) + 15W (электроника) + 10W (вентиляторы) = 355W</em></p>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">💡 Типичные значения для разных принтеров</h5>
                <ul>
                    <li><strong>Малые принтеры</strong> (Ender 3, Prusa Mini): 120-200W печать, 5-10W простой</li>
                    <li><strong>Средние принтеры</strong> (Prusa i3, Ender 5): 200-350W печать, 8-15W простой</li>
                    <li><strong>Большие принтеры</strong> (CR-10, Voron): 350-600W печать, 10-20W простой</li>
                    <li><strong>Bambu Lab</strong> (X1, P1): 250-400W печать, 10-15W простой</li>
                </ul>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">⚙️ Где вносить данные</h5>
                <p>Перейдите в <strong>Аналитика → Настройки</strong> и укажите:</p>
                <ul>
                    <li><strong>Номинальная мощность (печать, Вт)</strong> — средняя мощность во время активной печати</li>
                    <li><strong>Мощность простоя (Вт)</strong> — мощность когда принтер включен, но не печатает</li>
                </ul>
                <p style="margin-top: 10px; color: #888;"><em>💡 Совет: Лучше указать реальные измеренные значения для более точного расчёта стоимости энергии!</em></p>
            </div>
        `,

    // Temperature Sensors Modal
    temp_sensors_modal_title: 'Расширенные настройки температуры',
    temp_sensors_for_advanced: 'Для продвинутых пользователей:',
    temp_sensors_description: 'Настройте, какие датчики температуры отображать.',
    temp_sensors_auto_recommended:
      'Оставьте невыбранным для использования автоопределения (рекомендуется для большинства).',
    temp_sensors_tip: 'Совет:',
    temp_sensors_tip_text:
      'Выберите только те датчики, которые хотите видеть. Если ничего не выбрано, приложение автоматически определит температуру камеры по имени. Большинству пользователей ничего здесь менять не нужно.',
    temp_sensors_save_custom: 'Сохранить выбор',
    temp_sensors_use_auto: 'Использовать автоопределение',
    temp_sensors_chamber_hint: '🏠 Температура камеры',
    temp_sensors_mcu_hint: '🔧 Температура платы',
    temp_sensors_rpi_hint: '💻 Компьютер хоста',
    temp_sensors_room_hint: '🌡️ Температура окружения',
    temp_sensors_generic_hint: '📊 Датчик температуры',

    // Power Off Confirmation
    power_off_confirm_title: 'Подтверждение выключения',
    power_off_confirm_message: 'Вы уверены, что хотите выключить принтер?',
    power_off_confirm_warning:
      '⚠️ Это немедленно отключит питание принтера. Убедитесь, что печать завершена или приостановлена.',
    power_off_confirm_btn: 'Выключить',

    // Update Checker
    update_available_title: 'Доступна новая версия',
    update_new_version: 'Доступна новая версия приложения!',
    update_current: 'Текущая версия:',
    update_latest: 'Новая версия:',
    update_recommendation: 'Рекомендуем обновиться для получения новых функций и улучшений.',
    update_later: 'Позже',
    update_download: 'Скачать обновление',
    update_available_console: 'Доступна новая версия',
    checking_updates: 'Проверка обновлений...',
    no_updates: 'Вы используете последнюю версию',
    update_check_error: 'Ошибка проверки обновлений',
    update_up_to_date_title: 'Всё актуально!',
    update_no_updates_message: 'Вы используете последнюю версию!',
    update_no_updates_text:
      'Ваше приложение обновлено. Проверьте позже для получения новых функций и улучшений.',

    // Smart Plugs
    smart_plugs: 'Розетки',
    smart_plugs_config: 'Настройка умных розеток',
    smart_plugs_settings: 'Настройки',
    smart_plug_title: 'Умная розетка',
    plug_type: 'Тип подключения:',
    plug_not_configured: 'Не настроено',
    plug_configure_first: 'Сначала настройте подключение:',
    plugs_connection_type: 'Тип подключения:',
    plugs_choose_type: 'Выберите способ подключения ваших умных розеток:',
    plugs_tuya_desc: 'Прямое подключение к Tuya/Smart Life',
    plugs_ha_desc: 'Универсальное решение для всех брендов',
    plugs_easy_setup: 'Простая настройка',
    plugs_tuya_devices: 'Только Tuya устройства',
    plugs_all_brands: 'Все бренды (Tuya, Яндекс и т.д.)',
    plugs_local_control: 'Локальное управление',
    plugs_link_info:
      'Чтобы привязать конкретную умную розетку к принтеру, откройте настройки принтера и выберите устройство из списка.',

    // Tuya
    tuya_select_device: 'Выберите Tuya устройство:',
    tuya_not_connected: 'Не подключена',
    tuya_configure_first: 'Сначала настройте Tuya API:',
    tuya_settings: 'Настройки',
    tuya_automation: 'Автоматизация:',
    tuya_auto_shutdown_complete: 'Автоотключение после завершения печати',
    tuya_shutdown_delay: 'Задержка отключения (минут):',
    tuya_auto_shutdown_error: 'Автоотключение при ошибке печати',
    tuya_auto_shutdown_overheat: 'Автоотключение при перегреве (MCU > 70°C)',
    tuya_preparation: 'Подготовка:',
    tuya_step1: 'Зарегистрируйтесь на',
    tuya_step2: 'Создайте Cloud Project',
    tuya_step3: 'Получите Access ID и Access Secret',
    tuya_step4: 'Подпишитесь на Smart Home PaaS API',
    tuya_step5: 'Свяжите ваш аккаунт Smart Life',
    tuya_region: 'Регион:',
    tuya_access_id: 'Access ID:',
    tuya_access_secret: 'Access Secret:',
    tuya_encrypted: '⚠️ Будет храниться в зашифрованном виде',
    tuya_secret_saved_hint: '💡 Если сохранен, будет показан точками (кликните для редактирования)',
    tuya_test_connection: 'Проверить соединение',
    tuya_devices_not_found: 'Розетки не найдены',

    // Home Assistant
    ha_preparation: 'Подготовка:',
    ha_step1: 'Установите Home Assistant',
    ha_step2: 'Добавьте ваши розетки в Home Assistant',
    ha_step3: 'Создайте Long-Lived Access Token',
    ha_step4: 'Профиль → Security → Create Token',
    ha_url: 'URL Home Assistant:',
    ha_url_hint: 'Обычно: http://homeassistant.local:8123 или http://IP:8123',
    ha_token: 'Long-Lived Access Token:',
    ha_token_hint: 'Получить: Профиль → Security → Long-lived access tokens',
    ha_token_saved_hint: '💡 Если сохранен, будет показан точками (кликните для редактирования)',
    ha_test_connection: 'Проверить соединение',
    ha_select_device: 'Выберите Home Assistant entity:',
    ha_not_connected: 'Не подключена',
    ha_entities_not_found: 'Розетки не найдены',
    ha_configure_first: 'Сначала настройте Home Assistant API:',
    saving: 'Сохранение...',
    settings_saved: 'Настройки сохранены!',
    connection_success: 'Соединение установлено!',
    fill_all_fields: 'Заполните все поля',

    // Power Control
    power_control_error: 'Ошибка управления питанием',
    turn_on_power: 'Включить питание',
    turn_off_power: 'Выключить питание',
    tuya_power_control: 'Управление питанием',

    // Telegram Smart Plugs Notifications
    telegram_power_events: 'События умных розеток:',
    telegram_notify_power_off: 'Автоотключение питания',
    telegram_notify_emergency: 'Аварийное отключение (перегрев)',

    // Network Scanner
    adding_printers: '⏳ Добавляю принтеры...',
    scan_modal_closed: 'Окно сканирования закрыто',

    // Bambu Lab Warning Modal
    bambu_warning_title: '⚠️ Важно: Настройка Bambu Lab',
    bambu_warning_message: 'Для работы с принтерами Bambu Lab необходимо вручную ввести:',
    bambu_warning_step1: '1️⃣ <strong>Код доступа</strong> - получите в настройках принтера → Сеть',
    bambu_warning_step2: '2️⃣ <strong>Серийный номер</strong> - найдите на наклейке принтера',
    bambu_warning_step3: '3️⃣ Нажмите ✏️ <strong>Изменить</strong> на каждом принтере Bambu Lab',
    bambu_warning_button: 'Понятно',

    // Delete All Button
    deleteAllBtnText: 'Удалить все',
    confirm_delete_all: 'Вы уверены, что хотите удалить ВСЕ принтеры?',
    this_cannot_be_undone: 'Это действие необратимо!',
    all_printers_deleted: 'Удалено принтеров:',

    // Footer / License
    license_info: 'Для коммерческого использования свяжитесь с разработчиком',

    // License Dialog Messages
    license_error_copy_hwid: 'Ошибка копирования. HWID: {hwid}',
    license_telegram_opened:
      '✅ Telegram бот открыт!\n\n📋 ДАЛЬНЕЙШИЕ ДЕЙСТВИЯ:\n\n1️⃣ Напишите боту команду /start\n2️⃣ Сообщите боту ваш Hardware ID:\n   {hwid}\n\n3️⃣ Укажите желаемый тарифный план: {plan}\n\n4️⃣ Администратор свяжется с вами для уточнения оплаты\n5️⃣ После оплаты ключ автоматически придет в чат!\n\n⚠️ ВАЖНО - DISCLAIMER:\nПринтеры Bambu Lab имеют закрытую прошивку.\nИх работа с программой НЕ ГАРАНТИРОВАНА и может быть прекращена в любой момент по независящим от нас причинам.\n\nПриобретая лицензию, вы соглашаетесь с этими условиями.',
    license_email_copied: '✅ Текст скопирован в буфер обмена!\n\nОтправьте его на utolyana@ya.ru',
    license_email_copy_error: '❌ Ошибка копирования. Скопируйте текст вручную из окна ниже.',
    license_trial_process:
      '📋 ПРОЦЕСС ПОЛУЧЕНИЯ TRIAL:\n\n1️⃣ Напишите боту @CP_licensing_bot команду /start (если еще не писали)\n2️⃣ Отправьте запрос (сейчас)\n3️⃣ Администратор одобрит запрос\n4️⃣ Trial ключ автоматически придет вам в чат с ботом\n5️⃣ Активируйте ключ в приложении\n\nПродолжить?',
    license_trial_sending: '⏳ Отправка запроса...',
    license_trial_success: '✅ {message}',
    license_trial_error: '❌ Ошибка: {message}',
    license_error_enter_key: 'Введите лицензионный ключ',
    license_error_invalid_format: 'Неверный формат ключа. Ключ должен начинаться с 3DCP-',
    license_error_invalid_pattern:
      'Неверный формат ключа. Ожидается: 3DCP-XXXX-XXXX-XXXX-XXXX-XXXX или 3DCP-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX',
    license_error_server_response: 'Сервер вернул некорректный ответ. Попробуйте позже.',
    license_error_activation: 'Ошибка активации',
    license_error_activation_status: 'Ошибка активации ({status})',
    license_error_validation_failed: 'Validation failed',
    license_error_request_failed: 'Ошибка отправки запроса',
    license_activate_desc: 'Введите ключ, полученный от нас в Telegram или по почте',
    license_key_placeholder: '3DCP-XXXX-XXXX-XXXX-XXXX-XXXX',
    license_key_tooltip: 'Можно вставлять через Ctrl+V или правый клик мыши',
    license_status_free_title: 'FREE версия',
    license_status_free_message: 'До 10 принтеров - бесплатно',
    license_free_active: 'Уже активна',
    license_printer_disabled: '{name} — принтер отключен лицензией. Откройте окно лицензирования для разблокировки дополнительных принтеров.',
    license_btn_request_trial: 'Запросить Trial',
    contact_modal_title: 'Запрос лицензии',
    contact_modal_desc: 'Выберите способ связи для получения лицензии:',
    contact_telegram_title: 'Telegram бот',
    contact_telegram_fast: 'БЫСТРО',
    contact_telegram_desc:
      '✅ Автоматическая обработка<br>✅ Ответ в течение нескольких часов<br>✅ Удобная коммуникация',
    contact_email_title: 'Email',
    contact_email_slow: 'МЕДЛЕННО',
    contact_email_desc:
      '⚠️ Ручная обработка<br>⚠️ Ответ может занять несколько дней<br>⚠️ Альтернатива, если нет Telegram',
    contact_recommendation: '💡 Рекомендуем использовать Telegram для быстрой обработки запроса',
    mass_print_btn: 'Отправить на печать',
    mass_print_title: '📤 Массовая отправка файлов',
    mass_print_select_file: 'Выберите файл для печати:',
    mass_print_file_types: 'Поддерживаемые форматы: .gcode',
    mass_print_select_printers: 'Выберите принтеры:',
    mass_print_no_printers: 'Нет готовых принтеров (статус: готов/завершен)',
    mass_print_ready: 'Готов к печати',
    mass_print_printing: 'Печатает',
    mass_print_offline: 'Недоступен',
    mass_print_error: 'Ошибка',
    mass_print_send_btn: 'Отправить на печать',
    mass_print_cancel_btn: 'Отмена',
    mass_print_progress_title: 'Отправка файлов...',
    mass_print_success: 'Файлы успешно отправлены!',
    mass_print_error_msg: 'Ошибка отправки файлов',
    massPrintHint: '🖨️ Отправить файлы на принтеры',

    // HMS Errors
    hms_errors: 'Ошибки HMS',
    loading_hms: 'Загрузка статуса HMS...',
    hms_hotend_temp_error: 'Ошибка температуры сопла',
    hms_hotend_temp_desc: 'Температура сопла слишком высокая или низкая',
    hms_hotend_temp_solution: 'Проверьте датчик температуры сопла и проводку',
    hms_bed_temp_error: 'Ошибка температуры стола',
    hms_bed_temp_desc: 'Неисправность датчика температуры стола',
    hms_bed_temp_solution: 'Проверьте датчик температуры стола и проводку',
    hms_chamber_temp_error: 'Ошибка температуры камеры',
    hms_chamber_temp_desc: 'Проблема с датчиком температуры камеры',
    hms_chamber_temp_solution: 'Проверьте датчик температуры камеры',
    hms_fan_error: 'Ошибка вентилятора',
    hms_fan_desc: 'Обнаружена неисправность вентилятора',
    hms_fan_solution: 'Проверьте подключение вентилятора и замените при необходимости',
    hms_extruder_error: 'Ошибка экструдера',
    hms_extruder_desc: 'Проблема с мотором или шестернями экструдера',
    hms_extruder_solution: 'Проверьте мотор экструдера и сборку шестерен',
    hms_z_axis_error: 'Ошибка Z-оси',
    hms_z_axis_desc: 'Проблема с движением Z-оси',
    hms_z_axis_solution: 'Проверьте мотор Z-оси и ходовой винт',
    hms_x_axis_error: 'Ошибка X-оси',
    hms_x_axis_desc: 'Проблема с движением X-оси',
    hms_x_axis_solution: 'Проверьте мотор X-оси и натяжение ремня',
    hms_y_axis_error: 'Ошибка Y-оси',
    hms_y_axis_desc: 'Проблема с движением Y-оси',
    hms_y_axis_solution: 'Проверьте мотор Y-оси и натяжение ремня',
    hms_filament_runout: 'Закончилась нить',
    hms_filament_runout_desc: 'Нить не обнаружена',
    hms_filament_runout_solution: 'Загрузите новую нить и возобновите печать',
    hms_door_open: 'Дверь открыта',
    hms_door_open_desc: 'Дверь принтера открыта',
    hms_door_open_solution: 'Закройте дверь принтера',
    hms_unknown_error: 'Неизвестная ошибка',
    hms_unknown_desc: 'Код ошибки HMS: {code}',
    hms_unknown_solution: 'Проверьте руководство принтера или обратитесь в поддержку',

    // Print Speed Control
    print_speed: 'Скорость печати',
    current_speed: 'Обычная (2)',
    speed_silent: 'Тихая',
    speed_normal: 'Обычная',
    speed_sport: 'Спорт',
    speed_ludicrous: 'Безумная',

    // Temperature Control
    temperature_control: 'Управление температурой',
    nozzle_temperature: 'Температура сопла (°C)',
    bed_temperature: 'Температура стола (°C)',
    set_temperature: 'Установить',

    // Fan Control
    fan_control: 'Управление вентиляторами',
    chamber_fan: 'Вентилятор камеры (%)',
    aux_fan: 'Дополнительный вентилятор (%)',
    cooling_fan: 'Вентилятор охлаждения (%)',

    // Camera Controls
    live_camera: 'Живая камера',
    turn_led_on: 'Включить LED',
    turn_led_off: 'Выключить LED',
    save_screenshot: 'Сохранить снимок',
    loading_camera: 'Загрузка потока камеры...',
    camera_timeout: 'Таймаут камеры',
    camera_timeout_desc:
      'Данные камеры не получены в течение 10 секунд. Это может указывать на проблему платформы.',
    camera_error: 'Ошибка камеры',
    camera_not_available: 'Поток камеры недоступен или принтер офлайн',
    debug_info: 'Отладочная информация',
    platform: 'Платформа',
    time: 'Время',
    user_agent: 'User Agent',
    data_size: 'Размер данных',

    // File Upload
    file_upload: 'Загрузка файлов',
    select_file: 'Выбрать файл',
    upload_file: 'Загрузить файл',
    uploading_file: 'Загрузка файла...',
    upload_success: 'Файл загружен успешно',
    upload_error: 'Ошибка загрузки файла',
    start_print: 'Начать печать',
    printing_file: 'Печать файла...',
    print_started: 'Печать запущена',
    print_error: 'Ошибка запуска печати',
    supported_formats: 'Поддерживаемые форматы: .gcode, .3mf',
    file_size_limit: 'Максимальный размер файла: 100MB',

    // Unsupported Model
    unsupported_model: 'Неподдерживаемая модель',
    unsupported_model_desc:
      'Эта модель Bambu Lab (серия A1/X1) не полностью поддерживается текущей библиотекой.',
    unsupported_model_features:
      'Доступен базовый мониторинг, но расширенные функции как загрузка файлов, управление LED и вентиляторами недоступны.',
    print_progress: 'Прогресс печати',
    print_details: 'Детали печати',
    temperatures: 'Температуры',
    remaining_time: 'Время до завершения',
    current_layer: 'Текущий слой',
    print_speed_label: 'Скорость печати',
    no_file: 'Нет файла',
    target: 'Цель',
    ambient: 'Окружающая',
    ip_address: 'IP адрес',
    serial_number: 'Серийный номер',
    connection: 'Подключение',
    camera: 'Камера',
    last_update: 'Последнее обновление',
    live_camera: 'Живая камера',
    camera_image_not_available: 'Изображение камеры недоступно',
  },
  en: {
    // Statuses
    ready: 'Ready',
    printing: 'Printing',
    error: 'Error',
    offline: 'Offline',
    inactive: 'Inactive',
    paused: 'Paused',
    complete: 'Complete',

    // States
    ready_state: 'Ready to print',
    printing_state: 'Printing',
    paused_state: 'Paused',
    error_state: 'Error',
    complete_state: 'Print completed',
    cancelled_state: 'Cancelled',
    standby_state: 'Standby',

    // Interface
    title: '🖨️ 3D Printer Control Panel',
    add_printer: '➕ Add Printer',
    test_all: '🔗 Test Connections',
    polling_interval: 'Polling interval:',
    printer_status: '📊 Printer Status',
    event_log: '📋 Event Log',
    clear_log: '🗑️ Clear',
    export_log: '📥 Export',
    no_printers: 'No printers added',
    add_first_printer: 'Add first printer',

    // Printer management button hints
    addManualHint: '➕ Add by IP',
    scanHint: '🔍 Find in network',
    importHint: '📥 Restore backup',
    exportHint: '📤 Save config',
    deleteAllHint: '🗑️ Remove all',

    // Licensing - headings
    license_btn_header: 'License',
    licensing_title: '🔐 3DCP Licensing',
    license_tab_plans: '📦 Plans',
    license_tab_activate: '🔑 Activation',
    license_select_plan: 'Select a plan:',
    license_btn_request_trial: 'Request Trial',
    license_btn_request: 'Request License',
    license_btn_activate: '🔑 Activate License',
    license_btn_close: '❌ Close',
    license_badge_recommended: 'Recommended',
    license_activate_title: 'Activate License:',
    license_activate_desc: 'Enter the key received from us via Telegram or Email',
    license_key_label: 'License Key:',

    // FREE Plan
    license_free_price: 'Free',
    license_free_feature1: '✅ Up to 10 printers',
    license_free_feature2: '✅ All features',
    license_free_feature3: '✅ Forever',
    license_free_active: 'Already active',

    // TRIAL Plan
    license_trial_badge: 'Free!',
    license_trial_price: '$0',
    license_trial_feature1: '✅ Unlimited printers',
    license_trial_feature2: '✅ All features',
    license_trial_feature3: '✅ 14 days from activation',
    license_trial_feature4: '⚠️ After expiration → FREE (10 printers)',

    // License statuses
    license_status_free: 'FREE version',
    license_status_trial: 'TRIAL version',
    // 'license_status_standard': 'STANDARD license', // удален
    license_status_professional: 'PROFESSIONAL license',
    license_hwid_label: 'Hardware ID:',
    license_copy_hwid: '📋 Copy',
    license_how_to_request_title: '💡 How to request a license:',
    license_how_to_request_steps:
      '1. Click <b>"Request License"</b> on the selected plan<br>2. Choose contact method (Telegram or Email)<br>3. Follow instructions in the popup window<br>4. Wait for admin response',
    license_disclaimer_title: '⚠️ IMPORTANT - DISCLAIMER:',
    license_disclaimer_text:
      '<b>Bambu Lab</b> printers have closed firmware.<br>Their operation with this program is <b>NOT GUARANTEED</b> and may be discontinued at any time for reasons beyond our control (firmware updates, protocol blocking, etc.).<br><br>By purchasing a license, you agree to these terms.',

    // Status messages (dynamic)
    license_msg_free: 'Up to {limit} printers - free',
    license_msg_free_count: 'Free version: {count}/{max} printers',

    // License plans - prices and periods (from PRICING_CONFIG)
    // 'license_standard_price': PRICING_CONFIG.EN.STANDARD.price, // удален
    // 'license_standard_period': PRICING_CONFIG.EN.STANDARD.period, // удален
    // 'license_standard_feature1': '✅ Unlimited printers', // удален
    // 'license_standard_feature2': `✅ ${PRICING_CONFIG.EN.STANDARD.period} license`, // удален
    // 'license_standard_feature3': '✅ 1 PC binding', // удален
    // 'license_standard_feature4': '✅ Updates during period', // удален

    license_professional_price: PRICING_CONFIG.EN.PROFESSIONAL.price,
    license_professional_period: PRICING_CONFIG.EN.PROFESSIONAL.period,
    license_professional_feature1: '✅ All from Standard',
    license_professional_feature2: `✅ ${PRICING_CONFIG.EN.PROFESSIONAL.period} license`,
    license_professional_feature3: '✅ PC transfer (2x per year)',
    license_professional_feature4: '✅ Priority support',

    // Modal windows
    add_printer_modal: '➕ Add Printer',
    edit_printer_modal: '✏️ Edit Printer',
    printer_name: 'Printer name:',
    printer_type: 'Printer type:',
    printer_ip: 'IP address:',
    ip_address: 'IP address:',
    klipper_moonraker: 'Klipper (Moonraker)',
    bambu_lab: 'Bambu Lab',
    web_interface_port_optional: 'Web interface port (optional)',
    add: 'Add',
    cancel: 'Cancel',
    help: 'Help',
    moonraker_port: 'Moonraker port:',
    web_port: 'Web interface port (optional):',
    access_code: 'Access Code:',
    serial_number: 'Serial Number:',
    dev_mode_enabled: 'Developer Mode enabled on printer',
    dev_mode_warning: '⚠️ Developer mode must be enabled in printer settings',
    access_code_hint: 'Get from printer settings → Network → Access Code',
    serial_number_hint: 'Find on printer label or in settings',
    add_button: 'Add',
    save_button: 'Save',
    cancel_button: 'Cancel',

    // Printer info
    address: 'Address:',
    state: 'State:',
    file: 'File:',
    progress: 'Progress:',
    temperatures: 'Temperatures:',
    updated: 'Updated:',
    no_file: 'No file',
    nozzle: 'Nozzle:',
    bed: 'Bed:',
    chamber: 'Chamber:',

    // Actions
    edit: '✏️ Edit',
    test: '🔄 Test',
    remove: '🗑️ Remove',

    // Messages
    panel_started: '🚀 3D Printer Control Panel started',
    add_printers_hint: '📁 Add printers via "➕ Add Printer" button',
    testing_connection: '🔍 Testing connection to',
    http_success: 'Successful HTTP connection',
    http_failed: 'HTTP connection failed',
    websocket_connected: 'WebSocket connected',
    websocket_disconnected: 'WebSocket disconnected',
    websocket_error: 'WebSocket error',
    websocket_failed: 'Failed to setup WebSocket',
    websocket_success: 'WebSocket successfully connected',
    mqtt_connected: 'MQTT connected',
    mqtt_disconnected: 'MQTT disconnected',
    mqtt_failed: 'Failed to connect via MQTT',
    mqtt_success: 'MQTT successfully connected',
    using_http_polling: 'using HTTP polling',
    connection_error: 'Connection error',
    printer_added: 'Printer added:',
    printer_updated: 'Printer updated',
    printer_removed: 'Printer removed:',
    web_interface_opening: 'Opening web interface',
    web_interface_error: 'Web interface opening error',
    testing_all: '🚀 Starting all connections test...',
    testing_complete: '✅ All connections test completed',
    interval_changed: '🔄 Polling interval changed to',
    seconds: 'seconds',
    fill_fields: 'Please fill in printer name and IP address',
    printer_objects_failed: 'Failed to get printer objects',
    printer_offline: 'Printer offline',
    no_data: 'No data',
    no_connection: 'No connection',
    never: 'Never',

    // Printers counter
    printing_count: 'Printing',
    offline_count: 'Offline',
    ready_count: 'Ready',
    complete_count: 'Complete',
    paused_count: 'Paused',
    error_count: 'Error',

    // Telegram Bot
    telegram_settings: '🤖 Telegram Settings',
    bot_token: 'Bot Token:',
    chat_id: 'Chat ID:',
    enable_notifications: 'Enable notifications',
    notify_on: 'Notify on:',
    print_complete: 'Print complete',
    print_start: 'Print start',
    print_error: 'Print error',
    print_paused: 'Print paused',
    printer_offline: 'Printer offline',
    printer_online: 'Printer online',
    inefficiency_event: 'Inefficiency event',
    inefficiency_reason_saved: 'Inefficiency reason saved',
    inefficiency_gaps: 'Idle between jobs (gaps)',
    inefficiency_pauses: 'Pauses during print',
    program_start: 'Program start',
    startup_event: '🚀 Program Start',
    startup_version: 'Version',
    startup_printers_count: 'Printers in system',
    startup_status: 'Status: ready to work',
    inefficiency_notification_event: '⚠️ Inefficiency',
    operator_report_event: '📝 Operator Report',
    inefficiency_gap: 'Gap (break between prints)',
    inefficiency_pause: 'Pause (during printing)',
    inefficiency_type: 'Type',
    inefficiency_duration: 'Duration',
    inefficiency_start: 'Start',
    inefficiency_end: 'End',
    inefficiency_period: 'Period',
    inefficiency_reason: 'Reason',
    event_print_complete: '✅ Print Complete',
    event_print_error: '❌ Print Error',
    event_print_paused: '⏸️ Print Paused',
    event_printer_offline: '🔌 Printer Offline',
    event_printer_online: '🟢 Printer Online',
    event_print_start: '▶️ Print Started',
    save: 'Save',
    test_connection: 'Test Connection',
    telegram_saved: 'Telegram settings saved',
    enter_bot_token_chat_id: 'Please enter Bot Token and Chat ID',
    testing_telegram: 'Testing Telegram connection...',
    telegram_test_success: 'Telegram test message sent successfully!',
    telegram_test_failed: 'Failed to send Telegram test message',
    get_bot_token_from_botfather: 'Get this from @BotFather in Telegram',
    send_start_to_bot: 'Send /start to your bot and check logs',
    telegram_help: 'Telegram Bot Setup Help',

    // Printer Management
    manage_printers: 'Manage Printers',
    add_manage_printers: '🔧 Add & Manage Printers',
    add_manually: 'Add Manually',
    add_manually_hint: '➕ Add printer by IP',
    start_scan: 'Scan Network',
    scan_hint: '🔍 Find in network',
    import_btn: 'Import',
    import_hint: '📥 Restore backup',
    export_btn: 'Export',
    export_hint: '📤 Save config',
    scanning_network: 'Scanning network...',
    found_printers: 'Found Printers',
    no_printers_found: 'No printers found on the network',
    scan_tip: 'Make sure printers are powered on and connected to the same network',
    scan_started: 'Network scan started',
    scan_complete: 'Scan complete',
    printers_found: 'printer(s) found',
    scan_error: 'Scan error',
    scan_no_results: '🔍 No printers found on the network',
    scan_modal_opened: '🔍 Network scanner opened',
    scan_already_running: '⚠️ Scan is already in progress',
    scan_not_available: '❌ Network scanner is not available',
    already_added: 'already added',
    requires_credentials: 'requires access code & serial',
    printer_info_filled: 'Printer information filled from scan',
    add: 'Add',
    close: 'Close',

    // Batch add and export/import
    batch_add_selected: 'Add Selected',
    batch_add_all: 'Add All',
    export_printers: '📤 Export Printers',
    import_printers: '📥 Import Printers',
    printers_exported: 'Printers exported',
    printers_imported: 'Printers imported',
    import_error: 'Import error',
    export_import_hint:
      'Export/import printer configurations for backup or transfer to another computer',
    select_all: 'Select All',
    deselect_all: 'Deselect All',
    selected_count: 'Selected',
    batch_add_success: 'Printers added',
    no_printers_selected: 'No printers selected',
    import_file_invalid: 'Invalid file format',
    duplicate_name_suffix: '(copy)',

    // Additional keys
    printer: 'Printer',

    // Analytics
    analytics: '📈 Analytics',
    period: 'Period:',
    printer_filter: 'Printer:',
    period_day: 'Day',
    period_week: 'Week',
    period_month: 'Month',
    period_custom: 'Custom',
    custom_from: 'From',
    custom_to: 'To',
    kpi_print_time: 'Total print time',
    kpi_idle_time: 'Total idle time',
    kpi_efficiency: 'Efficiency',
    kpi_energy_cost: 'Energy cost',
    tab_efficiency: 'Efficiency',
    tab_inefficiency: 'Inefficiency',
    tab_energy: 'Energy',
    tab_details: 'Details',
    tab_settings: 'Settings',
    energy_details_title: 'Energy details',
    total_consumption: 'Total consumption',
    energy_cost: 'Energy cost',
    avg_daily: 'Average daily consumption',
    cost_per_kwh: 'Cost per 1 kWh',
    save_cost: 'Save cost',
    clear_analytics: 'Clear all analytics data',
    analytics_saved: 'Energy cost saved',
    analytics_cleared: 'Analytics data cleared',
    export_analytics: '📥 Export Statistics',
    energy_settings_title: 'Energy Cost Settings',
    clear_data_title: '🗑️ Data Cleanup',
    clear_orphaned_desc: 'Delete data from removed printers (recommended):',
    clear_orphaned_btn: '🧹 Clear data from removed printers',
    clear_printer_desc: 'Or delete data from specific printer:',
    clear_printer_btn: 'Clear',
    energy_cost_label: 'Cost per 1 kWh:',
    currency_label: 'Currency:',
    save_energy_cost: '💾 Save Cost',

    // Currencies
    currency_rub: '₽ RUB',
    currency_usd: '$ USD',
    currency_eur: '€ EUR',
    currency_kzt: '₸ KZT',
    currency_byn: 'Br BYN',
    currency_kgs: 'с KGS',
    currency_mdl: 'L MDL',
    currency_ils: '₪ ILS',
    currency_mnt: '₮ MNT',

    export_analytics_hint: 'Export all analytics data to JSON file for diagnostics',
    analytics_exported: 'Statistics exported',
    export_csv: 'Export CSV',
    wattage_title: 'Printer wattage (W)',
    wattage_print: 'Nominal printing power (W)',
    wattage_idle: 'Idle power (W)',
    wattage_print_hint: 'Estimated average power while printing',
    wattage_idle_hint: 'Average power while idle (electronics/fans)',
    save_wattage: 'Save wattage',
    inefficiency_periods: 'Inefficiency periods',
    no_inefficiency: 'No inefficiency periods',
    reason: 'Reason',
    enter_reason: 'Enter reason...',
    save_reason: 'Save reason',
    efficiency_rules_hint: 'Efficiency: print gaps < 10 min, pauses < 7 min',
    confirm_delete_printer: 'Are you sure you want to delete printer',
    unknown_printer: 'Unknown printer',

    // New Efficiency Tab Translations
    energy_consumption_kwh: 'Energy Consumption (kWh)',
    hours: 'Hours',
    efficiency_overview: 'Efficiency Overview',
    efficiency_stats: 'Statistics',
    avg_efficiency: 'Average Efficiency',
    best_day: 'Best Day',
    worst_day: 'Worst Day',
    total_days: 'Total Days',
    efficiency_tips: 'Tips',
    eff_tip_good: 'Excellent efficiency! Your printers are well utilized.',
    eff_tip_medium: "Good efficiency, but there's room for improvement.",
    eff_tip_low: 'Low efficiency detected.',
    eff_tip_reduce_gaps: 'Reduce gaps between prints',
    eff_tip_batch: 'Consider batch printing',
    eff_tip_check_ineff: 'Check Inefficiency tab for details',
    eff_tip_schedule: 'Optimize print scheduling',
    eff_tip_minimize: 'Minimize idle time',
    no_data_available: 'No data available',
    all_printers: 'All Printers',

    // Bambu Lab Info Modal
    bambu_info_modal_title: '🎋 Bambu Lab',
    bambu_info_message:
      'Bambu Lab printers use mobile app <strong>Bambu Handy</strong> or <strong>Bambu Studio</strong> for control.',
    bambu_info_no_web: 'There is no local web interface available for this printer type.',
    bambu_info_help: 'Help',
    bambu_lab_setup_help: 'Bambu Lab Printer Setup',

    // Web Server
    web_server_btn_text: 'Web Server',
    web_server_modal_title: 'Web Server Settings',
    web_server_port_label: 'Server Port:',
    web_server_port_hint: 'Recommended: 8000-9000',
    web_server_status_checking: 'Checking...',
    web_server_status_running: '✅ Running',
    web_server_status_stopped: '⭕ Stopped',
    web_server_url_text: 'Web interface is available at:',
    web_server_clients_text: 'Connected clients:',
    web_server_what_is_it_title: 'What is this?',
    web_server_what_is_it_text:
      'Web server allows you to manage printers through a browser from any device on your local network. Just open the address on your computer, tablet or phone.',
    web_server_feature1: 'View status of all printers',
    web_server_feature2: 'Real-time monitoring',
    web_server_feature3: 'Access from any device on network',
    web_server_feature4: 'No installation required',
    web_server_btn_start: '▶️ Start',
    web_server_btn_stop: '🛑 Stop',
    web_server_btn_processing: 'Processing...',
    web_server_btn_open: 'Open in Browser',
    web_server_btn_help: '📖 Help',
    web_server_btn_close: 'Close',

    // Inefficiency Comment Modal
    ineff_comment_modal_title_add: '📝 Add Comment',
    ineff_comment_modal_title_edit: '✏️ Edit Comment',
    ineff_comment_type_label: 'Type:',
    ineff_comment_duration_label: 'Duration:',
    ineff_comment_period: 'Period:',
    ineff_comment_label: 'Comment / Reason:',
    ineff_comment_placeholder: 'Enter the reason for this inefficiency period...',
    ineff_comment_hint:
      '💡 Example: Material change, maintenance, waiting for parts, operator break, etc.',
    ineff_comment_save: '💾 Save Comment',
    ineff_comment_delete: '🗑️ Delete',
    ineff_comment_cancel: 'Cancel',
    ineff_status_no_comment: '📝 No Comment',
    ineff_status_has_comment: '✅ Commented',
    ineff_btn_add_comment: '➕ Add Comment',
    ineff_btn_edit_comment: '✏️ Edit',
    ineff_btn_view_comment: '👁️ View',
    ineff_type_gap: 'Gap between prints',
    ineff_type_pause: 'Pause during printing',
    ineff_comment_saved: 'Comment saved',
    ineff_comment_deleted: 'Comment deleted',

    // Clear Analytics Modal
    clear_analytics_title: '⚠️ Clear Analytics Data',
    clear_analytics_warning1: '⚠️ Warning! This action is irreversible!',
    clear_analytics_warning2: 'All analytics data will be permanently deleted, including:',
    clear_analytics_item1: 'Print and idle time history',
    clear_analytics_item2: 'All status transition events',
    clear_analytics_item3: 'Inefficiency periods and operator reports',
    clear_analytics_item4: 'Energy consumption statistics',
    clear_analytics_warning3: 'Power settings (wattage, cost per kWh) will be preserved.',
    clear_analytics_confirm: 'Are you sure you want to continue?',
    clear_analytics_yes: 'Yes, Clear All Data',
    clear_analytics_no: 'Cancel',

    // Analytics Help
    analytics_help: '❓ Help',
    analytics_help_title: 'Analytics Section Help',
    telegram_help_title: 'Telegram Bot Setup Help',
    bambu_help_title: 'Bambu Lab Printer Setup',
    analytics_help_content: `
            <div class="help-section">
                <h4>📊 Overview</h4>
                <p>The "Analytics" section allows you to track the efficiency of your 3D printers, analyze printing time, idle time, and energy consumption.</p>
            </div>
            
            <div class="help-section">
                <h4>📈 Key Performance Indicators (KPI)</h4>
                <ul>
                    <li><strong>Total print time</strong> — total active printing time for the selected period</li>
                    <li><strong>Total idle time</strong> — time when the printer was ready but not printing</li>
                    <li><strong>Efficiency</strong> — percentage of printing time from total available printer time</li>
                    <li><strong>Energy cost</strong> — calculated cost of consumed electricity</li>
                </ul>
            </div>
            
            <div class="help-section">
                <h4>⚡ Energy Tab</h4>
                <p>Displays detailed energy consumption information:</p>
                <ul>
                    <li>Total power consumption in kWh</li>
                    <li>Cost of consumed energy</li>
                    <li>Average daily consumption</li>
                </ul>
                <p><em>Note: for accurate calculations, you need to specify printer wattage in settings.</em></p>
            </div>
            
            <div class="help-section">
                <h4>📉 Inefficiency Tab</h4>
                <p>Shows periods when the printer was operating inefficiently:</p>
                <ul>
                    <li>Long pauses during printing (> 7 minutes)</li>
                    <li>Long gaps between prints (> 10 minutes)</li>
                </ul>
                <p>You can specify a reason for each inefficiency period to keep track.</p>
            </div>
            
            <div class="help-section">
                <h4>⚙️ Settings Tab</h4>
                <p>Settings for analytics calculations:</p>
                <ul>
                    <li><strong>Cost per 1 kWh</strong> — set your electricity tariff</li>
                    <li><strong>Printer wattage</strong> — nominal power when printing and in idle mode</li>
                    <li><strong>Clear data</strong> — delete all accumulated analytics data</li>
                </ul>
            </div>
            
            <div class="help-section">
                <h4>🔍 Filters</h4>
                <ul>
                    <li><strong>Period</strong> — select time interval for analysis (day, week, month, or custom)</li>
                    <li><strong>Printer</strong> — filter data by specific printer or view statistics for all</li>
                </ul>
            </div>
            
            <div class="help-section">
                <h4>💾 Data Export</h4>
                <p>Use the "Export CSV" button to save detailed statistics in CSV format for further analysis in Excel or other programs.</p>
            </div>
            
            <div class="help-section" style="background: #2a2a2a; padding: 15px; border-radius: 8px; border-left: 4px solid #00d4ff;">
                <h4>⚡ How to Calculate 3D Printer Power Consumption</h4>
                <p>For accurate energy consumption calculations, you need to know your printer's power consumption:</p>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">📋 Method 1: Manufacturer Specifications</h5>
                <ul>
                    <li>Check the printer's technical documentation</li>
                    <li>Look at the power supply label (Voltage × Amperage = Watts)</li>
                    <li>Example: 24V × 15A = 360W (nominal power)</li>
                </ul>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">📊 Method 2: Measurement with Power Meter</h5>
                <ul>
                    <li><strong>Recommended!</strong> Use a household wattmeter (smart plug with power measurement)</li>
                    <li>Connect the printer through the power meter</li>
                    <li>Measure actual consumption during printing (usually 50-70% of nominal)</li>
                    <li>Measure consumption in standby mode (usually 5-15W)</li>
                </ul>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">🔢 Method 3: Component Calculation</h5>
                <p>Sum the power of main components:</p>
                <ul>
                    <li><strong>Heated bed:</strong> usually 150-300W (depends on size)</li>
                    <li><strong>Hotend:</strong> usually 40-60W</li>
                    <li><strong>Stepper motors:</strong> 4-6 motors × 10-20W = 40-120W</li>
                    <li><strong>Electronics:</strong> boards, display ≈ 10-20W</li>
                    <li><strong>Fans:</strong> 2-5W each</li>
                    <li><strong>Lighting/camera:</strong> 5-10W (if present)</li>
                </ul>
                <p><em>Example calculation: 200W (bed) + 50W (hotend) + 80W (motors) + 15W (electronics) + 10W (fans) = 355W</em></p>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">💡 Typical Values for Different Printers</h5>
                <ul>
                    <li><strong>Small printers</strong> (Ender 3, Prusa Mini): 120-200W printing, 5-10W idle</li>
                    <li><strong>Medium printers</strong> (Prusa i3, Ender 5): 200-350W printing, 8-15W idle</li>
                    <li><strong>Large printers</strong> (CR-10, Voron): 350-600W printing, 10-20W idle</li>
                    <li><strong>Bambu Lab</strong> (X1, P1): 250-400W printing, 10-15W idle</li>
                </ul>
                
                <h5 style="color: #00d4ff; margin-top: 15px;">⚙️ Where to Enter Data</h5>
                <p>Go to <strong>Analytics → Settings</strong> and specify:</p>
                <ul>
                    <li><strong>Nominal printing power (W)</strong> — average power during active printing</li>
                    <li><strong>Idle power (W)</strong> — power when printer is on but not printing</li>
                </ul>
                <p style="margin-top: 10px; color: #888;"><em>💡 Tip: It's better to specify real measured values for more accurate energy cost calculations!</em></p>
            </div>
        `,

    // Temperature Sensors Modal
    temp_sensors_modal_title: 'Advanced Temperature Settings',
    temp_sensors_for_advanced: 'For advanced users:',
    temp_sensors_description: 'Customize which temperature sensors to display.',
    temp_sensors_auto_recommended:
      'Leave unchecked to use automatic detection (recommended for most users).',
    temp_sensors_tip: 'Tip:',
    temp_sensors_tip_text:
      "Select only the sensors you want to display. If you don't select any, the app will automatically detect chamber temperature by name. Most users don't need to change anything here.",
    temp_sensors_save_custom: 'Save Custom Selection',
    temp_sensors_use_auto: 'Use Auto Detection',
    temp_sensors_chamber_hint: '🏠 Chamber temperature',
    temp_sensors_mcu_hint: '🔧 Board temperature',
    temp_sensors_rpi_hint: '💻 Host computer',
    temp_sensors_room_hint: '🌡️ Ambient temperature',
    temp_sensors_generic_hint: '📊 Temperature sensor',

    // Power Off Confirmation
    power_off_confirm_title: 'Confirm Power Off',
    power_off_confirm_message: 'Are you sure you want to turn off the printer?',
    power_off_confirm_warning:
      '⚠️ This will cut power to the printer immediately. Make sure the print is complete or paused.',
    power_off_confirm_btn: 'Turn Off',

    // Update Checker
    update_available_title: 'New Version Available',
    update_new_version: 'A new version of the application is available!',
    update_current: 'Current version:',
    update_latest: 'Latest version:',
    update_recommendation: 'We recommend updating to get the latest features and improvements.',
    update_later: 'Later',
    update_download: 'Download Update',
    update_available_console: 'New version available',
    checking_updates: 'Checking for updates...',
    no_updates: 'You are running the latest version',
    update_check_error: 'Error checking for updates',
    update_up_to_date_title: "You're Up to Date!",
    update_no_updates_message: 'You are running the latest version!',
    update_no_updates_text:
      'Your application is up to date. Check back later for new features and improvements.',

    // Smart Plugs
    smart_plugs: 'Smart Plugs',
    smart_plugs_config: 'Smart Plugs Configuration',
    smart_plugs_settings: 'Settings',
    smart_plug_title: 'Smart Plug',
    plug_type: 'Connection type:',
    plug_not_configured: 'Not configured',
    plug_configure_first: 'Configure connection first:',
    plugs_connection_type: 'Connection Type:',
    plugs_choose_type: 'Choose how to connect your smart plugs:',
    plugs_tuya_desc: 'Direct connection to Tuya/Smart Life',
    plugs_ha_desc: 'Universal solution for all brands',
    plugs_easy_setup: 'Easy setup',
    plugs_tuya_devices: 'Tuya devices only',
    plugs_all_brands: 'All brands (Tuya, Yandex, etc.)',
    plugs_local_control: 'Local control',
    plugs_link_info:
      'To link a specific smart plug to a printer, open the printer settings and select the device from the list.',

    // Tuya
    tuya_select_device: 'Select Tuya device:',
    tuya_not_connected: 'Not connected',
    tuya_configure_first: 'Configure Tuya API first:',
    tuya_settings: 'Settings',
    tuya_automation: 'Automation:',
    tuya_auto_shutdown_complete: 'Auto-shutdown after print complete',
    tuya_shutdown_delay: 'Shutdown delay (minutes):',
    tuya_auto_shutdown_error: 'Auto-shutdown on print error',
    tuya_auto_shutdown_overheat: 'Auto-shutdown on overheat (MCU > 70°C)',
    tuya_preparation: 'Preparation:',
    tuya_step1: 'Register at',
    tuya_step2: 'Create Cloud Project',
    tuya_step3: 'Get Access ID and Access Secret',
    tuya_step4: 'Subscribe to Smart Home PaaS API',
    tuya_step5: 'Link your Smart Life account',
    tuya_region: 'Region:',
    tuya_access_id: 'Access ID:',
    tuya_access_secret: 'Access Secret:',
    tuya_encrypted: '⚠️ Will be stored encrypted',
    tuya_secret_saved_hint: '💡 If saved, will be shown as dots (click to edit)',
    tuya_test_connection: 'Test Connection',
    tuya_devices_not_found: 'No smart plugs found',

    // Home Assistant
    ha_preparation: 'Preparation:',
    ha_step1: 'Install Home Assistant',
    ha_step2: 'Add your smart plugs to HA',
    ha_step3: 'Get Long-Lived Access Token',
    ha_step4: 'Profile → Security → Create Token',
    ha_url: 'Home Assistant URL:',
    ha_url_hint: 'Usually: http://homeassistant.local:8123 or http://IP:8123',
    ha_token: 'Long-Lived Access Token:',
    ha_token_hint: 'Get from: Profile → Security → Long-lived access tokens',
    ha_token_saved_hint: '💡 If saved, will be shown as dots (click to edit)',
    ha_test_connection: 'Test Connection',
    ha_select_device: 'Select entity:',
    ha_not_connected: 'Not connected',
    ha_entities_not_found: 'No entities found',
    ha_configure_first: 'Configure Home Assistant API first:',
    saving: 'Saving...',
    settings_saved: 'Settings saved!',
    connection_success: 'Connection established!',
    fill_all_fields: 'Fill all fields',

    // Power Control
    power_control_error: 'Power control error',
    turn_on_power: 'Turn on power',
    turn_off_power: 'Turn off power',
    tuya_power_control: 'Power Control',

    // Telegram Smart Plugs Notifications
    telegram_power_events: 'Smart Plug Events:',
    telegram_notify_power_off: 'Auto power off',
    telegram_notify_emergency: 'Emergency shutdown (overheat)',

    // Network Scanner
    adding_printers: '⏳ Adding printers...',
    scan_modal_closed: 'Scan modal closed',

    // Bambu Lab Warning Modal
    bambu_warning_title: '⚠️ Important: Bambu Lab Setup',
    bambu_warning_message: 'To use Bambu Lab printers, you need to manually enter:',
    bambu_warning_step1: '1️⃣ <strong>Access Code</strong> - get it from printer settings → Network',
    bambu_warning_step2: '2️⃣ <strong>Serial Number</strong> - find it on the printer label',
    bambu_warning_step3: '3️⃣ Click ✏️ <strong>Edit</strong> on each Bambu Lab printer',
    bambu_warning_button: 'Got it',

    // Delete All Button
    deleteAllBtnText: 'Delete All',
    confirm_delete_all: 'Are you sure you want to delete ALL printers?',
    this_cannot_be_undone: 'This action cannot be undone!',
    all_printers_deleted: 'Deleted printers:',

    // Footer / License
    license_info: 'For commercial use, please contact the developer',

    // License Dialog Messages
    license_error_copy_hwid: 'Copy error. HWID: {hwid}',
    license_telegram_opened:
      '✅ Telegram bot opened!\n\n📋 NEXT STEPS:\n\n1️⃣ Write /start command to the bot\n2️⃣ Tell the bot your Hardware ID:\n   {hwid}\n\n3️⃣ Specify the desired plan: {plan}\n\n4️⃣ Admin will contact you to clarify payment\n5️⃣ After payment, the key will automatically come to the chat!\n\n⚠️ IMPORTANT - DISCLAIMER:\nBambu Lab printers have closed firmware.\nTheir operation with this program is NOT GUARANTEED and may be discontinued at any time for reasons beyond our control.\n\nBy purchasing a license, you agree to these terms.',
    license_email_copied: '✅ Text copied to clipboard!\n\nSend it to utolyana@ya.ru',
    license_email_copy_error: '❌ Copy error. Copy the text manually from the window below.',
    license_trial_process:
      "📋 TRIAL REQUEST PROCESS:\n\n1️⃣ Write /start command to @CP_licensing_bot (if you haven't already)\n2️⃣ Send the request (now)\n3️⃣ Admin will approve the request\n4️⃣ Trial key will automatically come to your bot chat\n5️⃣ Activate the key in the application\n\nContinue?",
    license_trial_sending: '⏳ Sending request...',
    license_trial_success: '✅ {message}',
    license_trial_error: '❌ Error: {message}',
    license_error_enter_key: 'Enter license key',
    license_error_invalid_format: 'Invalid key format. Key must start with 3DCP-',
    license_error_invalid_pattern:
      'Invalid key format. Expected: 3DCP-XXXX-XXXX-XXXX-XXXX-XXXX or 3DCP-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX',
    license_error_server_response: 'Server returned invalid response. Please try again later.',
    license_error_activation: 'Activation error',
    license_error_activation_status: 'Activation error ({status})',
    license_error_validation_failed: 'Validation failed',
    license_error_request_failed: 'Request sending error',
    license_activate_desc: 'Enter the key received from us via Telegram or Email',
    license_key_placeholder: '3DCP-XXXX-XXXX-XXXX-XXXX-XXXX',
    license_key_tooltip: 'You can paste via Ctrl+V or right-click',
    license_status_free_title: 'FREE version',
    license_status_free_message: 'Up to 10 printers - free',
    license_free_active: 'Already active',
    license_printer_disabled: '{name} — printer is disabled by license. Open the licensing window to unlock additional printers.',
    license_btn_request_trial: 'Request Trial',
    contact_modal_title: 'License Request',
    contact_modal_desc: 'Choose contact method to get your license:',
    contact_telegram_title: 'Telegram Bot',
    contact_telegram_fast: 'FAST',
    contact_telegram_desc:
      '✅ Automatic processing<br>✅ Response within hours<br>✅ Convenient communication',
    contact_email_title: 'Email',
    contact_email_slow: 'SLOW',
    contact_email_desc:
      '⚠️ Manual processing<br>⚠️ Response may take days<br>⚠️ Alternative if no Telegram',
    contact_recommendation: '💡 We recommend using Telegram for quick request processing',
    mass_print_btn: 'Send to Print',
    mass_print_title: '📤 Mass File Printing',
    mass_print_select_file: 'Select file to print:',
    mass_print_file_types: 'Supported formats: .gcode',
    mass_print_select_printers: 'Select printers:',
    mass_print_no_printers: 'No ready printers (status: ready/complete)',
    mass_print_ready: 'Ready',
    mass_print_printing: 'Printing',
    mass_print_offline: 'Offline',
    mass_print_error: 'Error',
    mass_print_send_btn: 'Send to Print',
    mass_print_cancel_btn: 'Cancel',
    mass_print_progress_title: 'Sending files...',
    mass_print_success: 'Files sent successfully!',
    mass_print_error_msg: 'Error sending files',
    massPrintHint: '🖨️ Send files to printers',

    // HMS Errors
    hms_errors: 'HMS Errors',
    loading_hms: 'Loading HMS status...',
    hms_hotend_temp_error: 'Hotend Temperature Error',
    hms_hotend_temp_desc: 'Hotend temperature is too high or too low',
    hms_hotend_temp_solution: 'Check hotend temperature sensor and wiring',
    hms_bed_temp_error: 'Bed Temperature Error',
    hms_bed_temp_desc: 'Bed temperature sensor malfunction',
    hms_bed_temp_solution: 'Check bed temperature sensor and wiring',
    hms_chamber_temp_error: 'Chamber Temperature Error',
    hms_chamber_temp_desc: 'Chamber temperature sensor issue',
    hms_chamber_temp_solution: 'Check chamber temperature sensor',
    hms_fan_error: 'Fan Error',
    hms_fan_desc: 'Fan malfunction detected',
    hms_fan_solution: 'Check fan connections and replace if necessary',
    hms_extruder_error: 'Extruder Error',
    hms_extruder_desc: 'Extruder motor or gear issue',
    hms_extruder_solution: 'Check extruder motor and gear assembly',
    hms_z_axis_error: 'Z-axis Error',
    hms_z_axis_desc: 'Z-axis movement issue',
    hms_z_axis_solution: 'Check Z-axis motor and lead screw',
    hms_x_axis_error: 'X-axis Error',
    hms_x_axis_desc: 'X-axis movement issue',
    hms_x_axis_solution: 'Check X-axis motor and belt tension',
    hms_y_axis_error: 'Y-axis Error',
    hms_y_axis_desc: 'Y-axis movement issue',
    hms_y_axis_solution: 'Check Y-axis motor and belt tension',
    hms_filament_runout: 'Filament Runout',
    hms_filament_runout_desc: 'No filament detected',
    hms_filament_runout_solution: 'Load new filament and resume print',
    hms_door_open: 'Door Open',
    hms_door_open_desc: 'Printer door is open',
    hms_door_open_solution: 'Close the printer door',
    hms_unknown_error: 'Unknown Error',
    hms_unknown_desc: 'HMS Error Code: {code}',
    hms_unknown_solution: 'Check printer manual or contact support',

    // Print Speed Control
    print_speed: 'Print Speed',
    current_speed: 'Normal (2)',
    speed_silent: 'Silent',
    speed_normal: 'Normal',
    speed_sport: 'Sport',
    speed_ludicrous: 'Ludicrous',

    // Temperature Control
    temperature_control: 'Temperature Control',
    nozzle_temperature: 'Nozzle Temperature (°C)',
    bed_temperature: 'Bed Temperature (°C)',
    set_temperature: 'Set',

    // Fan Control
    fan_control: 'Fan Control',
    chamber_fan: 'Chamber Fan (%)',
    aux_fan: 'Aux Fan (%)',
    cooling_fan: 'Cooling Fan (%)',

    // Camera Controls
    live_camera: 'Live Camera',
    turn_led_on: 'Turn LED On',
    turn_led_off: 'Turn LED Off',
    save_screenshot: 'Save Screenshot',
    loading_camera: 'Loading camera stream...',
    camera_timeout: 'Camera timeout',
    camera_timeout_desc:
      'No camera data received within 10 seconds. This may indicate a platform-specific issue.',
    camera_error: 'Camera Error',
    camera_not_available: 'Camera stream is not available or printer is offline',
    debug_info: 'Debug Info',
    platform: 'Platform',
    time: 'Time',
    user_agent: 'User Agent',
    data_size: 'Data Size',

    // File Upload
    file_upload: 'File Upload',
    select_file: 'Select File',
    upload_file: 'Upload File',
    uploading_file: 'Uploading file...',
    upload_success: 'File uploaded successfully',
    upload_error: 'File upload error',
    start_print: 'Start Print',
    printing_file: 'Printing file...',
    print_started: 'Print started',
    print_error: 'Print start error',
    supported_formats: 'Supported formats: .gcode, .3mf',
    file_size_limit: 'Maximum file size: 100MB',

    // Unsupported Model
    unsupported_model: 'Unsupported Model',
    unsupported_model_desc:
      'This Bambu Lab model (A1/X1 series) is not fully supported by the current library.',
    unsupported_model_features:
      'Basic monitoring is available, but advanced features like file upload, LED control, and fan management are not available.',
    print_progress: 'Print Progress',
    print_details: 'Print Details',
    temperatures: 'Temperatures',
    remaining_time: 'Remaining Time',
    current_layer: 'Current Layer',
    print_speed_label: 'Print Speed',
    no_file: 'No file',
    target: 'Target',
    ambient: 'Ambient',
    ip_address: 'IP Address',
    serial_number: 'Serial Number',
    connection: 'Connection',
    camera: 'Camera',
    last_update: 'Last Update',
    live_camera: 'Live Camera',
    camera_image_not_available: 'Camera image not available',
  },
};

// Export functions
// export { getTranslation, updateLanguage };

// Функция для получения языка (сохраненный или системный)
async function getAppLanguage() {
  try {
    // Пытаемся получить сохраненный язык
    if (window.electronAPI && window.electronAPI.storeGet) {
      const savedLang = await window.electronAPI.storeGet('appLanguage', null);
      if (savedLang) {
        return savedLang;
      }
    }

    // Если сохраненного языка нет, определяем системный
    const systemLang = navigator.language || navigator.languages[0] || 'en';
    const langCode = systemLang.split('-')[0].toLowerCase();

    // Поддерживаемые языки
    const supportedLangs = ['ru', 'en'];
    return supportedLangs.includes(langCode) ? langCode : 'en';
  } catch (error) {
    console.error('Error getting app language:', error);
    return 'en';
  }
}

// Функция для получения перевода
function t(key) {
  if (TRANSLATIONS[BROWSER_LANGUAGE] && TRANSLATIONS[BROWSER_LANGUAGE][key]) {
    return TRANSLATIONS[BROWSER_LANGUAGE][key];
  }

  // Fallback на английский
  if (TRANSLATIONS.en && TRANSLATIONS.en[key]) {
    return TRANSLATIONS.en[key];
  }

  // Если перевод не найден, возвращаем ключ
  return key;
}

// Глобальная функция для получения перевода
function getTranslation(key) {
  return t(key);
}

// Функция для обновления языка
async function updateLanguage(lang) {
  BROWSER_LANGUAGE = lang;
  // Перерисовываем интерфейс
  if (typeof updateInterfaceLanguage === 'function') {
    updateInterfaceLanguage();
  }
}

// Инициализируем язык при загрузке
(function initLanguage() {
  try {
    // Определяем язык из навигатора
    const systemLang = navigator.language || navigator.languages[0] || 'en';
    const langCode = systemLang.split('-')[0].toLowerCase();

    // Поддерживаемые языки
    const supportedLangs = ['ru', 'en'];
    BROWSER_LANGUAGE = supportedLangs.includes(langCode) ? langCode : 'ru'; // По умолчанию русский

    console.log(
      '[Translations] Initialized language:',
      BROWSER_LANGUAGE,
      'from system:',
      systemLang,
    );
  } catch (error) {
    console.error('[Translations] Error initializing language:', error);
    BROWSER_LANGUAGE = 'ru'; // По умолчанию русский
  }
})();
