import { app, BrowserWindow, ipcMain, shell, Menu, dialog } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import { readFileSync } from 'fs';
import https from 'https';
import http from 'http';
import os from 'os';
import Store from 'electron-store';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const packageJson = JSON.parse(readFileSync(path.join(__dirname, '../package.json'), 'utf-8'));
const APP_VERSION = packageJson.version;

// Локальные модули
import { encrypt, decrypt } from './encryption.js';
import DiagnosticsReporter from './diagnostics.js';
import BambuLabAdapter from './bambu-printer-adapter.js';
import TuyaAdapter from './tuya-adapter.js';
import HomeAssistantAdapter from './homeassistant-adapter.js';
import WebServer from './web-server.js';
import {
  initLicensing,
  getLicenseStatus,
  checkLicense,
  canAddPrinter,
  activateLicense,
  requestLicense,
} from './licensing.js';
import { generateHWID, getSystemInfo, formatHWID } from './hwid.js';
import { autoMigrate, forceCleanup } from './data-migration.js';

const store = new Store();
const reporter = new DiagnosticsReporter();

let mainWindow;
let tabsWindow = null;
const printerTabs = new Map();

const bambuConnections = new Map();
const tuyaConnections = new Map();
let globalTuyaAdapter = null;
let globalHomeAssistantAdapter = null;

import { StructuredPrinterManager } from './data-structures.js';
const structuredManager = new StructuredPrinterManager(store, bambuConnections);
const webServer = new WebServer(store, bambuConnections, structuredManager);
let isWebServerEnabled = false;

// ============================================================================
// TABLE OF CONTENTS - Main Application Entry Point (Electron Main Process)
// ============================================================================
//
// DOMAIN 1: APPLICATION INITIALIZATION & LIFECYCLE (Lines 176-273)
//  1.1 Single Instance Lock (176-188)
//  1.2 Data Migration & Integrity (190-273)
//      - performStartupMigration() (191-215)
//      - diagnoseDataIntegrity() (217-273)
//
// DOMAIN 2: WINDOW MANAGEMENT (Lines 275-1610)
//  2.1 Main Window (275-364)
//      - createMainWindow() (275-309)
//      - getIconPath() (311-320)
//      - getSavedLanguage() (323-338)
//      - setLanguage() (341-363)
//  2.2 Application Menu (364-1493)
//      - createApplicationMenu() (364-512)
//      - showTelegramHelp() (514-952)
//      - showBambuLabHelp() (953-1497)
//  2.3 Update Checker (1499-1625)
//      - checkForUpdatesAPI() (1499-1610)
//      - compareVersions() (1611-1624)
//  2.4 Tabs Window (1626-1738)
//      - createTabsWindow() (1626-1670)
//      - addPrinterTab() (1671-1712)
//      - focusPrinterTab() (1713-1737)
//
// DOMAIN 3: BAMBU LAB INTEGRATION (Lines 1740-2845)
//  3.1 MQTT Connection Management (1740-2051)
//      - testBambuConnection() (1745-1805)
//      - closeBambuConnection() (1806-1817)
//      - getBambuPrinterData() (1818-1853)
//      - requestBambuStatus() (1854-1861)
//  3.2 IPC Handlers (2052-2084)
//      - test-bambu-connection, close-bambu-connection
//      - get-bambu-printer-data, request-bambu-status
//  3.3 Camera Management (2846-3082)
//      - fetchBambuCamera() (2858-2977)
//      - startCameraUpdates() (2978-3059)
//      - stopCameraUpdates() (3060-3068)
//      - IPC handlers: start-camera-updates, stop-camera-updates
//      - bambu-control (3083-3162)
//  3.4 File Operations (3163-3212)
//      - bambu-upload-file (3163-3187)
//      - bambu-start-print (3188-3211)
//
// DOMAIN 4: SMART PLUGS INTEGRATION (Lines 2084-2529)
//  4.1 Tuya Cloud IPC Handlers (2084-2297)
//      - setup-tuya, tuya-get-devices, tuya-link-device, tuya-unlink-device
//      - tuya-control-device, tuya-get-energy-stats, tuya-get-device-status
//  4.2 Home Assistant IPC Handlers (2297-2529)
//      - setup-homeassistant, ha-get-switches, ha-control-switch
//      - ha-get-switch-status, ha-link-device, ha-unlink-device
//      - ha-reconnect, reconnectHomeAssistant()
//
// DOMAIN 5: AUTOMATION & EVENT HANDLERS (Lines 2530-3453)
//  5.1 Tuya Automation (2530-2735)
//      - handlePrintComplete() (2540-2611)
//      - handlePrintError() (2612-2661)
//      - handleOverheat() (2662-2719)
//      - cancelScheduledShutdown() (2720-2735)
//  5.2 Menu Event Handlers (2736-2765)
//      - menu-add-printer, menu-test-all, show-telegram-help, show-bambu-help
//  5.3 Bambu Interface Communication (2766-2845)
//      - bambu-interface-ready, request-bambu-data
//      - sendBambuDataToInterface() (2777-2844)
//      - send-bambu-data
//
// DOMAIN 6: DIAGNOSTICS & TELEMETRY (Lines 3213-3288)
//  6.1 IPC Handlers (3213-3287)
//      - diagnostics-track-printer-added, diagnostics-update-printers
//      - diagnostics-track-feature, diagnostics-track-analytics-view
//      - diagnostics-track-export, diagnostics-track-smartplug-config
//      - diagnostics-update-smartplugs-stats, diagnostics-track-batch-add
//      - diagnostics-track-network-scan, diagnostics-track-print-event
//      - diagnostics-update-temperatures, diagnostics-track-manual-plug-toggle
//      - diagnostics-track-webserver-start, diagnostics-track-analytics-open
//      - diagnostics-track-help-page-open, diagnostics-force-sync
//      - diagnostics-set-theme, diagnostics-set-webserver
//
// DOMAIN 7: WEB SERVER (Lines 3289-3452)
//  7.1 Management Functions (3294-3451)
//      - start-web-server (3294-3335)
//      - stop-web-server (3336-3361)
//      - get-web-server-info (3366-3368)
//      - open-web-interface (3373-3380)
//      - open-external-link (3385-3393)
//      - get-network-interfaces (3398-3417)
//      - notifyWebServerPrinterUpdate() (3418-3427)
//      - notifyWebServerPrinterStatus() (3428-3436)
//      - update-printer-data (3437-3451)
//
// DOMAIN 8: UPDATE CHECKER (Lines 3454-3557)
//  8.1 Functions (3459-3555)
//      - checkForUpdates() (3459-3527)
//      - compareVersionsAPI() (3528-3545)
//      - IPC handlers: check-for-updates, open-release-page
//
// DOMAIN 9: IPC GENERAL HANDLERS (Lines 1862-2028)
//  9.1 Window & Navigation (1862-1931)
//      - open-external, open-printer-window, focus-printer-window
//      - close-printer-tab, focus-main-window
//  9.2 Application Info (1931-2028)
//      - get-app-version, store-get, store-set
//      - migrate-data, force-cleanup, diagnose-data
//      - encrypt-data, decrypt-data, scan-network
//
// DOMAIN 10: LICENSING SYSTEM (Lines 3558-3595)
//  10.1 IPC Handlers (3563-3595)
//      - licensing-init, licensing-get-status, licensing-check
//      - licensing-can-add-printer, licensing-activate
//      - licensing-request, licensing-get-hwid
//
// DOMAIN 11: APPLICATION LIFECYCLE EVENTS (Lines 3596-3749)
//  11.1 Startup (3596-3716)
//      - app.whenReady() with initialization
//      - Auto-start web server, Tuya, Home Assistant adapters
//      - Update checker on startup
//  11.2 Shutdown (3718-3749)
//      - window-all-closed handler
//      - before-quit cleanup (web server, connections)
//
// ============================================================================

// Single instance lock - должен быть в начале
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', (event, commandLine, workingDirectory) => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

// Автоматическая миграция данных при запуске
async function performStartupMigration() {
  try {
    // Тихо проверяем целостность данных
    const diagnostics = await diagnoseDataIntegrity();

    // Выполняем миграцию только если есть проблемы
    if (!diagnostics.isValid) {
      const result = await autoMigrate();

      if (result.success && !result.skipped) {
        console.log('[DataMigration] ✅ Fixed data issues automatically');
      }
    }
  } catch (error) {
    // Только при критических ошибках показываем в консоли
    console.error('[DataMigration] ❌ Critical error:', error.message);

    try {
      await forceCleanup();
      console.log('[DataMigration] ✅ Reset to defaults');
    } catch (cleanupError) {
      console.error('[DataMigration] ❌ Reset failed:', cleanupError.message);
    }
  }
}

// Функция диагностики целостности данных
async function diagnoseDataIntegrity() {
  const issues = [];
  const data = {};

  try {
    // Check printers data
    const printers = store.get('printers', []);
    data.printers = printers;
    if (!Array.isArray(printers)) {
      issues.push('printers: not an array');
    } else {
      printers.forEach((printer, index) => {
        if (!printer.id || !printer.name || !printer.ip) {
          issues.push(`printer[${index}]: missing required fields`);
        }
      });
    }

    // Check license data
    const license = store.get('license');
    data.license = license;
    if (license && typeof license !== 'object') {
      issues.push('license: invalid format');
    }

    // Check analytics data
    const analytics = store.get('analytics');
    data.analytics = analytics;
    if (analytics && typeof analytics !== 'object') {
      issues.push('analytics: invalid format');
    }

    // Check data version
    const dataVersion = store.get('dataVersion');
    data.dataVersion = dataVersion;

    return {
      isValid: issues.length === 0,
      issues,
      data,
      summary: {
        printersCount: Array.isArray(printers) ? printers.length : 0,
        hasLicense: !!license,
        hasAnalytics: !!analytics,
        dataVersion: dataVersion || 'Unknown',
      },
    };
  } catch (error) {
    return {
      isValid: false,
      issues: [`diagnosis error: ${error.message}`],
      data: {},
      summary: {},
    };
  }
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.resolve(__dirname, 'preload.cjs'),
    },
    icon: getIconPath(),
    title: `3D Printer Control Panel v${APP_VERSION}`,
    show: false,
  });

  mainWindow.loadFile('src/index.html');

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  if (process.argv.includes('--dev')) {
    // mainWindow.webContents.openDevTools(); // Отключено для продакшена
  }

  createApplicationMenu();

  mainWindow.on('closed', () => {
    if (tabsWindow && !tabsWindow.isDestroyed()) {
      tabsWindow.close();
    }
    mainWindow = null;
  });
}

function getIconPath() {
  switch (process.platform) {
    case 'darwin':
      return path.join(__dirname, '../icons/icon.icns');
    case 'win32':
      return path.join(__dirname, '../icons/icon.ico');
    default:
      return path.join(__dirname, '../icons/icon.png');
  }
}

// Функция для получения сохраненного или системного языка
function getSavedLanguage() {
  // Сначала проверяем сохраненный выбор пользователя
  const savedLang = store.get('appLanguage', null);
  if (savedLang) {
    return savedLang;
  }

  // Если нет сохраненного, определяем системный
  try {
    const locale = app.getLocale();
    return locale.toLowerCase().includes('ru') ? 'ru' : 'en';
  } catch (error) {
    console.log('Could not determine locale, using English as default');
    return 'en';
  }
}

// Функция для установки языка
function setLanguage(lang) {
  store.set('appLanguage', lang);

  // Пересоздаем меню
  createApplicationMenu();

  // Уведомляем renderer процесс об изменении языка
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('language-changed', lang);
  }

  // Показываем уведомление
  const isRussian = lang === 'ru';
  dialog.showMessageBox(mainWindow, {
    type: 'info',
    title: isRussian ? 'Язык изменен' : 'Language Changed',
    message: isRussian
      ? 'Язык программы изменен. Для полного применения изменений перезапустите программу.'
      : 'Application language has been changed. Please restart the application for full effect.',
    buttons: ['OK'],
  });
}

function createApplicationMenu() {
  const currentLang = getSavedLanguage();
  const isRussian = currentLang === 'ru';

  const template = [
    {
      label: isRussian ? 'Файл' : 'File',
      submenu: [
        {
          label: isRussian ? 'Добавить принтер' : 'Add Printer',
          accelerator: 'CmdOrCtrl+N',
          click: () => {
            if (mainWindow) {
              mainWindow.webContents.send('menu-add-printer');
            }
          },
        },
        {
          label: isRussian ? 'Проверить все подключения' : 'Test All Connections',
          accelerator: 'CmdOrCtrl+T',
          click: () => {
            if (mainWindow) {
              mainWindow.webContents.send('menu-test-all');
            }
          },
        },
        { type: 'separator' },
        {
          label: isRussian ? 'Настройки Telegram' : 'Telegram Settings',
          accelerator: 'CmdOrCtrl+Shift+T',
          click: () => {
            if (mainWindow) {
              mainWindow.webContents.executeJavaScript('openTelegramSettingsModal()');
            }
          },
        },
        { type: 'separator' },
        {
          label: isRussian ? 'Выход' : 'Exit',
          accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Ctrl+Q',
          click: () => {
            app.quit();
          },
        },
      ],
    },
    {
      label: isRussian ? 'Вид' : 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' },
      ],
    },
    {
      label: isRussian ? 'Окно' : 'Window',
      submenu: [{ role: 'minimize' }, { role: 'close' }],
    },
    {
      label: 'Language',
      submenu: [
        {
          label: '🇷🇺 Русский',
          type: 'radio',
          checked: isRussian,
          click: () => {
            setLanguage('ru');
          },
        },
        {
          label: '🇬🇧 English',
          type: 'radio',
          checked: !isRussian,
          click: () => {
            setLanguage('en');
          },
        },
      ],
    },
    {
      label: isRussian ? 'Помощь' : 'Help',
      submenu: [
        {
          label: isRussian ? 'Помощь' : 'Help',
          click: () => {
            if (mainWindow) {
              mainWindow.webContents.send('show-telegram-help-modal');
            }
          },
        },
        {
          label: isRussian ? 'Настройка принтеров Bambu Lab' : 'Bambu Lab Printer Setup',
          click: () => {
            if (mainWindow) {
              mainWindow.webContents.send('show-bambu-help-modal');
            }
          },
        },
        { type: 'separator' },
        {
          label: isRussian ? 'Проверить обновления' : 'Check for Updates',
          click: () => {
            if (mainWindow) {
              mainWindow.webContents.send('check-updates-menu');
            }
          },
        },
        { type: 'separator' },
        {
          label: isRussian ? 'Диагностика данных' : 'Data Diagnostics',
          click: () => {
            const diagnosticsWindow = new BrowserWindow({
              width: 900,
              height: 700,
              parent: mainWindow,
              modal: true,
              webPreferences: {
                nodeIntegration: true,
                contextIsolation: false,
                enableRemoteModule: true,
                preload: path.join(__dirname, 'preload.cjs'),
              },
            });
            diagnosticsWindow.loadFile('src/data-diagnostics.html');
          },
        },
        { type: 'separator' },
        {
          label: isRussian
            ? 'О программе 3D Printer Control Panel'
            : 'About 3D Printer Control Panel',
          click: () => {
            shell.openExternal('https://github.com/Tombraider2006/KCP');
          },
        },
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

function showTelegramHelp(isRussian) {
  const helpWindow = new BrowserWindow({
    width: 700,
    height: 900,
    parent: mainWindow,
    modal: true,
    resizable: true,
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
    title: isRussian ? 'Помощь по настройке Telegram бота' : 'Telegram Bot Setup Help',
  });

  const helpContent = isRussian
    ? `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Помощь по настройке Telegram бота</title>
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                padding: 25px; 
                line-height: 1.6;
                color: #333;
                background: #f5f5f5;
            }
            .container {
                max-width: 650px;
                margin: 0 auto;
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 { color: #0088cc; text-align: center; margin-bottom: 30px; }
            h2 { color: #555; margin-top: 25px; padding-bottom: 8px; border-bottom: 2px solid #0088cc; }
            .step { 
                background: #f8f9fa; 
                padding: 20px; 
                margin: 15px 0; 
                border-radius: 8px;
                border-left: 4px solid #0088cc;
            }
            code { 
                background: #2d2d2d; 
                color: #fff; 
                padding: 12px; 
                display: block; 
                border-radius: 6px;
                margin: 12px 0;
                font-family: 'Courier New', monospace;
                font-size: 14px;
                overflow-x: auto;
            }
            .note { 
                background: #e3f2fd; 
                border: 1px solid #bbdefb; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            .warning { 
                background: #fff3cd; 
                border: 1px solid #ffeaa7; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            .success { 
                background: #d4edda; 
                border: 1px solid #c3e6cb; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            ul { padding-left: 20px; }
            li { margin: 8px 0; }
            .icon { font-size: 18px; margin-right: 8px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🤖 Помощь по настройке Telegram бота</h1>
            
            <h2>📋 Шаг 1: Создание бота в Telegram</h2>
            <div class="step">
                <p><span class="icon">1.</span> Откройте Telegram и найдите <strong>@BotFather</strong></p>
                <p><span class="icon">2.</span> Отправьте команду: <code>/newbot</code></p>
                <p><span class="icon">3.</span> Следуйте инструкциям чтобы выбрать имя и username для вашего бота</p>
                <p><span class="icon">4.</span> После создания вы получите <strong>Токен бота</strong> - сохраните его!</p>
                <div class="note">
                    💡 <strong>Пример токена:</strong> <code>1234567890:ABCdefGHIjklMNopQRstUVwxyz</code>
                </div>
            </div>

            <h2>🆔 Шаг 2: Получение вашего Chat ID</h2>
            <div class="step">
                <p><strong>Способ 1 (простой):</strong></p>
                <p><span class="icon">1.</span> Найдите бота <strong>@userinfobot</strong> в Telegram</p>
                <p><span class="icon">2.</span> Отправьте ему команду <code>/start</code></p>
                <p><span class="icon">3.</span> Он покажет ваш Chat ID - скопируйте его</p>
                
                <p><strong>Способ 2 (через API):</strong></p>
                <p><span class="icon">1.</span> Начните диалог с вашим новым ботом</p>
                <p><span class="icon">2.</span> Отправьте команду: <code>/start</code></p>
                <p><span class="icon">3.</span> Откройте этот URL в браузере (замените YOUR_BOT_TOKEN):</p>
                <code>https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates</code>
                <p><span class="icon">4.</span> Найдите объект "chat" и скопируйте значение "id"</p>
            </div>

            <h2>📢 Шаг 3: Добавление бота в канал (опционально)</h2>
            <div class="step">
                <p><strong>Если вы хотите получать уведомления в канал Telegram:</strong></p>
                
                <p><strong>Создание и настройка канала:</strong></p>
                <p><span class="icon">1.</span> Создайте канал в Telegram (через меню → Новый канал)</p>
                <p><span class="icon">2.</span> Назовите канал (например, "3D Printer Notifications")</p>
                <p><span class="icon">3.</span> Выберите тип канала: <strong>Приватный</strong> или <strong>Публичный</strong></p>
                
                <p><strong>Добавление бота администратором:</strong></p>
                <p><span class="icon">1.</span> Откройте настройки канала (⋮ → Управление каналом)</p>
                <p><span class="icon">2.</span> Перейдите в <strong>Администраторы</strong> → Добавить администратора</p>
                <p><span class="icon">3.</span> Найдите и выберите вашего бота (по username)</p>
                <p><span class="icon">4.</span> Выдайте права: минимум нужно <strong>"Публикация сообщений"</strong></p>
                <p><span class="icon">5.</span> Сохраните изменения</p>
                
                <p><strong>Получение Chat ID канала:</strong></p>
                <p><span class="icon">1.</span> Опубликуйте любое сообщение в канале</p>
                <p><span class="icon">2.</span> Перешлите это сообщение боту <strong>@userinfobot</strong></p>
                <p><span class="icon">3.</span> Он покажет Chat ID канала (начинается с <code>-100</code>)</p>
                <div class="note">
                    💡 <strong>Пример Chat ID канала:</strong> <code>-1001234567890</code> (отрицательное число для каналов и групп)
                </div>
                
                <p><strong>Альтернативный способ через API:</strong></p>
                <p><span class="icon">1.</span> Добавьте бота администратором канала</p>
                <p><span class="icon">2.</span> Отправьте любое сообщение в канал</p>
                <p><span class="icon">3.</span> Откройте в браузере:</p>
                <code>https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates</code>
                <p><span class="icon">4.</span> Найдите в JSON объект "chat" с типом "channel" и скопируйте "id"</p>
                
                <div class="warning">
                    ⚠️ <strong>Важно для каналов:</strong>
                    <ul>
                        <li>Chat ID канала всегда отрицательный и начинается с <code>-100</code></li>
                        <li>Бот должен быть администратором канала с правами на публикацию</li>
                        <li>Используйте Chat ID канала вместо личного ID в настройках</li>
                    </ul>
                </div>
            </div>

            <h2>⚙️ Шаг 4: Настройка в программе</h2>
            <div class="step">
                <p><span class="icon">1.</span> Нажмите кнопку "🤖 Telegram" в главном окне</p>
                <p><span class="icon">2.</span> Введите ваш Токен бота и Chat ID (личный или канала)</p>
                <p><span class="icon">3.</span> Выберите какие уведомления вы хотите получать</p>
                <p><span class="icon">4.</span> Нажмите "Проверить соединение" для проверки</p>
                <p><span class="icon">5.</span> Сохраните настройки</p>
                <div class="success">
                    ✅ <strong>Готово!</strong> Теперь вы будете получать уведомления о статусе ваших принтеров
                </div>
            </div>

            <h2>🔔 Поддерживаемые уведомления</h2>
            
            <h3>📄 Уведомления о печати:</h3>
            <ul>
                <li>✅ <strong>Завершение печати</strong> - когда печать успешно завершена</li>
                <li>❌ <strong>Ошибка печати</strong> - когда возникает ошибка во время печати</li>
                <li>⏸️ <strong>Пауза печати</strong> - когда печать поставлена на паузу</li>
            </ul>
            
            <h3>🖨️ Уведомления о принтере:</h3>
            <ul>
                <li>🔌 <strong>Принтер offline</strong> - когда принтер отключается (опционально)</li>
                <li>🟢 <strong>Принтер online</strong> - когда принтер подключается (опционально)</li>
            </ul>
            
            <h3>📊 Уведомления об эффективности:</h3>
            <ul>
                <li>⚠️ <strong>Событие неэффективности</strong> - автоматически обнаруживает:
                    <ul>
                        <li><strong>Gap</strong> (перерыв между печатями более 10 минут)</li>
                        <li><strong>Pause</strong> (пауза во время печати более 7 минут)</li>
                    </ul>
                </li>
                <li>📝 <strong>Отчет оператора</strong> - когда оператор сохраняет причину неэффективности в разделе Аналитика</li>
            </ul>
            
            <h3>⚙️ Системные уведомления:</h3>
            <ul>
                <li>🚀 <strong>Запуск программы</strong> - отправляется при старте программы (включает версию и количество принтеров)</li>
            </ul>

            <div class="warning">
                <strong>Важно:</strong> Убедитесь что у вашего бота отключен режим конфиденциальности (Privacy mode), 
                если вы хотите получать от него сообщения. Это можно настроить через @BotFather командой <code>/setprivacy</code> → <code>Disable</code>.
            </div>

            <div class="note">
                <strong>Совет:</strong> Для тестирования вы можете временно включить все типы уведомлений, 
                а после настройки оставить только нужные.
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <button onclick="window.close()" class="close-btn">
                    ✅ Закрыть
                </button>
            </div>
        </div>
    </body>
    </html>
  `
    : `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Telegram Bot Setup Help</title>
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                padding: 25px; 
                line-height: 1.6;
                color: #333;
                background: #f5f5f5;
            }
            .container {
                max-width: 650px;
                margin: 0 auto;
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 { color: #0088cc; text-align: center; margin-bottom: 30px; }
            h2 { color: #555; margin-top: 25px; padding-bottom: 8px; border-bottom: 2px solid #0088cc; }
            .step { 
                background: #f8f9fa; 
                padding: 20px; 
                margin: 15px 0; 
                border-radius: 8px;
                border-left: 4px solid #0088cc;
            }
            code { 
                background: #2d2d2d; 
                color: #fff; 
                padding: 12px; 
                display: block; 
                border-radius: 6px;
                margin: 12px 0;
                font-family: 'Courier New', monospace;
                font-size: 14px;
                overflow-x: auto;
            }
            .note { 
                background: #e3f2fd; 
                border: 1px solid #bbdefb; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            .warning { 
                background: #fff3cd; 
                border: 1px solid #ffeaa7; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            .success { 
                background: #d4edda; 
                border: 1px solid #c3e6cb; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            ul { padding-left: 20px; }
            li { margin: 8px 0; }
            .icon { font-size: 18px; margin-right: 8px; }
            .close-btn {
                background: #0088cc;
                color: white;
                border: none;
                padding: 12px 30px;
                border-radius: 6px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                box-shadow: 0 2px 8px rgba(0,136,204,0.3);
                transition: all 0.3s ease;
            }
            .close-btn:hover {
                background: #0099dd;
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,136,204,0.5);
            }
            .close-btn:active {
                transform: translateY(0);
                box-shadow: 0 2px 6px rgba(0,136,204,0.4);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🤖 Telegram Bot Setup Help</h1>
            
            <h2>📋 Step 1: Create a Telegram Bot</h2>
            <div class="step">
                <p><span class="icon">1.</span> Open Telegram and search for <strong>@BotFather</strong></p>
                <p><span class="icon">2.</span> Send the command: <code>/newbot</code></p>
                <p><span class="icon">3.</span> Follow the instructions to choose a name and username for your bot</p>
                <p><span class="icon">4.</span> After creation, you'll receive a <strong>Bot Token</strong> - save it!</p>
                <div class="note">
                    💡 <strong>Token example:</strong> <code>1234567890:ABCdefGHIjklMNopQRstUVwxyz</code>
                </div>
            </div>

            <h2>🆔 Step 2: Get Your Chat ID</h2>
            <div class="step">
                <p><strong>Method 1 (easy):</strong></p>
                <p><span class="icon">1.</span> Search for <strong>@userinfobot</strong> in Telegram</p>
                <p><span class="icon">2.</span> Send it the <code>/start</code> command</p>
                <p><span class="icon">3.</span> It will show your Chat ID - copy it</p>
                
                <p><strong>Method 2 (via API):</strong></p>
                <p><span class="icon">1.</span> Start a conversation with your new bot</p>
                <p><span class="icon">2.</span> Send the command: <code>/start</code></p>
                <p><span class="icon">3.</span> Open this URL in your browser (replace YOUR_BOT_TOKEN):</p>
                <code>https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates</code>
                <p><span class="icon">4.</span> Look for the "chat" object and copy the "id" value</p>
            </div>

            <h2>📢 Step 3: Add Bot to Channel (Optional)</h2>
            <div class="step">
                <p><strong>If you want to receive notifications in a Telegram channel:</strong></p>
                
                <p><strong>Create and configure channel:</strong></p>
                <p><span class="icon">1.</span> Create a channel in Telegram (menu → New Channel)</p>
                <p><span class="icon">2.</span> Name your channel (e.g., "3D Printer Notifications")</p>
                <p><span class="icon">3.</span> Choose channel type: <strong>Private</strong> or <strong>Public</strong></p>
                
                <p><strong>Add bot as administrator:</strong></p>
                <p><span class="icon">1.</span> Open channel settings (⋮ → Manage Channel)</p>
                <p><span class="icon">2.</span> Go to <strong>Administrators</strong> → Add Administrator</p>
                <p><span class="icon">3.</span> Find and select your bot (by username)</p>
                <p><span class="icon">4.</span> Grant permissions: minimum required is <strong>"Post Messages"</strong></p>
                <p><span class="icon">5.</span> Save changes</p>
                
                <p><strong>Get channel Chat ID:</strong></p>
                <p><span class="icon">1.</span> Post any message in the channel</p>
                <p><span class="icon">2.</span> Forward this message to <strong>@userinfobot</strong></p>
                <p><span class="icon">3.</span> It will show the channel Chat ID (starts with <code>-100</code>)</p>
                <div class="note">
                    💡 <strong>Channel Chat ID example:</strong> <code>-1001234567890</code> (negative number for channels and groups)
                </div>
                
                <p><strong>Alternative method via API:</strong></p>
                <p><span class="icon">1.</span> Add bot as channel administrator</p>
                <p><span class="icon">2.</span> Post any message to the channel</p>
                <p><span class="icon">3.</span> Open in browser:</p>
                <code>https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates</code>
                <p><span class="icon">4.</span> Find the "chat" object with type "channel" and copy the "id"</p>
                
                <div class="warning">
                    ⚠️ <strong>Important for channels:</strong>
                    <ul>
                        <li>Channel Chat ID is always negative and starts with <code>-100</code></li>
                        <li>Bot must be channel administrator with posting permissions</li>
                        <li>Use channel Chat ID instead of personal ID in settings</li>
                    </ul>
                </div>
            </div>

            <h2>⚙️ Step 4: Configure in the App</h2>
            <div class="step">
                <p><span class="icon">1.</span> Click the "🤖 Telegram" button in the main window</p>
                <p><span class="icon">2.</span> Enter your Bot Token and Chat ID (personal or channel)</p>
                <p><span class="icon">3.</span> Choose which notifications you want to receive</p>
                <p><span class="icon">4.</span> Click "Test Connection" to verify everything works</p>
                <p><span class="icon">5.</span> Save the settings</p>
                <div class="success">
                    ✅ <strong>Done!</strong> You will now receive notifications about your printers status
                </div>
            </div>

            <h2>🔔 Supported Notifications</h2>
            
            <h3>📄 Print Notifications:</h3>
            <ul>
                <li>✅ <strong>Print Complete</strong> - When a print job finishes successfully</li>
                <li>❌ <strong>Print Error</strong> - When an error occurs during printing</li>
                <li>⏸️ <strong>Print Paused</strong> - When a print is paused</li>
            </ul>
            
            <h3>🖨️ Printer Notifications:</h3>
            <ul>
                <li>🔌 <strong>Printer Offline</strong> - When a printer goes offline (optional)</li>
                <li>🟢 <strong>Printer Online</strong> - When a printer comes back online (optional)</li>
            </ul>
            
            <h3>📊 Efficiency Notifications:</h3>
            <ul>
                <li>⚠️ <strong>Inefficiency Event</strong> - Automatically detects:
                    <ul>
                        <li><strong>Gap</strong> (break between prints exceeding 10 minutes)</li>
                        <li><strong>Pause</strong> (pause during printing exceeding 7 minutes)</li>
                    </ul>
                </li>
                <li>📝 <strong>Operator Report</strong> - When operator saves the reason for inefficiency in Analytics section</li>
            </ul>
            
            <h3>⚙️ System Notifications:</h3>
            <ul>
                <li>🚀 <strong>Program Start</strong> - Sent when the program starts (includes version and number of printers)</li>
            </ul>

            <div class="warning">
                <strong>Important:</strong> Make sure your bot has privacy mode disabled if you want to receive messages from it.
                You can configure this via @BotFather with command <code>/setprivacy</code> → <code>Disable</code>.
            </div>

            <div class="note">
                <strong>Tip:</strong> For testing, you can temporarily enable all notification types, 
                and after setup leave only the ones you need.
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <button onclick="window.close()" class="close-btn">
                    ✅ Close
                </button>
            </div>
        </div>
    </body>
    </html>
  `;

  helpWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(helpContent)}`);
}

function showBambuLabHelp(isRussian) {
  const helpWindow = new BrowserWindow({
    width: 800,
    height: 900,
    parent: mainWindow,
    modal: true,
    resizable: true,
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
    title: isRussian ? 'Настройка принтеров Bambu Lab' : 'Bambu Lab Printer Setup',
  });

  const helpContent = isRussian
    ? `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Настройка принтеров Bambu Lab</title>
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                padding: 25px; 
                line-height: 1.6;
                color: #333;
                background: #f5f5f5;
            }
            .container {
                max-width: 750px;
                margin: 0 auto;
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 { color: #00b894; text-align: center; margin-bottom: 30px; }
            h2 { color: #555; margin-top: 25px; padding-bottom: 8px; border-bottom: 2px solid #00b894; }
            h3 { color: #666; margin-top: 20px; }
            .step { 
                background: #f8f9fa; 
                padding: 20px; 
                margin: 15px 0; 
                border-radius: 8px;
                border-left: 4px solid #00b894;
            }
            code { 
                background: #2d2d2d; 
                color: #fff; 
                padding: 3px 8px; 
                border-radius: 4px;
                font-family: 'Courier New', monospace;
                font-size: 13px;
            }
            pre {
                background: #2d2d2d; 
                color: #fff; 
                padding: 15px; 
                border-radius: 6px;
                overflow-x: auto;
                margin: 12px 0;
            }
            .note { 
                background: #e3f2fd; 
                border: 1px solid #bbdefb; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            .warning { 
                background: #fff3cd; 
                border: 1px solid #ffeaa7; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            .success { 
                background: #d4edda; 
                border: 1px solid #c3e6cb; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            ul { padding-left: 20px; }
            li { margin: 8px 0; }
            .icon { font-size: 18px; margin-right: 8px; }
            .checklist { list-style: none; padding-left: 0; }
            .checklist li:before { content: "✅ "; margin-right: 8px; }
            strong { color: #2d3436; }
            .close-btn {
                background: #0088cc;
                color: white;
                border: none;
                padding: 12px 30px;
                border-radius: 6px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                box-shadow: 0 2px 8px rgba(0,136,204,0.3);
                transition: all 0.3s ease;
            }
            .close-btn:hover {
                background: #0099dd;
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,136,204,0.5);
            }
            .close-btn:active {
                transform: translateY(0);
                box-shadow: 0 2px 6px rgba(0,136,204,0.4);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🎋 Руководство по настройке Bambu Lab</h1>
            
            <div class="success">
                <strong>Отличные новости!</strong> Приложение теперь поддерживает принтеры <strong>Bambu Lab</strong> в дополнение к принтерам на базе Klipper!
            </div>

            <h2>📋 Требования</h2>
            <div class="step">
                <p><strong>Для принтеров Bambu Lab:</strong></p>
                <ul>
                    <li><strong>Режим разработчика</strong> должен быть включен на принтере</li>
                    <li><strong>Access Code</strong> из настроек принтера (8-значный код)</li>
                    <li><strong>Серийный номер</strong> вашего принтера</li>
                    <li>Подключение к <strong>локальной сети</strong> (принтер и ПК в одной сети)</li>
                </ul>
                <div class="note">
                    💡 Необходимая библиотека <strong>MQTT</strong> уже включена в программу.
                </div>
            </div>

            <h2>🔧 Подготовка к работе</h2>
            
            <h3>Шаг 1: Установка программы</h3>
            <div class="step">
                <p>Скачайте готовый установщик из <a href="https://github.com/Tombraider2006/KCP/releases/" target="_blank">релизов</a>:</p>
                <ul>
                    <li>🪟 <strong>Windows:</strong> .exe установщик</li>
                    <li>🍎 <strong>macOS:</strong> .dmg образ</li>
                    <li>🐧 <strong>Linux:</strong> .AppImage портативная версия</li>
                </ul>
                <div class="note">
                    💡 <strong>Примечание:</strong> Все зависимости, включая MQTT библиотеку (<code>mqtt@^5.3.5</code>), уже включены в установщик!
                </div>
            </div>

            <h3>Шаг 2: Включите режим разработчика на принтере</h3>
            <div class="step">
                <p><span class="icon">1.</span> Зайдите в настройки принтера на сенсорном экране</p>
                <p><span class="icon">2.</span> Перейдите в <strong>Настройки → Сеть → Режим разработчика</strong></p>
                <p><span class="icon">3.</span> Включите режим разработчика</p>
                <p><span class="icon">4.</span> Запишите отображаемый <strong>Access Code</strong></p>
                
                <div class="warning">
                    ⚠️ <strong>Важно:</strong> Без включенного режима разработчика принтер не будет принимать подключения от стороннего ПО.
                </div>
            </div>

            <h3>Шаг 3: Получите информацию о принтере</h3>
            <div class="step">
                <p>Вам понадобится:</p>
                <ul>
                    <li><strong>IP адрес:</strong> Найдите в сетевых настройках принтера</li>
                    <li><strong>Access Code:</strong> 8-значный код из настроек режима разработчика</li>
                    <li><strong>Серийный номер:</strong> Находится на наклейке принтера или в настройках (формат: <code>01P00A123456789</code>)</li>
                </ul>
            </div>

            <h2>📱 Добавление принтера Bambu Lab</h2>
            <div class="step">
                <p><span class="icon">1.</span> Нажмите кнопку <strong>"➕ Добавить принтер"</strong></p>
                <p><span class="icon">2.</span> Выберите <strong>"Bambu Lab"</strong> из выпадающего списка типов принтеров</p>
                <p><span class="icon">3.</span> Заполните необходимую информацию:</p>
                <ul>
                    <li><strong>Название принтера:</strong> Любое имя на ваш выбор</li>
                    <li><strong>IP адрес:</strong> Локальный IP вашего принтера (например, <code>192.168.1.100</code>)</li>
                    <li><strong>Access Code:</strong> 8-значный код из режима разработчика</li>
                    <li><strong>Серийный номер:</strong> Серийный номер вашего принтера</li>
                </ul>
                <p><span class="icon">4.</span> Убедитесь что галочка <strong>"Режим разработчика включен на принтере"</strong> установлена</p>
                <p><span class="icon">5.</span> Нажмите <strong>"Добавить"</strong></p>
            </div>

            <h2>🔌 Протокол подключения</h2>
            <div class="note">
                <ul>
                    <li>Принтеры <strong>Bambu Lab</strong> используют протокол <strong>MQTT</strong> (порт 8883)</li>
                    <li>Принтеры <strong>Klipper</strong> используют <strong>HTTP/WebSocket</strong> (порт 7125)</li>
                </ul>
            </div>

            <h2>🎯 Поддерживаемые функции</h2>
            
            <h3>Текущая поддержка:</h3>
            <ul class="checklist">
                <li>Добавление/Редактирование/Удаление принтеров Bambu Lab</li>
                <li>Сохранение конфигурации принтера</li>
                <li>Отображение типа принтера в интерфейсе</li>
                <li>Двуязычная поддержка (Русский/Английский)</li>
            </ul>

            <h3>В разработке:</h3>
            <ul>
                <li>🔄 MQTT подключение в реальном времени</li>
                <li>🔄 Мониторинг статуса печати</li>
                <li>🔄 Мониторинг температуры</li>
                <li>🔄 Отслеживание прогресса</li>
                <li>🔄 Информация о файле</li>
            </ul>

            <h2>⚠️ Известные ограничения</h2>
            <div class="warning">
                <ol>
                    <li><strong>Веб-интерфейс:</strong> У принтеров Bambu Lab нет локального веб-интерфейса как у Klipper (используйте приложение Bambu Handy или Bambu Studio)</li>
                    <li><strong>Прошивка января 2025:</strong> Последняя прошивка Bambu Lab требует режим разработчика для любого стороннего ПО</li>
                    <li><strong>Функциональность:</strong> Некоторые функции (мониторинг в реальном времени, управление печатью) находятся в разработке</li>
                </ol>
            </div>

            <h2>🔍 Решение проблем</h2>
            
            <h3>Проблемы с подключением MQTT</h3>
            <div class="step">
                <p><strong>Если принтер Bambu Lab не подключается:</strong></p>
                <ul>
                    <li>🔑 Проверьте, что режим разработчика включен</li>
                    <li>📝 Проверьте правильность Access Code (8 цифр)</li>
                    <li>🔢 Проверьте серийный номер принтера</li>
                    <li>🌐 Убедитесь что принтер и ПК в одной сети</li>
                    <li>🛡️ Проверьте что порт 8883 не заблокирован</li>
                    <li>🔄 Попробуйте перезапустить приложение</li>
                </ul>
            </div>

            <h3>"Developer mode must be enabled in printer settings"</h3>
            <div class="step">
                <p><strong>Решение:</strong></p>
                <p><span class="icon">1.</span> На сенсорном экране принтера: Настройки → Сеть → Режим разработчика</p>
                <p><span class="icon">2.</span> Включите его и запишите Access Code</p>
                <p><span class="icon">3.</span> При необходимости перезагрузите принтер</p>
            </div>

            <h3>Ошибка подключения</h3>
            <div class="step">
                <p><strong>Контрольный список:</strong></p>
                <ul class="checklist">
                    <li>Принтер и ПК в одной сети</li>
                    <li>Режим разработчика включен на принтере</li>
                    <li>Правильно введен Access Code (8 цифр)</li>
                    <li>Правильно введен серийный номер</li>
                    <li>Брандмауэр не блокирует порт 8883</li>
                    <li>IP адрес принтера актуален (не изменился)</li>
                </ul>
            </div>

            <h2>📚 Полезные ресурсы</h2>
            <ul>
                <li><a href="https://bambulab.com" target="_blank">Официальный сайт Bambu Lab</a></li>
                <li><a href="https://bambulab.com/download" target="_blank">Скачать Bambu Studio</a></li>
                <li><a href="https://bambulab.com/download" target="_blank">Приложение Bambu Handy</a></li>
                <li><a href="https://bambulab.com/community" target="_blank">Сообщество Bambu Lab</a></li>
            </ul>

            <div class="success">
                <strong>Успешной печати! 🖨️</strong>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <button onclick="window.close()" class="close-btn">
                    ✅ Закрыть
                </button>
            </div>
        </div>
    </body>
    </html>
  `
    : `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Bambu Lab Printer Setup</title>
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                padding: 25px; 
                line-height: 1.6;
                color: #333;
                background: #f5f5f5;
            }
            .container {
                max-width: 750px;
                margin: 0 auto;
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 { color: #00b894; text-align: center; margin-bottom: 30px; }
            h2 { color: #555; margin-top: 25px; padding-bottom: 8px; border-bottom: 2px solid #00b894; }
            h3 { color: #666; margin-top: 20px; }
            .step { 
                background: #f8f9fa; 
                padding: 20px; 
                margin: 15px 0; 
                border-radius: 8px;
                border-left: 4px solid #00b894;
            }
            code { 
                background: #2d2d2d; 
                color: #fff; 
                padding: 3px 8px; 
                border-radius: 4px;
                font-family: 'Courier New', monospace;
                font-size: 13px;
            }
            pre {
                background: #2d2d2d; 
                color: #fff; 
                padding: 15px; 
                border-radius: 6px;
                overflow-x: auto;
                margin: 12px 0;
            }
            .note { 
                background: #e3f2fd; 
                border: 1px solid #bbdefb; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            .warning { 
                background: #fff3cd; 
                border: 1px solid #ffeaa7; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            .success { 
                background: #d4edda; 
                border: 1px solid #c3e6cb; 
                padding: 12px; 
                border-radius: 6px;
                margin: 15px 0;
            }
            ul { padding-left: 20px; }
            li { margin: 8px 0; }
            .icon { font-size: 18px; margin-right: 8px; }
            .checklist { list-style: none; padding-left: 0; }
            .checklist li:before { content: "✅ "; margin-right: 8px; }
            strong { color: #2d3436; }
            .close-btn {
                background: #0088cc;
                color: white;
                border: none;
                padding: 12px 30px;
                border-radius: 6px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                box-shadow: 0 2px 8px rgba(0,136,204,0.3);
                transition: all 0.3s ease;
            }
            .close-btn:hover {
                background: #0099dd;
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,136,204,0.5);
            }
            .close-btn:active {
                transform: translateY(0);
                box-shadow: 0 2px 6px rgba(0,136,204,0.4);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🎋 Bambu Lab Integration Setup Guide</h1>
            
            <div class="success">
                <strong>Great news!</strong> This application now supports <strong>Bambu Lab</strong> 3D printers in addition to Klipper-based printers!
            </div>

            <h2>📋 Requirements</h2>
            <div class="step">
                <p><strong>For Bambu Lab Printers:</strong></p>
                <ul>
                    <li><strong>Developer Mode</strong> must be enabled on your printer</li>
                    <li><strong>Access Code</strong> from printer settings (8-digit code)</li>
                    <li><strong>Serial Number</strong> of your printer</li>
                    <li><strong>Local Network</strong> connection (printer and PC on same network)</li>
                </ul>
                <div class="note">
                    💡 The required <strong>MQTT</strong> library is already included in the program.
                </div>
            </div>

            <h2>🔧 Getting Started</h2>
            
            <h3>Step 1: Install the Application</h3>
            <div class="step">
                <p>Download the ready installer from <a href="https://github.com/Tombraider2006/KCP/releases/" target="_blank">releases</a>:</p>
                <ul>
                    <li>🪟 <strong>Windows:</strong> .exe installer</li>
                    <li>🍎 <strong>macOS:</strong> .dmg image</li>
                    <li>🐧 <strong>Linux:</strong> .AppImage portable version</li>
                </ul>
                <div class="note">
                    💡 <strong>Note:</strong> All dependencies, including MQTT library (<code>mqtt@^5.3.5</code>), are already included in the installer!
                </div>
            </div>

            <h3>Step 2: Enable Developer Mode on Printer</h3>
            <div class="step">
                <p><span class="icon">1.</span> Go to printer settings on the printer's touchscreen</p>
                <p><span class="icon">2.</span> Navigate to <strong>Settings → Network → Developer Mode</strong></p>
                <p><span class="icon">3.</span> Enable Developer Mode</p>
                <p><span class="icon">4.</span> Note the <strong>Access Code</strong> displayed</p>
                
                <div class="warning">
                    ⚠️ <strong>Important:</strong> Without Developer Mode enabled, the printer will not accept connections from third-party software.
                </div>
            </div>

            <h3>Step 3: Get Printer Information</h3>
            <div class="step">
                <p>You'll need:</p>
                <ul>
                    <li><strong>IP Address:</strong> Find in printer's network settings</li>
                    <li><strong>Access Code:</strong> 8-digit code from developer mode settings</li>
                    <li><strong>Serial Number:</strong> Found on printer label or in settings (format: <code>01P00A123456789</code>)</li>
                </ul>
            </div>

            <h2>📱 Adding a Bambu Lab Printer</h2>
            <div class="step">
                <p><span class="icon">1.</span> Click <strong>"➕ Add Printer"</strong> button</p>
                <p><span class="icon">2.</span> Select <strong>"Bambu Lab"</strong> from the printer type dropdown</p>
                <p><span class="icon">3.</span> Fill in the required information:</p>
                <ul>
                    <li><strong>Printer Name:</strong> Any name you choose</li>
                    <li><strong>IP Address:</strong> Your printer's local IP (e.g., <code>192.168.1.100</code>)</li>
                    <li><strong>Access Code:</strong> 8-digit code from developer mode</li>
                    <li><strong>Serial Number:</strong> Your printer's serial number</li>
                </ul>
                <p><span class="icon">4.</span> Ensure <strong>"Developer Mode enabled on printer"</strong> checkbox is checked</p>
                <p><span class="icon">5.</span> Click <strong>"Add"</strong></p>
            </div>

            <h2>🔌 Connection Protocol</h2>
            <div class="note">
                <ul>
                    <li><strong>Bambu Lab</strong> printers use <strong>MQTT</strong> protocol (port 8883)</li>
                    <li><strong>Klipper</strong> printers use <strong>HTTP/WebSocket</strong> (port 7125)</li>
                </ul>
            </div>

            <h2>🎯 Supported Features</h2>
            
            <h3>Currently Supported:</h3>
            <ul class="checklist">
                <li>Add/Edit/Remove Bambu Lab printers</li>
                <li>Store printer configuration</li>
                <li>Display printer type in UI</li>
                <li>Bilingual support (Russian/English)</li>
            </ul>

            <h3>In Development:</h3>
            <ul>
                <li>🔄 Real-time MQTT connection</li>
                <li>🔄 Print status monitoring</li>
                <li>🔄 Temperature monitoring</li>
                <li>🔄 Progress tracking</li>
                <li>🔄 File information</li>
            </ul>

            <h2>⚠️ Known Limitations</h2>
            <div class="warning">
                <ol>
                    <li><strong>Web Interface:</strong> Bambu Lab printers don't have a local web interface like Klipper (use Bambu Handy app or Bambu Studio instead)</li>
                    <li><strong>January 2025 Firmware:</strong> Latest Bambu Lab firmware requires Developer Mode for any third-party software</li>
                    <li><strong>Functionality:</strong> Some features (real-time monitoring, print control) are currently in development</li>
                </ol>
            </div>

            <h2>🔍 Troubleshooting</h2>
            
            <h3>MQTT Connection Issues</h3>
            <div class="step">
                <p><strong>If Bambu Lab printer won't connect:</strong></p>
                <ul>
                    <li>🔑 Check that developer mode is enabled</li>
                    <li>📝 Verify Access Code correctness (8 digits)</li>
                    <li>🔢 Verify printer serial number</li>
                    <li>🌐 Ensure printer and PC are on the same network</li>
                    <li>🛡️ Check that port 8883 is not blocked</li>
                    <li>🔄 Try restarting the application</li>
                </ul>
            </div>

            <h3>"Developer mode must be enabled in printer settings"</h3>
            <div class="step">
                <p><strong>Solution:</strong></p>
                <p><span class="icon">1.</span> On printer touchscreen: Settings → Network → Developer Mode</p>
                <p><span class="icon">2.</span> Enable it and note the Access Code</p>
                <p><span class="icon">3.</span> Restart the printer if needed</p>
            </div>

            <h3>Connection Failed</h3>
            <div class="step">
                <p><strong>Checklist:</strong></p>
                <ul class="checklist">
                    <li>Printer and PC on same network</li>
                    <li>Developer Mode enabled on printer</li>
                    <li>Correct Access Code entered (8 digits)</li>
                    <li>Correct Serial Number entered</li>
                    <li>Firewall not blocking port 8883</li>
                    <li>Printer IP address is current (hasn't changed)</li>
                </ul>
            </div>

            <h2>📚 Related Resources</h2>
            <ul>
                <li><a href="https://bambulab.com" target="_blank">Bambu Lab Official Website</a></li>
                <li><a href="https://bambulab.com/download" target="_blank">Bambu Studio Download</a></li>
                <li><a href="https://bambulab.com/download" target="_blank">Bambu Handy App</a></li>
                <li><a href="https://bambulab.com/community" target="_blank">Bambu Lab Community</a></li>
            </ul>

            <div class="success">
                <strong>Happy Printing! 🖨️</strong>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <button onclick="window.close()" class="close-btn">
                    ✅ Close
                </button>
            </div>
        </div>
    </body>
    </html>
  `;

  helpWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(helpContent)}`);
}

async function checkForUpdatesAPI(isRussian) {
  const currentVersion = APP_VERSION;

  try {
    // Показываем диалог "Проверка..."
    const checkingMessage = isRussian ? 'Проверка обновлений...' : 'Checking for updates...';

    console.log(checkingMessage);

    // Делаем запрос к API сайта (вместо GitHub API)
    const latestRelease = await new Promise((resolve, reject) => {
      const options = {
        hostname: 'tomich.fun',
        path: '/api/latest-version',
        method: 'GET',
        headers: {
          'User-Agent': '3D-Printer-Control-Panel',
        },
      };

      const req = https.request(options, (res) => {
        let data = '';

        res.on('data', (chunk) => {
          data += chunk;
        });

        res.on('end', () => {
          if (res.statusCode === 200) {
            try {
              const info = JSON.parse(data);
              // Преобразуем формат ответа к ожидаемому
              resolve({
                tag_name: 'v' + info.version,
                name: info.name,
                body: info.notes,
                html_url: info.download_url || 'https://tomich.fun/download',
              });
            } catch (e) {
              reject(new Error('Failed to parse response'));
            }
          } else {
            reject(new Error(`HTTP ${res.statusCode}`));
          }
        });
      });

      req.on('error', (error) => {
        reject(error);
      });

      req.setTimeout(10000, () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.end();
    });

    // Получаем версию из тега (убираем 'v' если есть)
    const latestVersion = latestRelease.tag_name.replace(/^v/, '');

    // Сравниваем версии
    const isNewer = compareVersions(latestVersion, currentVersion);

    if (isNewer) {
      const result = await dialog.showMessageBox(mainWindow, {
        type: 'info',
        title: isRussian ? 'Доступно обновление' : 'Update Available',
        message: isRussian
          ? `Доступна новая версия ${latestVersion}!\nТекущая версия: ${currentVersion}`
          : `New version ${latestVersion} is available!\nCurrent version: ${currentVersion}`,
        detail: isRussian
          ? 'Хотите перейти на страницу загрузки?'
          : 'Would you like to go to the download page?',
        buttons: [isRussian ? 'Да' : 'Yes', isRussian ? 'Нет' : 'No'],
        defaultId: 0,
        cancelId: 1,
      });

      if (result.response === 0) {
        shell.openExternal('https://tomich.fun/downloads');
      }
    } else {
      dialog.showMessageBox(mainWindow, {
        type: 'info',
        title: isRussian ? 'Обновлений нет' : 'No Updates',
        message: isRussian
          ? `У вас установлена последняя версия (${currentVersion})`
          : `You have the latest version (${currentVersion})`,
        buttons: ['OK'],
      });
    }
  } catch (error) {
    console.error('Error checking for updates:', error);
    dialog.showMessageBox(mainWindow, {
      type: 'error',
      title: isRussian ? 'Ошибка' : 'Error',
      message: isRussian
        ? 'Не удалось проверить обновления.\n\nВы можете проверить обновления вручную:\nhttps://tomich.fun/downloads'
        : 'Failed to check for updates.\n\nYou can check manually at:\nhttps://tomich.fun/downloads',
      detail: error.message,
      buttons: ['OK'],
    });
  }
}

function compareVersions(v1, v2) {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);

  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const num1 = parts1[i] || 0;
    const num2 = parts2[i] || 0;

    if (num1 > num2) return true;
    if (num1 < num2) return false;
  }

  return false;
}

function createTabsWindow() {
  if (tabsWindow && !tabsWindow.isDestroyed()) {
    // Показываем окно если оно скрыто или свернуто
    if (!tabsWindow.isVisible()) {
      tabsWindow.show();
    }
    if (tabsWindow.isMinimized()) {
      tabsWindow.restore();
    }
    tabsWindow.focus();
    return tabsWindow;
  }

  tabsWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 800,
    minHeight: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webSecurity: false,
      allowRunningInsecureContent: true,
    },
    title: `3D Printer Interfaces - v${APP_VERSION}`,
    icon: getIconPath(),
    show: true, // Показываем окно сразу
    autoHideMenuBar: true,
  });

  tabsWindow.loadFile('src/printer-tabs-window.html');

  // DevTools отключены для продакшена
  // tabsWindow.webContents.openDevTools();

  tabsWindow.on('closed', () => {
    tabsWindow = null;
    printerTabs.clear();
  });

  // Tabs window created and shown

  return tabsWindow;
}

function addPrinterTab(printerData) {
  // Проверяем было ли окно создано заново (ПЕРЕД добавлением в Map)
  const wasWindowNull = !tabsWindow || tabsWindow.isDestroyed();

  const window = createTabsWindow();
  const isNewWindow = wasWindowNull; // Новое окно если раньше его не было

  // Adding printer tab

  // Сохраняем данные принтера
  printerTabs.set(printerData.id, printerData);

  // Отправляем данные в окно вкладок
  const sendData = () => {
    if (window && !window.isDestroyed()) {
      // Sending add-printer-tab event
      window.webContents.send('add-printer-tab', printerData);

      // Для Bambu Lab принтеров сразу отправляем данные
      if (printerData.type === 'bambu') {
        // Scheduling Bambu data send
        setTimeout(async () => {
          await sendBambuDataToInterface(printerData.id);
        }, 500); // Увеличил задержку до 500мс
      }
    }
  };

  // Если это новое окно (первый принтер) - ждем dom-ready
  if (isNewWindow) {
    // Waiting for dom-ready event
    window.webContents.once('dom-ready', () => {
      // DOM ready event fired
      setTimeout(sendData, 300); // Увеличил задержку до 300мс
    });
  } else {
    // Окно уже существует - отправляем сразу
    // Window already exists, sending data immediately
    setTimeout(sendData, 50); // Увеличил задержку до 50мс
  }
}

function focusPrinterTab(printerId) {
  if (tabsWindow && !tabsWindow.isDestroyed() && printerTabs.has(printerId)) {
    // Показываем окно если оно скрыто или свернуто
    if (!tabsWindow.isVisible()) {
      tabsWindow.show();
    }
    if (tabsWindow.isMinimized()) {
      tabsWindow.restore();
    }

    tabsWindow.webContents.send('focus-printer-tab', printerId);
    tabsWindow.focus();

    // Для Bambu Lab принтеров отправляем данные при фокусе
    const printerData = printerTabs.get(printerId);
    if (printerData && printerData.type === 'bambu') {
      setTimeout(async () => {
        await sendBambuDataToInterface(printerId);
      }, 100);
    }

    return true;
  }
  return false;
}

// ===== BAMBU LAB MQTT CONNECTION MANAGEMENT =====

/**
 * Test connection to Bambu Lab printer
 */
async function testBambuConnection(printerData) {
  try {
    console.log(`Testing Bambu Lab connection for: ${printerData.name}`);

    // Create adapter instance
    const adapter = new BambuLabAdapter(printerData);

    // Try to connect
    const success = await adapter.testConnection();

    if (success) {
      // Store the connection
      bambuConnections.set(printerData.id, adapter);

      // Setup message handler to send updates to renderer
      await adapter.setupRealtimeConnection();

      // Set up data update callback
      printerData.onDataUpdate = (updatedPrinter) => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('bambu-printer-update', {
            id: printerData.id,
            data: updatedPrinter.data,
            status: adapter.getStatus(),
            lastUpdate: new Date().toISOString(),
          });
        }

        // Отправляем обновление в web-сервер
        const statusData = {
          state: adapter.getStatus(),
          stateText: adapter.getStateText(),
          progress: adapter.getProgress(),
          fileName: adapter.getFileName(),
          temps: adapter.getTemperatures(),
        };
        notifyWebServerPrinterUpdate(printerData.id, statusData);
        notifyWebServerPrinterStatus(printerData.id, statusData);
      };

      console.log(`✅ Bambu Lab connection successful for: ${printerData.name}`);
      return {
        success: true,
        protocol: adapter.usedProtocol,
        data: adapter.printerData,
      };
    }

    return { success: false, error: 'Connection failed' };
  } catch (error) {
    console.error(`❌ Bambu Lab connection error for ${printerData.name}:`, error.message);
    return {
      success: false,
      error: error.message,
    };
  }
}

/**
 * Close Bambu Lab connection
 */
async function closeBambuConnection(printerId) {
  if (bambuConnections.has(printerId)) {
    const adapter = bambuConnections.get(printerId);
    await adapter.closeConnection();
    bambuConnections.delete(printerId);
    console.log(`Closed Bambu Lab connection for printer: ${printerId}`);
  }
}

/**
 * Get Bambu Lab printer data
 */
async function getBambuPrinterData(printerId) {
  console.log('getBambuPrinterData called for printer:', printerId);

  if (!bambuConnections.has(printerId)) {
    console.log('No adapter found for printer:', printerId);
    return null;
  }

  const adapter = bambuConnections.get(printerId);
  console.log('Found adapter for printer:', printerId);
  console.log('Adapter printerData:', adapter.printerData);

  const result = {
    status: adapter.getStatus(),
    stateText: adapter.getStateText(),
    progress: adapter.getProgress(),
    fileName: adapter.getFileName(),
    temps: adapter.getTemperatures(),
    data: adapter.printerData,
    connectionType: 'MQTT',
    protocol: adapter.usedProtocol,
    hasCamera: adapter.hasCamera(),
    cameraStreamUrl: adapter.getCameraStreamUrl(),
    hmsErrors: adapter.getActiveHmsErrors(),
    printSpeed: adapter.getPrintSpeed(),
    fanStates: adapter.getFanStates(),
    isBambuJsSupported: adapter.isBambuJsSupported(),
  };

  console.log('Returning printer data:', result);
  return result;
}

/**
 * Request status update for Bambu printer
 */
function requestBambuStatus(printerId) {
  if (bambuConnections.has(printerId)) {
    const adapter = bambuConnections.get(printerId);
    adapter.requestStatus();
  }
}

// IPC handlers
ipcMain.handle('open-external', (event, url) => {
  try {
    shell.openExternal(url);
    return { success: true };
  } catch (error) {
    console.error('Error opening external URL:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('open-printer-window', (event, printerData) => {
  try {
    const sanitizedPrinterData = {
      id: String(printerData.id),
      name: String(printerData.name),
      ip: String(printerData.ip),
      type: String(printerData.type || 'klipper'),
      port: String(printerData.port || '7125'),
      webPort: String(printerData.webPort || '80'),
      accessCode: printerData.accessCode ? String(printerData.accessCode) : undefined,
      serialNumber: printerData.serialNumber ? String(printerData.serialNumber) : undefined,
      // Добавляем данные авторизации для Klipper
      authUsername: printerData.authUsername ? String(printerData.authUsername) : undefined,
      authPassword: printerData.authPassword ? String(printerData.authPassword) : undefined,
      // Добавляем флаги состояния
      requiresAuth: printerData.requiresAuth || false,
      hasConnectedWithoutAuth: printerData.hasConnectedWithoutAuth || false,
    };

    console.log(
      'Opening printer tab for:',
      sanitizedPrinterData.name,
      'Type:',
      sanitizedPrinterData.type,
    );

    // Проверяем, существует ли уже вкладка
    if (printerTabs.has(sanitizedPrinterData.id)) {
      focusPrinterTab(sanitizedPrinterData.id);
    } else {
      addPrinterTab(sanitizedPrinterData);
    }

    return { success: true };
  } catch (error) {
    console.error('Error opening printer tab:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('focus-printer-window', (event, printerId) => {
  return focusPrinterTab(String(printerId));
});

// ОБРАБОТЧИК ДЛЯ ЗАКРЫТИЯ ВКЛАДКИ ПРИНТЕРА
ipcMain.on('close-printer-tab', (event, printerId) => {
  console.log('Closing printer tab:', printerId);
  if (printerTabs.has(printerId)) {
    printerTabs.delete(printerId);
    console.log('Printer tab removed from map:', printerId);
  }
});

// ОБРАБОТЧИК ДЛЯ ВОЗВРАТА НА ГЛАВНЫЙ ЭКРАН
ipcMain.on('focus-main-window', (event) => {
  console.log('Focusing main window...');
  if (mainWindow && !mainWindow.isDestroyed()) {
    if (mainWindow.isMinimized()) {
      mainWindow.restore();
    }
    mainWindow.focus();
  }
});

ipcMain.handle('get-app-version', () => {
  return APP_VERSION;
});

// Storage handlers
ipcMain.handle('store-get', (event, key, defaultValue) => {
  return store.get(key, defaultValue);
});

ipcMain.handle('store-set', (event, key, value) => {
  store.set(key, value);
  return true;
});

// Migration handlers
ipcMain.handle('migrate-data', async () => {
  try {
    const result = await autoMigrate();
    return result;
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('force-cleanup', async () => {
  try {
    const result = await forceCleanup();
    return result;
  } catch (error) {
    return { success: false, error: error.message };
  }
});

// Data diagnostics handler
ipcMain.handle('diagnose-data', async () => {
  try {
    const issues = [];
    const data = {};

    // Check printers data
    const printers = store.get('printers', []);
    data.printers = printers;
    if (!Array.isArray(printers)) {
      issues.push('printers: not an array');
    } else {
      printers.forEach((printer, index) => {
        if (!printer.id || !printer.name || !printer.ip) {
          issues.push(`printer[${index}]: missing required fields`);
        }
      });
    }

    // Check license data
    const license = store.get('license');
    data.license = license;
    if (license && typeof license !== 'object') {
      issues.push('license: invalid format');
    }

    // Check analytics data
    const analytics = store.get('analytics');
    data.analytics = analytics;
    if (analytics && typeof analytics !== 'object') {
      issues.push('analytics: invalid format');
    }

    // Check data version
    const dataVersion = store.get('dataVersion');
    data.dataVersion = dataVersion;

    return {
      success: true,
      isValid: issues.length === 0,
      issues,
      data,
      summary: {
        printersCount: Array.isArray(printers) ? printers.length : 0,
        hasLicense: !!license,
        hasAnalytics: !!analytics,
        dataVersion: dataVersion || 'Unknown',
      },
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

// Encryption handlers for secure credential storage
ipcMain.handle('encrypt-data', (event, text) => {
  return encrypt(text);
});

ipcMain.handle('decrypt-data', (event, encryptedText) => {
  return decrypt(encryptedText);
});

// Network Scanner
ipcMain.handle('scan-network', async (event) => {
  const networkScanner = await import('./network-scanner.js');

  try {
    const foundPrinters = [];

    const result = await networkScanner.scanNetwork(
      // Progress callback
      (ip, current, total) => {
        event.sender.send('scan-progress', ip, current, total);
      },
      // Found printer callback
      (printer) => {
        foundPrinters.push(printer);
      },
    );

    return result;
  } catch (error) {
    console.error('Network scan error:', error);
    throw error;
  }
});

// ===== BAMBU LAB IPC HANDLERS =====

/**
 * Test Bambu Lab printer connection
 */
ipcMain.handle('test-bambu-connection', async (event, printerData) => {
  return await testBambuConnection(printerData);
});

/**
 * Close Bambu Lab printer connection
 */
ipcMain.handle('close-bambu-connection', async (event, printerId) => {
  await closeBambuConnection(printerId);
  return { success: true };
});

/**
 * Get Bambu Lab printer data
 */
ipcMain.handle('get-bambu-printer-data', async (event, printerId) => {
  return await getBambuPrinterData(printerId);
});

/**
 * Request status update for Bambu printer
 */
ipcMain.handle('request-bambu-status', (event, printerId) => {
  requestBambuStatus(printerId);
  return { success: true };
});

// ===== TUYA SMART PLUG IPC HANDLERS =====

/**
 * Setup Tuya Cloud API connection
 */
ipcMain.handle('setup-tuya', async (event, config) => {
  try {
    // Проверяем и нормализуем secret
    let secret = config.accessSecret;
    if (typeof secret !== 'string') {
      console.warn('[Tuya] Invalid secret type:', typeof secret, secret);
      return { success: false, error: 'Invalid secret format' };
    }

    // Очищаем secret от лишних символов
    secret = secret.trim();
    if (!secret) {
      return { success: false, error: 'Secret cannot be empty' };
    }

    const adapter = new TuyaAdapter({
      baseUrl: config.baseUrl,
      accessKey: config.accessId,
      secretKey: secret,
      debug: true,
    });

    const isConnected = await adapter.testConnection();

    if (isConnected) {
      globalTuyaAdapter = adapter;

      // Сохранить конфигурацию (зашифровать secret)
      const encryptedSecret = await encrypt(secret);
      store.set('tuyaConfig', {
        baseUrl: config.baseUrl,
        accessId: config.accessId,
        accessSecret: encryptedSecret,
      });

      return { success: true, message: 'Connected to Tuya Cloud API' };
    } else {
      return { success: false, error: 'Connection test failed' };
    }
  } catch (error) {
    console.error('[Tuya] Setup error:', error);
    return { success: false, error: error.message };
  }
});

/**
 * Get list of Tuya devices (smart plugs)
 */
ipcMain.handle('tuya-get-devices', async () => {
  if (!globalTuyaAdapter) {
    return { success: false, error: 'Tuya not configured' };
  }

  try {
    const devices = await globalTuyaAdapter.getDevices();

    // Фильтруем только розетки (switch)
    const switches = devices.filter(
      (d) =>
        d.category === 'cz' || // Socket
        d.category === 'pc' || // Power strip
        (d.product_name && d.product_name.toLowerCase().includes('socket')) ||
        (d.product_name && d.product_name.toLowerCase().includes('plug')),
    );

    return { success: true, devices: switches };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

/**
 * Link Tuya device to printer
 */
ipcMain.handle('tuya-link-device', async (event, printerId, deviceId, settings) => {
  try {
    tuyaConnections.set(printerId, {
      adapter: globalTuyaAdapter,
      deviceId: deviceId,
    });

    // Сохранить в настройках принтера
    const printers = store.get('printers', []);
    const printer = printers.find((p) => p.id === printerId);
    if (printer) {
      printer.tuyaDeviceId = deviceId;
      printer.autoShutdownEnabled = settings.autoShutdownEnabled || false;
      printer.autoShutdownDelay = settings.autoShutdownDelay || 5;
      printer.autoShutdownError = settings.autoShutdownError || false;
      printer.autoShutdownOverheat = settings.autoShutdownOverheat || false;
      store.set('printers', printers);
    }

    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

/**
 * Unlink Tuya device from printer
 */
ipcMain.handle('tuya-unlink-device', async (event, printerId) => {
  try {
    tuyaConnections.delete(printerId);

    // Удалить из настроек принтера
    const printers = store.get('printers', []);
    const printer = printers.find((p) => p.id === printerId);
    if (printer) {
      delete printer.tuyaDeviceId;
      delete printer.autoShutdownEnabled;
      delete printer.autoShutdownDelay;
      delete printer.autoShutdownError;
      delete printer.autoShutdownOverheat;
      store.set('printers', printers);
    }

    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

/**
 * Control Tuya device (turn on/off/get status)
 */
ipcMain.handle('tuya-control-device', async (event, printerId, action) => {
  const connection = tuyaConnections.get(printerId);

  if (!connection) {
    return { success: false, error: 'Device not linked' };
  }

  try {
    let result;

    switch (action) {
      case 'turn_on':
        result = await connection.adapter.turnOn(connection.deviceId);
        break;
      case 'turn_off':
        result = await connection.adapter.turnOff(connection.deviceId);
        break;
      case 'get_status':
        result = await connection.adapter.getDeviceStatus(connection.deviceId);
        break;
      case 'toggle':
        // Сначала получаем статус
        const isOn = await connection.adapter.isDeviceOn(connection.deviceId);
        if (isOn === null) {
          return { success: false, error: 'Failed to get device status' };
        }
        // Переключаем
        result = isOn
          ? await connection.adapter.turnOff(connection.deviceId)
          : await connection.adapter.turnOn(connection.deviceId);
        break;
      default:
        return { success: false, error: 'Unknown action' };
    }

    return result;
  } catch (error) {
    return { success: false, error: error.message };
  }
});

/**
 * Get energy statistics from Tuya device
 */
ipcMain.handle('tuya-get-energy-stats', async (event, printerId) => {
  const connection = tuyaConnections.get(printerId);

  if (!connection) {
    return { success: false, error: 'Device not linked' };
  }

  try {
    const stats = await connection.adapter.getEnergyStats(connection.deviceId);
    return stats;
  } catch (error) {
    return { success: false, error: error.message };
  }
});

/**
 * Get current Tuya device status for printer
 */
ipcMain.handle('tuya-get-device-status', async (event, printerId) => {
  const connection = tuyaConnections.get(printerId);

  if (!connection) {
    return { success: false, linked: false };
  }

  try {
    const isOn = await connection.adapter.isDeviceOn(connection.deviceId);
    return {
      success: true,
      linked: true,
      deviceId: connection.deviceId,
      isOn: isOn,
    };
  } catch (error) {
    return { success: false, error: error.message, linked: true };
  }
});

// ===== HOME ASSISTANT IPC HANDLERS =====

/**
 * Setup Home Assistant connection
 */
ipcMain.handle('setup-homeassistant', async (event, config) => {
  try {
    // Проверяем и нормализуем токен
    let token = config.token;
    if (typeof token !== 'string') {
      console.warn('[HomeAssistant] Invalid token type:', typeof token, token);
      return { success: false, error: 'Invalid token format' };
    }

    // Очищаем токен от лишних символов
    token = token.trim();
    if (!token) {
      return { success: false, error: 'Token cannot be empty' };
    }

    const adapter = new HomeAssistantAdapter({
      baseUrl: config.baseUrl,
      token: token,
      debug: true,
    });

    const isConnected = await adapter.testConnection();

    if (isConnected) {
      globalHomeAssistantAdapter = adapter;

      // Сохранить конфигурацию (зашифровать token)
      const encryptedToken = await encrypt(token);
      store.set('homeassistantConfig', {
        baseUrl: config.baseUrl,
        token: encryptedToken,
      });

      return { success: true, message: 'Connected to Home Assistant' };
    } else {
      return { success: false, error: 'Connection test failed' };
    }
  } catch (error) {
    console.error('[HomeAssistant] Setup error:', error);
    return { success: false, error: error.message };
  }
});

/**
 * Get list of Home Assistant switches
 */
ipcMain.handle('ha-get-switches', async () => {
  if (!globalHomeAssistantAdapter) {
    return { success: false, error: 'Home Assistant not configured or connection failed' };
  }

  try {
    const switches = await globalHomeAssistantAdapter.getSwitches();
    return { success: true, devices: switches };
  } catch (error) {
    console.error('[HomeAssistant] Get switches error:', error);
    return { success: false, error: error.message };
  }
});

/**
 * Control Home Assistant switch
 */
ipcMain.handle('ha-control-switch', async (event, printerId, action) => {
  if (!globalHomeAssistantAdapter) {
    return { success: false, error: 'Home Assistant not configured or connection failed' };
  }

  const printers = store.get('printers', []);
  const printer = printers.find((p) => p.id === printerId);

  if (!printer || !printer.haEntityId) {
    return { success: false, error: 'Device not linked' };
  }

  try {
    let result;

    switch (action) {
      case 'turn_on':
        result = await globalHomeAssistantAdapter.turnOn(printer.haEntityId);
        break;
      case 'turn_off':
        result = await globalHomeAssistantAdapter.turnOff(printer.haEntityId);
        break;
      case 'toggle':
        const isOn = await globalHomeAssistantAdapter.isDeviceOn(printer.haEntityId);
        result = isOn
          ? await globalHomeAssistantAdapter.turnOff(printer.haEntityId)
          : await globalHomeAssistantAdapter.turnOn(printer.haEntityId);
        break;
      default:
        return { success: false, error: 'Unknown action' };
    }

    return { success: true, result };
  } catch (error) {
    console.error('[HomeAssistant] Control switch error:', error);
    return { success: false, error: error.message };
  }
});

/**
 * Get Home Assistant switch status
 */
ipcMain.handle('ha-get-switch-status', async (event, printerId) => {
  if (!globalHomeAssistantAdapter) {
    return { success: false, error: 'Home Assistant not configured or connection failed' };
  }

  const printers = store.get('printers', []);
  const printer = printers.find((p) => p.id === printerId);

  if (!printer || !printer.haEntityId) {
    return { success: false, linked: false };
  }

  try {
    const isOn = await globalHomeAssistantAdapter.isDeviceOn(printer.haEntityId);
    return {
      success: true,
      linked: true,
      entityId: printer.haEntityId,
      isOn: isOn,
    };
  } catch (error) {
    console.error('[HomeAssistant] Get switch status error:', error);
    return { success: false, error: error.message, linked: true };
  }
});

/**
 * Link Home Assistant entity to printer
 */
ipcMain.handle('ha-link-device', async (event, printerId, entityId, settings) => {
  try {
    // Сохранить в настройках принтера
    const printers = store.get('printers', []);
    const printer = printers.find((p) => p.id === printerId);
    if (printer) {
      printer.haEntityId = entityId;
      printer.autoShutdownEnabled = settings.autoShutdownEnabled || false;
      printer.autoShutdownDelay = settings.autoShutdownDelay || 5;
      printer.autoShutdownError = settings.autoShutdownError || false;
      printer.autoShutdownOverheat = settings.autoShutdownOverheat || false;
      store.set('printers', printers);
    }

    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

/**
 * Unlink Home Assistant entity from printer
 */
ipcMain.handle('ha-unlink-device', async (event, printerId) => {
  try {
    // Удалить из настроек принтера
    const printers = store.get('printers', []);
    const printer = printers.find((p) => p.id === printerId);
    if (printer) {
      delete printer.haEntityId;
      delete printer.autoShutdownEnabled;
      delete printer.autoShutdownDelay;
      delete printer.autoShutdownError;
      delete printer.autoShutdownOverheat;
      store.set('printers', printers);
    }

    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

/**
 * Reconnect to Home Assistant
 */
ipcMain.handle('ha-reconnect', async () => {
  return await reconnectHomeAssistant();
});

/**
 * Reconnect to Home Assistant function
 */
async function reconnectHomeAssistant() {
  const haConfig = store.get('homeassistantConfig');
  if (haConfig && haConfig.baseUrl && haConfig.token) {
    try {
      // Проверяем тип токена
      if (typeof haConfig.token !== 'string') {
        console.warn('[HomeAssistant] Invalid token type for reconnection:', typeof haConfig.token);
        store.delete('homeassistantConfig');
        return { success: false, error: 'Invalid token format' };
      }

      const decryptedToken = await decrypt(haConfig.token);
      if (!decryptedToken || typeof decryptedToken !== 'string') {
        throw new Error('Failed to decrypt Home Assistant token');
      }

      globalHomeAssistantAdapter = new HomeAssistantAdapter({
        baseUrl: haConfig.baseUrl,
        token: decryptedToken,
        debug: process.argv.includes('--dev'),
      });

      const isConnected = await globalHomeAssistantAdapter.testConnection();
      if (isConnected) {
        console.log('[HomeAssistant] ✅ Reconnected successfully');
        return { success: true, message: 'Reconnected to Home Assistant' };
      } else {
        console.log('[HomeAssistant] ❌ Reconnection failed');
        globalHomeAssistantAdapter = null;
        return { success: false, error: 'Connection test failed' };
      }
    } catch (error) {
      console.error('[HomeAssistant] Reconnection error:', error);
      globalHomeAssistantAdapter = null;
      return { success: false, error: error.message };
    }
  } else {
    return { success: false, error: 'No Home Assistant configuration found' };
  }
}

// ===== TUYA AUTOMATION FUNCTIONS =====

// Map для хранения таймеров отключения
const shutdownTimers = new Map();

/**
 * Обработка завершения печати - автоматическое отключение
 * @param {string} printerId - ID принтера
 * @param {string} printerName - Имя принтера
 */
async function handlePrintComplete(printerId, printerName) {
  // Получить настройки принтера
  const printers = store.get('printers', []);
  const printer = printers.find((p) => p.id === printerId);

  if (!printer || !printer.autoShutdownEnabled) {
    console.log(`[SmartPlug] Auto-shutdown not enabled for printer ${printerId}`);
    return;
  }

  // Проверить, есть ли подключение (Tuya или HA)
  const tuyaConnection = tuyaConnections.get(printerId);
  const hasHA = printer.haEntityId && globalHomeAssistantAdapter;

  if (!tuyaConnection && !hasHA) {
    console.log(`[SmartPlug] No connection for printer ${printerId}`);
    return;
  }

  const delay = (printer.autoShutdownDelay || 5) * 60 * 1000; // минуты в мс
  const plugType = tuyaConnection ? 'Tuya' : 'Home Assistant';

  console.log(
    `[SmartPlug] ⏲️ Scheduling shutdown for printer ${printerName} (${printerId}) via ${plugType} in ${delay / 60000} minutes`,
  );

  // Отменить предыдущий таймер, если есть
  if (shutdownTimers.has(printerId)) {
    clearTimeout(shutdownTimers.get(printerId));
  }

  // Установить новый таймер
  const timer = setTimeout(async () => {
    try {
      console.log(
        `[SmartPlug] 🔌 Executing auto-shutdown for printer ${printerName} (${printerId})`,
      );

      let result;

      // Выбираем правильный адаптер
      if (tuyaConnection) {
        result = await tuyaConnection.adapter.turnOff(tuyaConnection.deviceId);
      } else if (hasHA) {
        result = await globalHomeAssistantAdapter.turnOff(printer.haEntityId);
      }

      if (result && result.success) {
        console.log(
          `[SmartPlug] ✅ Printer ${printerName} (${printerId}) powered off automatically via ${plugType}`,
        );

        // Отправить уведомление в renderer
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('printer-powered-off', {
            printerId: printerId,
            printerName: printerName,
            reason: 'auto_shutdown_after_complete',
          });
        }
      } else {
        console.error(
          `[SmartPlug] ❌ Failed to auto-shutdown printer ${printerId}: ${result?.error || 'Unknown error'}`,
        );
      }
    } catch (error) {
      console.error(`[SmartPlug] ❌ Exception during auto-shutdown for ${printerId}:`, error);
    } finally {
      shutdownTimers.delete(printerId);
    }
  }, delay);

  shutdownTimers.set(printerId, timer);
}

/**
 * Обработка ошибки печати - автоматическое отключение
 * @param {string} printerId - ID принтера
 * @param {string} printerName - Имя принтера
 */
async function handlePrintError(printerId, printerName) {
  // Получить настройки принтера
  const printers = store.get('printers', []);
  const printer = printers.find((p) => p.id === printerId);

  if (!printer || !printer.autoShutdownError) {
    console.log(`[SmartPlug] Auto-shutdown on error not enabled for printer ${printerId}`);
    return;
  }

  const tuyaConnection = tuyaConnections.get(printerId);
  const hasHA = printer.haEntityId && globalHomeAssistantAdapter;

  if (!tuyaConnection && !hasHA) return;

  const plugType = tuyaConnection ? 'Tuya' : 'Home Assistant';
  console.log(
    `[SmartPlug] ⚠️ Print error detected for ${printerName} (${printerId}), executing auto-shutdown via ${plugType}`,
  );

  try {
    let result;

    if (tuyaConnection) {
      result = await tuyaConnection.adapter.turnOff(tuyaConnection.deviceId);
    } else if (hasHA) {
      result = await globalHomeAssistantAdapter.turnOff(printer.haEntityId);
    }

    if (result && result.success) {
      console.log(`[SmartPlug] ✅ Printer ${printerName} powered off after error via ${plugType}`);

      // Отправить уведомление
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('printer-powered-off', {
          printerId: printerId,
          printerName: printerName,
          reason: 'auto_shutdown_after_error',
        });
      }
    }
  } catch (error) {
    console.error(`[SmartPlug] Failed to auto-shutdown printer ${printerId} after error:`, error);
  }
}

/**
 * Защита от перегрева - аварийное отключение
 * @param {string} printerId - ID принтера
 * @param {string} printerName - Имя принтера
 * @param {number} temperature - Температура MCU
 */
async function handleOverheat(printerId, printerName, temperature) {
  // Получить настройки принтера
  const printers = store.get('printers', []);
  const printer = printers.find((p) => p.id === printerId);

  if (!printer || !printer.autoShutdownOverheat) {
    console.log(`[SmartPlug] Overheat protection not enabled for printer ${printerId}`);
    return;
  }

  const tuyaConnection = tuyaConnections.get(printerId);
  const hasHA = printer.haEntityId && globalHomeAssistantAdapter;

  if (!tuyaConnection && !hasHA) return;

  // Критический порог
  const CRITICAL_TEMP = 70;

  if (temperature > CRITICAL_TEMP) {
    const plugType = tuyaConnection ? 'Tuya' : 'Home Assistant';
    console.error(
      `[SmartPlug] 🔥 CRITICAL: Printer ${printerName} (${printerId}) overheating! (${temperature}°C)`,
    );

    try {
      // Немедленно выключить питание
      let result;

      if (tuyaConnection) {
        result = await tuyaConnection.adapter.turnOff(tuyaConnection.deviceId);
      } else if (hasHA) {
        result = await globalHomeAssistantAdapter.turnOff(printer.haEntityId);
      }

      if (result && result.success) {
        console.log(
          `[SmartPlug] ✅ Emergency shutdown: Printer ${printerName} powered off via ${plugType}`,
        );

        // Отправить критическое уведомление
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('printer-emergency-shutdown', {
            printerId: printerId,
            printerName: printerName,
            temperature: temperature,
            reason: 'overheat',
          });
        }
      } else {
        console.error(
          `[SmartPlug] ❌ Failed to emergency shutdown: ${result?.error || 'Unknown error'}`,
        );
      }
    } catch (error) {
      console.error(`[SmartPlug] Exception during emergency shutdown for ${printerId}:`, error);
    }
  }
}

/**
 * Отменить запланированное отключение
 * @param {string} printerId - ID принтера
 */
function cancelScheduledShutdown(printerId) {
  if (shutdownTimers.has(printerId)) {
    clearTimeout(shutdownTimers.get(printerId));
    shutdownTimers.delete(printerId);
    console.log(`[Tuya] ⏹️ Cancelled scheduled shutdown for printer ${printerId}`);
  }
}

// Экспортируем функции для использования в других частях кода
// (Например, при обработке статуса принтера)
global.tuyaHandlePrintComplete = handlePrintComplete;
global.tuyaHandlePrintError = handlePrintError;
global.tuyaHandleOverheat = handleOverheat;
global.tuyaCancelShutdown = cancelScheduledShutdown;

// Menu events
ipcMain.on('menu-add-printer', () => {
  if (mainWindow) {
    mainWindow.webContents.send('menu-add-printer');
  }
});

ipcMain.on('menu-test-all', () => {
  if (mainWindow) {
    mainWindow.webContents.send('menu-test-all');
  }
});

ipcMain.on('show-telegram-help', () => {
  // Отправляем сообщение в renderer для открытия модального окна
  if (mainWindow) {
    // Clear cache before opening modal
    mainWindow.webContents.clearCache();
    mainWindow.webContents.send('show-telegram-help-modal');
  }
});

ipcMain.on('show-bambu-help', () => {
  // Отправляем сообщение в renderer для открытия модального окна
  if (mainWindow) {
    // Отправляем событие без очистки кеша (clearCache не существует в новых версиях)
    mainWindow.webContents.send('show-bambu-help-modal');
  }
});

// Bambu Lab interface data handlers
ipcMain.on('bambu-interface-ready', async (event, printerId) => {
  console.log('Bambu Lab interface ready for printer:', printerId);
  // Отправляем начальные данные
  await sendBambuDataToInterface(printerId);
});

ipcMain.on('request-bambu-data', async (event, printerId) => {
  console.log('Bambu data requested for printer:', printerId);
  await sendBambuDataToInterface(printerId);
});

async function sendBambuDataToInterface(printerId) {
  if (!tabsWindow || tabsWindow.isDestroyed()) {
    console.log('Tabs window not available for printer:', printerId);
    return;
  }

  console.log('Sending Bambu data to interface for printer:', printerId);

  try {
    // Получаем данные напрямую из адаптера MQTT
    const adapter = bambuConnections.get(printerId);
    if (adapter) {
      const printerData = await adapter.getPrinterData();
      console.log('Got printer data from adapter:', printerData);

      // Добавляем информацию о камере
      printerData.hasCamera = adapter.hasCamera();
      printerData.cameraStreamUrl = adapter.getCameraStreamUrl();

      // Добавляем недостающие данные для интерфейса Bambu
      printerData.fanStates = adapter.getFanStates();
      printerData.printSpeed = adapter.getPrintSpeed();
      printerData.hmsErrors = adapter.getActiveHmsErrors();
      printerData.isBambuJsSupported = adapter.isBambuJsSupported();

      // Camera data and additional data added to printer data

      // Отправляем данные в окно вкладок
      if (tabsWindow && !tabsWindow.isDestroyed()) {
        tabsWindow.webContents.send('bambu-data-update', printerId, printerData);
        // Data sent to tabs window
      }
    } else {
      // No MQTT adapter found
      // Отправляем сообщение об отсутствии данных
      if (tabsWindow && !tabsWindow.isDestroyed()) {
        tabsWindow.webContents.send('bambu-data-update', printerId, {
          status: 'offline',
          name: 'Unknown Printer',
          ip: 'Unknown',
          progress: 0,
          fileName: 'No file',
          temps: { nozzle: 0, bed: 0, chamber: 0, nozzle_target: 0, bed_target: 0 },
        });
      }
    }
  } catch (error) {
    console.error('Error getting printer data for interface:', error);
    // Отправляем сообщение об ошибке
    if (tabsWindow && !tabsWindow.isDestroyed()) {
      tabsWindow.webContents.send('bambu-data-update', printerId, {
        status: 'error',
        name: 'Error',
        ip: 'Unknown',
        progress: 0,
        fileName: 'No file',
        temps: { nozzle: 0, bed: 0, chamber: 0, nozzle_target: 0, bed_target: 0 },
      });
    }
  }
}

// Обработчик для пересылки данных Bambu Lab в окно вкладок
ipcMain.on('send-bambu-data', (event, printerId, data) => {
  if (tabsWindow && !tabsWindow.isDestroyed()) {
    console.log('Sending Bambu data to tabs window for printer:', printerId);
    tabsWindow.webContents.send('bambu-data-update', printerId, data);
  }
});

// ===== BAMBU LAB CAMERA MANAGEMENT =====

const cameraIntervals = new Map(); // printerId -> interval

// Функция sendCameraLog удалена для продакшена

// Хранилище CameraController для каждого принтера
const cameraControllers = new Map(); // printerId -> CameraController

/**
 * Загрузка изображения с камеры Bambu Lab через bambu-js библиотеку
 */
async function fetchBambuCamera(ip, accessCode, model = 'P1S') {
  // Сначала проверяем, поддерживает ли bambu-js эту модель
  try {
    const { isSupportedModel } = await import('bambu-js');

    if (!isSupportedModel(model)) {
      console.log(`[CAMERA] Model ${model} not supported by bambu-js, trying HTTP fallback`);
      throw new Error(`Model ${model} not supported by bambu-js`);
    }

    console.log(`[CAMERA] Model ${model} supported by bambu-js, attempting connection...`);
  } catch (error) {
    console.log(`[CAMERA] Error checking model support: ${error.message}`);
    // Продолжаем с HTTP fallback
  }

  // Сначала пробуем bambu-js (TCP метод)
  try {
    console.log(`[CAMERA] Attempting bambu-js method from ${ip} (model: ${model})`);

    // Динамический импорт bambu-js как ES модуль
    const { CameraController } = await import('bambu-js');
    console.log('[CAMERA] bambu-js imported successfully');

    // Создаем camera controller
    const camera = CameraController.create({
      model: model,
      host: ip,
      accessCode: accessCode,
      options: {
        connectionTimeout: 5000, // Уменьшил timeout
        maxFrameSize: 2 * 1024 * 1024, // 2MB
      },
    });
    console.log('[CAMERA] Camera controller created');

    // Захватываем кадр
    const frame = await camera.captureFrame();
    console.log(`[CAMERA] bambu-js success: ${frame.size} bytes, frame #${frame.frameNumber}`);

    // Конвертируем Buffer в base64 Data URL
    const base64 = frame.imageData.toString('base64');
    const dataUrl = `data:image/jpeg;base64,${base64}`;

    return dataUrl;
  } catch (error) {
    console.log(`[CAMERA] bambu-js failed: ${error.message}`);

    // Если bambu-js не работает, пробуем HTTP метод
    try {
      console.log(`[CAMERA] Trying HTTP method for ${ip}`);

      // Пробуем разные HTTP URL для камеры
      const urls = [
        `http://${ip}:8080/?action=stream`,
        `http://${ip}:8080/stream`,
        `http://${ip}:8080/cam.jpg`,
        `http://${ip}:8080/jpeg`,
        `http://${ip}/cgi-bin/mjpg/video.cgi?channel=0&subtype=1`,
        `http://${ip}/cam.jpg`,
      ];

      for (const url of urls) {
        try {
          console.log(`[CAMERA] Trying HTTP URL: ${url}`);

          const response = await new Promise((resolve, reject) => {
            const client = url.startsWith('https') ? https : http;
            const req = client.get(
              url,
              {
                timeout: 3000,
                headers: {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                },
              },
              resolve,
            );

            req.on('error', reject);
            req.setTimeout(3000, () => reject(new Error('Timeout')));
          });

          if (response.statusCode === 200) {
            console.log(`[CAMERA] HTTP success on: ${url}`);

            // Получаем изображение
            const chunks = [];
            response.on('data', (chunk) => chunks.push(chunk));

            await new Promise((resolve, reject) => {
              response.on('end', resolve);
              response.on('error', reject);
              setTimeout(() => reject(new Error('Timeout')), 5000);
            });

            const buffer = Buffer.concat(chunks);
            const base64 = buffer.toString('base64');
            const dataUrl = `data:image/jpeg;base64,${base64}`;

            console.log(`[CAMERA] HTTP image converted, size: ${buffer.length} bytes`);
            return dataUrl;
          }
        } catch (httpError) {
          console.log(`[CAMERA] HTTP failed for ${url}: ${httpError.message}`);
          continue;
        }
      }

      throw new Error('All HTTP methods failed');
    } catch (httpError) {
      console.log(`[CAMERA] HTTP method failed: ${httpError.message}`);

      // Если и HTTP не работает, возвращаем null
      console.log('[CAMERA] All camera methods failed');
      return null;
    }
  }
}

/**
 * Запуск периодической загрузки камеры для принтера
 */
function startCameraUpdates(printerId) {
  // Останавливаем существующий интервал если есть
  stopCameraUpdates(printerId);

  const printerData = printerTabs.get(printerId);

  if (!printerData) {
    console.error('[CAMERA] No printer data found for ID:', printerId);
    return;
  }

  if (printerData.type !== 'bambu') {
    console.error('[CAMERA] Not a Bambu printer, type:', printerData.type);
    return;
  }

  const cleanIp = printerData.ip.split(':')[0];
  const accessCode = printerData.accessCode;

  if (!accessCode) {
    console.error('[CAMERA] No access code for printer:', printerId);
    return;
  }

  // Определяем модель для bambu-js (поддерживаются только P1S и H2D)
  let model = 'P1S'; // По умолчанию

  // Сначала пытаемся получить реальную модель из MQTT данных
  const realModel = printerData.info?.machine_type || printerData.info?.model || '';
  const printerName = printerData.name || '';

  console.log(`[CAMERA] Real model from MQTT: "${realModel}", Printer name: "${printerName}"`);

  if (realModel) {
    // Используем реальную модель из MQTT
    const modelLower = realModel.toLowerCase();
    if (modelLower.includes('h2d')) {
      model = 'H2D';
    } else if (modelLower.includes('p1s')) {
      model = 'P1S';
    } else {
      // Для неподдерживаемых моделей используем P1S как fallback
      model = 'P1S';
    }
    console.log(`[CAMERA] Using real MQTT model: ${model} (from: ${realModel})`);
  } else {
    // Fallback: пытаемся определить по названию принтера
    const nameLower = printerName.toLowerCase();
    if (nameLower.includes('h2d')) {
      model = 'H2D';
    } else if (nameLower.includes('p1s')) {
      model = 'P1S';
    } else {
      // Для всех остальных моделей (X1C, A1, etc.) используем P1S как fallback
      model = 'P1S';
    }
    console.log(`[CAMERA] Using guessed model: ${model} (from name: ${printerName})`);
  }

  // Загружаем камеру каждые 3 секунды (чтобы не нагружать принтер)
  const interval = setInterval(async () => {
    const imageDataUrl = await fetchBambuCamera(cleanIp, accessCode, model);

    if (imageDataUrl && tabsWindow && !tabsWindow.isDestroyed()) {
      tabsWindow.webContents.send('bambu-camera-update', printerId, imageDataUrl);
    }
  }, 3000);

  cameraIntervals.set(printerId, interval);

  // Первая загрузка сразу
  (async () => {
    const imageDataUrl = await fetchBambuCamera(cleanIp, accessCode, model);
    if (imageDataUrl && tabsWindow && !tabsWindow.isDestroyed()) {
      tabsWindow.webContents.send('bambu-camera-update', printerId, imageDataUrl);
    }
  })();
}

/**
 * Остановка загрузки камеры
 */
function stopCameraUpdates(printerId) {
  if (cameraIntervals.has(printerId)) {
    clearInterval(cameraIntervals.get(printerId));
    cameraIntervals.delete(printerId);
    console.log('[CAMERA] Stopped camera updates for:', printerId);
  }
}

// IPC обработчик для запуска камеры
ipcMain.on('start-camera-updates', (event, printerId) => {
  console.log('[CAMERA IPC] ============================================');
  console.log('[CAMERA IPC] Start camera updates requested for:', printerId);
  console.log('[CAMERA IPC] printerTabs has this ID?:', printerTabs.has(printerId));
  console.log('[CAMERA IPC] Available printer IDs:', Array.from(printerTabs.keys()));
  startCameraUpdates(printerId);
});

ipcMain.on('stop-camera-updates', (event, printerId) => {
  console.log('[CAMERA IPC] Stop camera updates requested for:', printerId);
  stopCameraUpdates(printerId);
});

// IPC обработчик для управления Bambu Lab принтером
ipcMain.on('bambu-control', async (event, printerId, action, data = {}) => {
  console.log(
    '[BAMBU CONTROL] Command received:',
    action,
    'for printer:',
    printerId,
    'data:',
    data,
  );

  const adapter = bambuConnections.get(printerId);
  if (!adapter) {
    console.error('[BAMBU CONTROL] No adapter found for printer:', printerId);
    return;
  }

  try {
    switch (action) {
      case 'pause':
        console.log('[BAMBU CONTROL] Pausing print...');
        await adapter.pausePrint();
        break;
      case 'resume':
        console.log('[BAMBU CONTROL] Resuming print...');
        await adapter.resumePrint();
        break;
      case 'stop':
        console.log('[BAMBU CONTROL] Stopping print...');
        await adapter.stopPrint();
        break;
      case 'led_on':
        console.log('[BAMBU CONTROL] Turning LED on...');
        await adapter.setCameraLed(true);
        break;
      case 'led_off':
        console.log('[BAMBU CONTROL] Turning LED off...');
        await adapter.setCameraLed(false);
        break;
      case 'speed_1':
        console.log('[BAMBU CONTROL] Setting speed to 1 (silent)...');
        await adapter.setPrintSpeed(1);
        break;
      case 'speed_2':
        console.log('[BAMBU CONTROL] Setting speed to 2 (normal)...');
        await adapter.setPrintSpeed(2);
        break;
      case 'speed_3':
        console.log('[BAMBU CONTROL] Setting speed to 3 (sport)...');
        await adapter.setPrintSpeed(3);
        break;
      case 'speed_4':
        console.log('[BAMBU CONTROL] Setting speed to 4 (ludicrous)...');
        await adapter.setPrintSpeed(4);
        break;
      case 'set_nozzle_temp':
        console.log('[BAMBU CONTROL] Setting nozzle temperature...');
        const nozzleTemp = data.temperature;
        if (nozzleTemp !== undefined) {
          await adapter.setNozzleTemperature(nozzleTemp);
        }
        break;
      case 'set_bed_temp':
        console.log('[BAMBU CONTROL] Setting bed temperature...');
        const bedTemp = data.temperature;
        if (bedTemp !== undefined) {
          await adapter.setBedTemperature(bedTemp);
        }
        break;
      case 'set_fan_speed':
        console.log('[BAMBU CONTROL] Setting fan speed...');
        const fanType = data.fanType;
        const fanSpeed = data.speed;
        if (fanType && fanSpeed !== undefined) {
          await adapter.setFanSpeed(fanType, fanSpeed);
        }
        break;
      default:
        console.error('[BAMBU CONTROL] Unknown action:', action);
    }

    console.log('[BAMBU CONTROL] Command executed successfully:', action);
  } catch (error) {
    console.error('[BAMBU CONTROL] Error executing command:', action, error.message);
  }
});

// IPC обработчик для загрузки файлов на Bambu Lab принтер
ipcMain.handle('bambu-upload-file', async (event, printerId, file) => {
  console.log('[BAMBU UPLOAD] File upload requested for printer:', printerId);

  const adapter = bambuConnections.get(printerId);
  if (!adapter) {
    console.error('[BAMBU UPLOAD] No adapter found for printer:', printerId);
    return { success: false, error: 'Printer adapter not found' };
  }

  try {
    const result = await adapter.uploadFile(file);
    if (result) {
      console.log('[BAMBU UPLOAD] ✅ File uploaded successfully');
      return { success: true };
    } else {
      console.error('[BAMBU UPLOAD] ❌ File upload failed');
      return { success: false, error: 'File upload failed' };
    }
  } catch (error) {
    console.error('[BAMBU UPLOAD] ❌ Error uploading file:', error.message);
    return { success: false, error: error.message };
  }
});

// IPC обработчик для запуска печати на Bambu Lab принтере
ipcMain.handle('bambu-start-print', async (event, printerId, fileName) => {
  console.log('[BAMBU PRINT] Print start requested for printer:', printerId);

  const adapter = bambuConnections.get(printerId);
  if (!adapter) {
    console.error('[BAMBU PRINT] No adapter found for printer:', printerId);
    return { success: false, error: 'Printer adapter not found' };
  }

  try {
    const result = await adapter.startPrint(fileName);
    if (result) {
      console.log('[BAMBU PRINT] ✅ Print started successfully');
      return { success: true };
    } else {
      console.error('[BAMBU PRINT] ❌ Print start failed');
      return { success: false, error: 'Print start failed' };
    }
  } catch (error) {
    console.error('[BAMBU PRINT] ❌ Error starting print:', error.message);
    return { success: false, error: error.message };
  }
});

// IPC Handlers for diagnostics
ipcMain.handle('diagnostics-track-printer-added', (event, printerType) => {
  reporter.trackPrinterAdded(printerType);
});

ipcMain.handle('diagnostics-update-printers', (event, printers) => {
  reporter.updatePrintersCount(printers);
  reporter.updateSmartPlugsStats(printers);
});

ipcMain.handle('diagnostics-track-feature', (event, featureName) => {
  reporter.trackFeatureUsage(featureName);
});

ipcMain.handle('diagnostics-track-analytics-view', () => {
  reporter.trackAnalyticsView();
});

ipcMain.handle('diagnostics-track-export', (event, format) => {
  reporter.trackExport(format);
});

// === НОВЫЕ IPC ОБРАБОТЧИКИ АНАЛИТИКИ v1.5.36 ===

ipcMain.handle('diagnostics-track-smartplug-config', (event, type, configured) => {
  reporter.trackSmartPlugConfig(type, configured);
});

ipcMain.handle('diagnostics-update-smartplugs-stats', (event, printers) => {
  reporter.updateSmartPlugsStats(printers);
});

ipcMain.handle('diagnostics-track-batch-add', (event, count) => {
  reporter.trackBatchAdd(count);
});

ipcMain.handle('diagnostics-track-network-scan', () => {
  reporter.trackNetworkScan();
});

ipcMain.handle('diagnostics-track-print-event', (event, eventType) => {
  reporter.trackPrintEvent(eventType);
});

ipcMain.handle('diagnostics-update-temperatures', (event, data) => {
  reporter.updateTemperatures(data);
});

ipcMain.handle('diagnostics-track-manual-plug-toggle', () => {
  reporter.trackManualPlugToggle();
});

ipcMain.handle('diagnostics-track-webserver-start', (event, port) => {
  reporter.trackWebServerStart(port);
});

ipcMain.handle('diagnostics-track-analytics-open', () => {
  reporter.trackAnalyticsOpen();
});

ipcMain.handle('diagnostics-track-help-page-open', () => {
  reporter.trackHelpPageOpen();
});

ipcMain.handle('diagnostics-force-sync', async () => {
  await reporter.sync(true); // force = true
  return { success: true };
});

ipcMain.handle('diagnostics-set-theme', (event, theme) => {
  reporter.setCurrentTheme(theme);
});

ipcMain.handle('diagnostics-set-webserver', (event, enabled) => {
  reporter.setWebServerEnabled(enabled);
});

// ===== WEB SERVER MANAGEMENT =====

/**
 * Запустить web-сервер
 */
ipcMain.handle('start-web-server', async (event, port) => {
  try {
    if (webServer.isRunning) {
      return {
        success: true,
        message: 'Web-сервер уже запущен',
        info: webServer.getInfo(),
      };
    }

    const result = await webServer.start(port || 8000);
    isWebServerEnabled = true;
    store.set('webServerEnabled', true);
    store.set('webServerPort', port || 8000);

    // Обновляем статус в телеметрии
    reporter.setWebServerEnabled(true);

    console.log(`[WebServer] ✅ Запущен на порту ${result.port}`);

    // Отправляем обновление в renderer
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('web-server-status', webServer.getInfo());
    }

    return {
      success: true,
      message: `Web-сервер запущен на http://localhost:${result.port}`,
      info: webServer.getInfo(),
    };
  } catch (error) {
    console.error('[WebServer] Ошибка запуска:', error);
    return {
      success: false,
      error: error.message,
    };
  }
});

/**
 * Остановить web-сервер
 */
ipcMain.handle('stop-web-server', async () => {
  try {
    await webServer.stop();
    isWebServerEnabled = false;
    store.set('webServerEnabled', false);

    // Обновляем статус в телеметрии
    reporter.setWebServerEnabled(false);

    // Отправляем обновление в renderer
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('web-server-status', webServer.getInfo());
    }

    return {
      success: true,
      message: 'Web-сервер остановлен',
    };
  } catch (error) {
    console.error('[WebServer] Ошибка остановки:', error);
    return {
      success: false,
      error: error.message,
    };
  }
});

/**
 * Получить информацию о web-сервере
 */
ipcMain.handle('get-web-server-info', () => {
  return webServer.getInfo();
});

/**
 * Открыть web-интерфейс в браузере
 */
ipcMain.handle('open-web-interface', () => {
  const info = webServer.getInfo();
  if (info.isRunning && info.url) {
    shell.openExternal(info.url);
    return { success: true };
  }
  return { success: false, error: 'Web-сервер не запущен' };
});

/**
 * Открыть внешнюю ссылку в браузере
 */
ipcMain.handle('open-external-link', (event, url) => {
  try {
    shell.openExternal(url);
    return { success: true };
  } catch (error) {
    console.error('[IPC] Error opening external link:', error);
    return { success: false, error: error.message };
  }
});

/**
 * Получить сетевые интерфейсы хоста
 */
ipcMain.handle('get-network-interfaces', () => {
  const interfaces = os.networkInterfaces();
  const addresses = [];

  Object.keys(interfaces).forEach((name) => {
    interfaces[name].forEach((iface) => {
      // Только IPv4, не внутренние
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push({
          name: name,
          address: iface.address,
        });
      }
    });
  });

  return addresses;
});

// Отправка обновлений принтеров в web-сервер
function notifyWebServerPrinterUpdate(printerId, data) {
  // Сохраняем данные в структурированный кэш
  const wasUpdated = structuredManager.updatePrinterData(printerId, data);

  // Рассылаем через WebSocket только если данные обновились
  if (webServer.isRunning && wasUpdated) {
    webServer.broadcastPrinterUpdate(printerId, data);
  }
}

function notifyWebServerPrinterStatus(printerId, status) {
  if (webServer.isRunning) {
    webServer.broadcastPrinterStatus(printerId, status);
  }
}

/**
 * IPC handler для обновления данных принтера из renderer
 */
ipcMain.handle('update-printer-data', (event, printerId, data) => {
  try {
    // Сохраняем данные в структурированный менеджер
    structuredManager.updatePrinterData(printerId, data);

    // Отправляем в web-сервер
    notifyWebServerPrinterUpdate(printerId, data);
    notifyWebServerPrinterStatus(printerId, data);

    return { success: true };
  } catch (error) {
    console.error('[IPC] Error updating printer data:', error);
    return { success: false, error: error.message };
  }
});

// ===== UPDATE CHECKER =====

/**
 * Проверка наличия обновлений через API сайта (вместо GitHub API)
 */
async function checkForUpdates() {
  return new Promise((resolve) => {
    const options = {
      hostname: 'tomich.fun',
      path: '/api/latest-version',
      method: 'GET',
      headers: {
        'User-Agent': '3D-Printer-Control-Panel',
      },
    };

    const req = https.request(options, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        try {
          if (res.statusCode === 200) {
            const info = JSON.parse(data);
            const latestVersion = info.version; // Уже без 'v'
            const currentVersion = APP_VERSION;

            // Сравниваем версии
            if (compareVersions(latestVersion, currentVersion) > 0) {
              resolve({
                hasUpdate: true,
                latestVersion: latestVersion,
                currentVersion: currentVersion,
                releaseUrl: info.download_url || 'https://tomich.fun/download',
                releaseNotes: info.notes,
                releaseName: info.name,
                publishedAt: info.published_at,
              });
            } else {
              resolve({ hasUpdate: false, currentVersion: currentVersion });
            }
          } else {
            console.log('[UpdateChecker] API returned status:', res.statusCode);
            resolve({ hasUpdate: false, currentVersion: APP_VERSION });
          }
        } catch (error) {
          console.error('[UpdateChecker] Error parsing response:', error);
          resolve({ hasUpdate: false, currentVersion: APP_VERSION });
        }
      });
    });

    req.on('error', (error) => {
      console.error('[UpdateChecker] Request error:', error);
      resolve({ hasUpdate: false, currentVersion: APP_VERSION });
    });

    req.setTimeout(10000, () => {
      req.destroy();
      console.log('[UpdateChecker] Request timeout');
      resolve({ hasUpdate: false, currentVersion: APP_VERSION });
    });

    req.end();
  });
}

/**
 * Сравнение версий (semver) для API
 * @returns {number} 1 если v1 > v2, -1 если v1 < v2, 0 если равны
 */
function compareVersionsAPI(v1, v2) {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);

  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;

    if (p1 > p2) return 1;
    if (p1 < p2) return -1;
  }

  return 0;
}

/**
 * IPC handler для проверки обновлений
 */
ipcMain.handle('check-for-updates', async () => {
  const updateInfo = await checkForUpdates();
  return updateInfo;
});

/**
 * IPC handler для открытия страницы релиза
 */
ipcMain.handle('open-release-page', async (event, url) => {
  shell.openExternal(url);
});

// ============================================================================
// LICENSING IPC HANDLERS
// ============================================================================

ipcMain.handle('licensing-init', () => {
  return initLicensing();
});

ipcMain.handle('licensing-get-status', () => {
  return getLicenseStatus();
});

ipcMain.handle('licensing-check', (event, printerCount) => {
  return checkLicense(printerCount);
});

ipcMain.handle('licensing-can-add-printer', () => {
  return canAddPrinter();
});

ipcMain.handle('licensing-activate', async (event, key) => {
  return await activateLicense(key);
});

ipcMain.handle('licensing-request', async (event, params) => {
  return await requestLicense(params);
});

ipcMain.handle('licensing-get-hwid', () => {
  const systemInfo = getSystemInfo();
  return {
    hwid: systemInfo.hwid,
    formatted: formatHWID(systemInfo.hwid),
    system: systemInfo,
  };
});

// App events
app.whenReady().then(async () => {
  // Выполняем миграцию данных перед инициализацией
  await performStartupMigration();

  // Инициализация лицензирования
  initLicensing();
  console.log('[App] Licensing system initialized');

  await reporter.initialize();
  reporter.trackSession();

  createMainWindow();

  // Автозапуск web-сервера если был включен ранее
  const webServerEnabled = store.get('webServerEnabled', false);
  if (webServerEnabled) {
    const webServerPort = store.get('webServerPort', 8000);
    try {
      await webServer.start(webServerPort);
      isWebServerEnabled = true;
      reporter.setWebServerEnabled(true); // Обновляем телеметрию
      console.log(`[WebServer] ✅ Автозапуск на порту ${webServerPort}`);
    } catch (error) {
      console.error('[WebServer] Ошибка автозапуска:', error);
    }
  }

  // Инициализация Tuya адаптера
  const tuyaConfig = store.get('tuyaConfig');
  if (tuyaConfig && tuyaConfig.accessId && tuyaConfig.accessSecret) {
    try {
      // Проверяем тип secret
      if (typeof tuyaConfig.accessSecret !== 'string') {
        console.warn('[Tuya] Invalid secret type:', typeof tuyaConfig.accessSecret);
        store.delete('tuyaConfig');
        return;
      }

      const decryptedSecret = await decrypt(tuyaConfig.accessSecret);
      if (!decryptedSecret || typeof decryptedSecret !== 'string') {
        console.warn('[Tuya] Failed to decrypt secret or invalid result type');
        store.delete('tuyaConfig');
        return;
      }

      globalTuyaAdapter = new TuyaAdapter({
        baseUrl: tuyaConfig.baseUrl || 'https://openapi.tuyaeu.com',
        accessKey: tuyaConfig.accessId,
        secretKey: decryptedSecret,
        debug: process.argv.includes('--dev'),
      });

      const isConnected = await globalTuyaAdapter.testConnection();
      if (isConnected) {
        console.log('[Tuya] ✅ Tuya Cloud API connected');
      } else {
        console.log('[Tuya] ❌ Tuya Cloud API connection failed');
        globalTuyaAdapter = null;
      }
    } catch (error) {
      console.error('[Tuya] Автоподключение ошибка:', error);
      globalTuyaAdapter = null;
      store.delete('tuyaConfig');
    }
  }

  // Инициализация Home Assistant адаптера
  const haConfig = store.get('homeassistantConfig');
  if (haConfig && haConfig.baseUrl && haConfig.token) {
    try {
      // Проверяем тип токена
      if (typeof haConfig.token !== 'string') {
        console.warn('[HomeAssistant] Invalid token type:', typeof haConfig.token);
        store.delete('homeassistantConfig');
        return;
      }

      const decryptedToken = await decrypt(haConfig.token);
      if (!decryptedToken || typeof decryptedToken !== 'string') {
        console.warn('[HomeAssistant] Failed to decrypt token or invalid result type');
        store.delete('homeassistantConfig');
        return;
      }

      globalHomeAssistantAdapter = new HomeAssistantAdapter({
        baseUrl: haConfig.baseUrl,
        token: decryptedToken,
        debug: process.argv.includes('--dev'),
      });

      const isConnected = await globalHomeAssistantAdapter.testConnection();
      if (isConnected) {
        console.log('[HomeAssistant] ✅ Home Assistant API connected');
      } else {
        console.log('[HomeAssistant] ❌ Home Assistant API connection failed');
        globalHomeAssistantAdapter = null; // Сбросить при неудаче
      }
    } catch (error) {
      console.error('[HomeAssistant] Initialization error:', error);
      globalHomeAssistantAdapter = null;
      store.delete('homeassistantConfig');
    }
  }

  // Проверка обновлений через 5 секунд после запуска
  setTimeout(async () => {
    const updateInfo = await checkForUpdates();
    if (updateInfo.hasUpdate && mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('update-available', updateInfo);
      console.log(`[UpdateChecker] ✅ New version available: ${updateInfo.latestVersion}`);
    } else {
      console.log(`[UpdateChecker] ✅ Running latest version: ${APP_VERSION}`);
    }
  }, 5000);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', async () => {
  // Stop web server
  if (webServer.isRunning) {
    try {
      await webServer.stop();
      console.log('[WebServer] Stopped on app quit');
    } catch (error) {
      console.error('[WebServer] Error stopping on quit:', error);
    }
  }

  // Close all Bambu Lab connections
  for (const [printerId, adapter] of bambuConnections.entries()) {
    try {
      await adapter.closeConnection();
      console.log(`Closed Bambu Lab connection for printer: ${printerId}`);
    } catch (error) {
      console.error(`Error closing Bambu connection for ${printerId}:`, error);
    }
  }
  bambuConnections.clear();

  if (tabsWindow && !tabsWindow.isDestroyed()) {
    tabsWindow.destroy();
  }
});
