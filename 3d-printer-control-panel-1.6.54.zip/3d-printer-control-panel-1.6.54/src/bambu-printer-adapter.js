/**
 * Адаптер для 3D принтеров Bambu Lab
 * Использует MQTT протокол для связи с принтером
 */

import PrinterAdapter from './printer-adapter.js';
import mqtt from 'mqtt';

class BambuLabAdapter extends PrinterAdapter {
  constructor(printer, mqttClient = null) {
    super(printer);
    this.mqttClient = mqttClient;
    this.printerData = {
      print: {},
      temps: {
        nozzle: 0,
        nozzle_target: 0,
        bed: 0,
        bed_target: 0,
        chamber: null, // null пока не получим данные с принтера
      },
      info: {},
      gcode_state: 'IDLE',
    };
    this.isConnected = false;
    this.messageHandler = null;
    // Кэшируем успешный протокол подключения (mqtts или mqtt)
    this.preferredProtocol = printer.preferredProtocol || null;
  }

  static getType() {
    return 'bambu';
  }

  /**
   * Тестирование подключения к принтеру Bambu Lab через MQTT
   */
  async testConnection() {
    try {
      const { ip, accessCode, serialNumber } = this.printer;

      if (!ip || !accessCode || !serialNumber) {
        throw new Error('IP, Access Code and Serial Number are required for Bambu Lab');
      }

      // Если у нас есть сохраненный успешный протокол, пробуем его первым
      if (this.preferredProtocol) {
        const useSecure = this.preferredProtocol === 'mqtts';
        try {
          console.log(`Trying cached protocol: ${this.preferredProtocol.toUpperCase()}`);
          return await this.tryConnect(mqtt, ip, accessCode, serialNumber, useSecure);
        } catch (error) {
          console.log(
            `Cached protocol ${this.preferredProtocol.toUpperCase()} failed, trying alternatives...`,
          );
          // Сбрасываем кэш если не сработало
          this.preferredProtocol = null;
          this.printer.preferredProtocol = null;
        }
      }

      // Пробуем сначала MQTTS (новые прошивки 1.09+), потом MQTT (старые прошивки)
      return await this.tryConnect(mqtt, ip, accessCode, serialNumber, true).catch(() => {
        console.log('MQTTS failed, trying plain MQTT for older firmware...');
        return this.tryConnect(mqtt, ip, accessCode, serialNumber, false);
      });
    } catch (error) {
      console.error('Bambu Lab connection error:', error);
      throw error;
    }
  }

  /**
   * Попытка подключения через MQTT/MQTTS
   */
  async tryConnect(mqtt, ip, accessCode, serialNumber, useSecure) {
    const protocol = useSecure ? 'mqtts' : 'mqtt';
    const mqttUrl = `${protocol}://${ip}:8883`;

    console.log(`Trying ${protocol.toUpperCase()} connection to ${ip}...`);

    const options = {
      username: 'bblp',
      password: accessCode,
      clientId: `3DPC_${Date.now()}`,
      reconnectPeriod: 0,
      connectTimeout: 10000,
    };

    // Для MQTTS добавляем параметры TLS
    if (useSecure) {
      options.rejectUnauthorized = false;
      options.protocol = 'mqtts';
    }

    const client = mqtt.connect(mqttUrl, options);

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        client.end();
        reject(
          new Error(
            `${protocol.toUpperCase()} connection timeout - превышено время ожидания подключения (10 сек)`,
          ),
        );
      }, 10000);

      client.on('connect', () => {
        clearTimeout(timeout);
        this.mqttClient = client;
        this.isConnected = true;
        this.usedProtocol = protocol;

        // Сохраняем успешный протокол для будущих подключений
        this.preferredProtocol = protocol;
        this.printer.preferredProtocol = protocol;

        console.log(
          `✅ Connected via ${protocol.toUpperCase()} to Bambu Lab printer (saved for future connections)`,
        );

        // Подписываемся на топик статуса принтера
        const topic = `device/${serialNumber}/report`;
        client.subscribe(topic, (err) => {
          if (err) {
            console.error('Subscribe error:', err);
          }
        });

        // Запрашиваем текущий статус
        this.requestStatus();

        resolve(true);
      });

      client.on('error', (error) => {
        clearTimeout(timeout);
        client.end();

        // Улучшенная диагностика ошибок
        let errorMessage = `Ошибка подключения к Bambu Lab (${protocol.toUpperCase()}): `;

        if (error.code === 'ECONNREFUSED') {
          errorMessage +=
            'Принтер недоступен. Проверьте IP адрес и убедитесь, что принтер включен.';
        } else if (error.code === 'ETIMEDOUT' || error.code === 'ESOCKETTIMEDOUT') {
          errorMessage += 'Превышено время ожидания. Проверьте сетевое подключение и firewall.';
        } else if (error.code === 'ENOTFOUND') {
          errorMessage += 'Неверный IP адрес.';
        } else if (
          error.toString().includes('Not authorized') ||
          error.toString().includes('auth')
        ) {
          errorMessage += 'Неверный Access Code. Проверьте код в настройках принтера.';
        } else {
          errorMessage += error.message || error.toString();
        }

        console.error('Bambu Lab connection error:', {
          protocol,
          ip,
          error: error.message,
          code: error.code,
          fullError: error,
        });

        reject(new Error(errorMessage));
      });
    });
  }

  /**
   * Запрос текущего статуса принтера
   */
  requestStatus() {
    if (!this.mqttClient || !this.isConnected) return;

    const { serialNumber } = this.printer;
    const requestTopic = `device/${serialNumber}/request`;

    // Запрос информации о принтере
    const pushAllCommand = {
      pushing: {
        sequence_id: Date.now().toString(),
        command: 'pushall',
      },
    };

    this.mqttClient.publish(requestTopic, JSON.stringify(pushAllCommand));
  }

  /**
   * Установка MQTT подключения с обработчиками сообщений
   */
  async setupRealtimeConnection() {
    if (!this.mqttClient || !this.isConnected) {
      await this.testConnection();
    }

    const { serialNumber } = this.printer;
    const topic = `device/${serialNumber}/report`;

    // Обработка входящих сообщений
    this.messageHandler = (receivedTopic, message) => {
      if (receivedTopic === topic) {
        try {
          const data = JSON.parse(message.toString());
          this.handlePrinterMessage(data);
        } catch (error) {
          console.error('Error parsing MQTT message:', error);
        }
      }
    };

    this.mqttClient.on('message', this.messageHandler);

    // Периодический запрос статуса
    this.statusInterval = setInterval(() => {
      this.requestStatus();
    }, 30000); // каждые 30 секунд
  }

  /**
   * Обработка сообщений от принтера
   */
  handlePrinterMessage(data) {
    console.log('Bambu Lab MQTT message received:', JSON.stringify(data, null, 2));

    // Логируем ВСЕ ключи верхнего уровня для поиска данных камеры и модели
    console.log('[MQTT] Top level keys:', Object.keys(data));

    // Ищем информацию о модели принтера во всех возможных полях
    if (data.print) {
      console.log('[MQTT] Print keys:', Object.keys(data.print));

      // Проверяем поля которые могут содержать информацию о модели
      const modelFields = [
        'machine_type',
        'model',
        'printer_type',
        'device_type',
        'hw_ver',
        'sw_ver',
      ];
      modelFields.forEach((field) => {
        if (data.print[field] !== undefined) {
          console.log(`[MODEL INFO] ${field}:`, data.print[field]);
        }
      });
    }

    // Проверяем другие возможные поля с информацией о модели
    const possibleModelFields = ['info', 'device', 'printer', 'system'];
    possibleModelFields.forEach((field) => {
      if (data[field] && typeof data[field] === 'object') {
        console.log(`[MODEL INFO] ${field} keys:`, Object.keys(data[field]));
        const modelFields = [
          'machine_type',
          'model',
          'printer_type',
          'device_type',
          'hw_ver',
          'sw_ver',
        ];
        modelFields.forEach((modelField) => {
          if (data[field][modelField] !== undefined) {
            console.log(`[MODEL INFO] ${field}.${modelField}:`, data[field][modelField]);
          }
        });
      }
    });

    // Обновляем данные принтера
    if (data.print) {
      this.printerData.print = { ...this.printerData.print, ...data.print };
      console.log('Updated print data:', this.printerData.print);

      // Сохраняем информацию о модели принтера, если найдена
      if (data.print.machine_type) {
        this.printerData.info = this.printerData.info || {};
        this.printerData.info.machine_type = data.print.machine_type;
        console.log('[MODEL SAVED] machine_type:', data.print.machine_type);
      }
      if (data.print.model) {
        this.printerData.info = this.printerData.info || {};
        this.printerData.info.model = data.print.model;
        console.log('[MODEL SAVED] model:', data.print.model);
      }
      if (data.print.hw_ver) {
        this.printerData.info = this.printerData.info || {};
        this.printerData.info.hw_ver = data.print.hw_ver;
        console.log('[MODEL SAVED] hw_ver:', data.print.hw_ver);
      }

      // Проверяем поля камеры
      if (data.print.ipcam_dev !== undefined) {
        console.log('[CAMERA] ipcam_dev found:', data.print.ipcam_dev);
      }
      if (data.print.ipcam_record !== undefined) {
        console.log('[CAMERA] ipcam_record found:', data.print.ipcam_record);
      }
    }

    // Температуры - проверяем различные возможные поля
    if (data.print) {
      // Проверяем все возможные поля для температур
      const tempFields = [
        'nozzle_temper',
        'nozzle_temperature',
        'hotend_temp',
        'extruder_temp',
        'bed_temper',
        'bed_temperature',
        'bed_temp',
        'chamber_temper',
        'chamber_temperature',
        'chamber_temp',
      ];

      console.log('Available temperature fields in data.print:', Object.keys(data.print));

      // Сопло
      if (data.print.nozzle_temper !== undefined) {
        this.printerData.temps.nozzle = data.print.nozzle_temper;
        this.printerData.temps.nozzle_target = data.print.nozzle_target_temper || 0;
        console.log(
          'Updated nozzle temp:',
          data.print.nozzle_temper,
          'target:',
          data.print.nozzle_target_temper,
        );
      }
      if (data.print.nozzle_temperature !== undefined) {
        this.printerData.temps.nozzle = data.print.nozzle_temperature;
        this.printerData.temps.nozzle_target = data.print.nozzle_target_temperature || 0;
        console.log('Updated nozzle temp (alt):', data.print.nozzle_temperature);
      }

      // Стол
      if (data.print.bed_temper !== undefined) {
        this.printerData.temps.bed = data.print.bed_temper;
        this.printerData.temps.bed_target = data.print.bed_target_temper || 0;
        console.log(
          'Updated bed temp:',
          data.print.bed_temper,
          'target:',
          data.print.bed_target_temper,
        );
      }
      if (data.print.bed_temperature !== undefined) {
        this.printerData.temps.bed = data.print.bed_temperature;
        this.printerData.temps.bed_target = data.print.bed_target_temperature || 0;
        console.log('Updated bed temp (alt):', data.print.bed_temperature);
      }

      // Камера (фильтруем нереалистично низкие значения < 10°C, которые могут приходить с принтеров без датчика)
      if (data.print.chamber_temper !== undefined) {
        if (data.print.chamber_temper >= 10) {
          this.printerData.temps.chamber = data.print.chamber_temper;
          console.log('Updated chamber temp:', data.print.chamber_temper);
        } else {
          this.printerData.temps.chamber = null;
          console.log(
            'Ignoring invalid chamber temp:',
            data.print.chamber_temper,
            '(too low, sensor likely not present)',
          );
        }
      }
      if (data.print.chamber_temperature !== undefined) {
        if (data.print.chamber_temperature >= 10) {
          this.printerData.temps.chamber = data.print.chamber_temperature;
          console.log('Updated chamber temp (alt):', data.print.chamber_temperature);
        } else {
          this.printerData.temps.chamber = null;
          console.log(
            'Ignoring invalid chamber temp (alt):',
            data.print.chamber_temperature,
            '(too low, sensor likely not present)',
          );
        }
      }
    }

    // Состояние печати
    if (data.print && data.print.gcode_state !== undefined) {
      this.printerData.gcode_state = data.print.gcode_state;
    }

    // Прогресс
    if (data.print && data.print.mc_percent !== undefined) {
      this.printerData.print.progress = data.print.mc_percent;
    }

    // Оставшееся время (в минутах)
    if (data.print && data.print.mc_remaining_time !== undefined) {
      this.printerData.print.remaining_time = data.print.mc_remaining_time;
    }

    // Текущий слой и общее количество
    if (data.print && data.print.layer_num !== undefined) {
      this.printerData.print.layer_num = data.print.layer_num;
    }
    if (data.print && data.print.total_layer_num !== undefined) {
      this.printerData.print.total_layer_num = data.print.total_layer_num;
    }

    // Скорость печати
    if (data.print && data.print.spd_mag !== undefined) {
      this.printerData.print.speed_magnitude = data.print.spd_mag;
    }

    // AMS статус
    if (data.print && data.print.ams !== undefined) {
      this.printerData.ams = data.print.ams;
    }
    if (data.print && data.print.ams_status !== undefined) {
      this.printerData.ams_status = data.print.ams_status;
    }

    // Имя файла
    if (data.print && data.print.subtask_name !== undefined) {
      this.printerData.print.filename = data.print.subtask_name;
    }

    // Обновляем объект принтера
    this.updatePrinterObject();

    // Вызываем callback если установлен
    if (this.printer.onDataUpdate) {
      this.printer.onDataUpdate(this.printer);
    }
  }

  /**
   * Обновление объекта принтера с новыми данными
   */
  updatePrinterObject() {
    this.printer.lastUpdate = new Date();
    this.printer.data = this.printerData;
    this.printer.connectionType = 'MQTT';
  }

  /**
   * Получение данных о принтере
   */
  async getPrinterData() {
    this.requestStatus();
    return this.printerData;
  }

  /**
   * Обновление статуса
   */
  async updateStatus() {
    if (this.isConnected) {
      this.requestStatus();
    } else {
      await this.testConnection();
    }
  }

  /**
   * Получение прогресса печати (0-100)
   */
  getProgress() {
    if (this.printer.status === 'offline') {
      return 0;
    }
    return this.printerData.print?.progress || 0;
  }

  /**
   * Получение имени файла
   */
  getFileName() {
    if (this.printer.status === 'offline') {
      return 'No connection';
    }

    const filename = this.printerData.print?.filename || this.printerData.print?.subtask_name;

    if (!filename || filename === '' || filename === 'null') {
      return 'No file';
    }

    try {
      const shortName = filename.split('/').pop().split('\\').pop();
      return shortName.length > 25 ? shortName.substring(0, 25) + '...' : shortName;
    } catch (error) {
      return filename.length > 25 ? filename.substring(0, 25) + '...' : filename;
    }
  }

  /**
   * Получение температур
   */
  getTemperatures() {
    const temps = this.printerData.temps || {};
    console.log('Getting temperatures - current temps data:', temps);
    console.log('Full printer data:', this.printerData);

    const result = {
      nozzle: temps.nozzle || 0,
      nozzle_target: temps.nozzle_target || 0,
      bed: temps.bed || 0,
      bed_target: temps.bed_target || 0,
      chamber: temps.chamber || null,
    };

    console.log('Returning temperatures:', result);
    return result;
  }

  /**
   * Получение статуса принтера
   * Bambu Lab states: IDLE, RUNNING, PAUSE, FINISH, FAILED
   */
  getStatus() {
    if (!this.isConnected) {
      return 'offline';
    }

    const state = this.printerData.gcode_state;

    switch (state) {
      case 'RUNNING':
        return 'printing';
      case 'PAUSE':
        return 'paused';
      case 'FINISH':
        return 'complete';
      case 'FAILED':
        return 'error';
      case 'IDLE':
      default:
        return 'ready';
    }
  }

  /**
   * Получение текстового описания состояния
   */
  getStateText() {
    const status = this.getStatus();

    const stateMap = {
      offline: 'Принтер offline',
      ready: 'Готов',
      printing: 'Печатает',
      paused: 'Пауза',
      complete: 'Завершено',
      error: 'Ошибка',
    };

    return stateMap[status] || 'Неизвестно';
  }

  /**
   * Расшифровка HMS ошибок с рекомендациями
   */
  getHmsErrorInfo(errorCode) {
    const hmsErrors = {
      '0300-1100-0002-0002': {
        title: 'hms_hotend_temp_error',
        description: 'hms_hotend_temp_desc',
        solution: 'hms_hotend_temp_solution',
        severity: 'high',
      },
      '0300-1100-0002-0003': {
        title: 'hms_bed_temp_error',
        description: 'hms_bed_temp_desc',
        solution: 'hms_bed_temp_solution',
        severity: 'high',
      },
      '0300-1100-0002-0004': {
        title: 'hms_chamber_temp_error',
        description: 'hms_chamber_temp_desc',
        solution: 'hms_chamber_temp_solution',
        severity: 'medium',
      },
      '0300-1100-0002-0005': {
        title: 'hms_fan_error',
        description: 'hms_fan_desc',
        solution: 'hms_fan_solution',
        severity: 'medium',
      },
      '0300-1100-0002-0006': {
        title: 'hms_extruder_error',
        description: 'hms_extruder_desc',
        solution: 'hms_extruder_solution',
        severity: 'high',
      },
      '0300-1100-0002-0007': {
        title: 'hms_z_axis_error',
        description: 'hms_z_axis_desc',
        solution: 'hms_z_axis_solution',
        severity: 'high',
      },
      '0300-1100-0002-0008': {
        title: 'hms_x_axis_error',
        description: 'hms_x_axis_desc',
        solution: 'hms_x_axis_solution',
        severity: 'high',
      },
      '0300-1100-0002-0009': {
        title: 'hms_y_axis_error',
        description: 'hms_y_axis_desc',
        solution: 'hms_y_axis_solution',
        severity: 'high',
      },
      '0300-1100-0002-0010': {
        title: 'hms_filament_runout',
        description: 'hms_filament_runout_desc',
        solution: 'hms_filament_runout_solution',
        severity: 'low',
      },
      '0300-1100-0002-0011': {
        title: 'hms_door_open',
        description: 'hms_door_open_desc',
        solution: 'hms_door_open_solution',
        severity: 'low',
      },
    };

    return (
      hmsErrors[errorCode] || {
        title: 'hms_unknown_error',
        description: 'hms_unknown_desc',
        solution: 'hms_unknown_solution',
        severity: 'unknown',
      }
    );
  }

  /**
   * Получение всех активных HMS ошибок
   */
  getActiveHmsErrors() {
    if (!this.printerData.hms || !Array.isArray(this.printerData.hms)) {
      return [];
    }

    return this.printerData.hms.map((error) => ({
      code: error.code,
      info: this.getHmsErrorInfo(error.code),
      timestamp: error.timestamp || new Date().toISOString(),
    }));
  }

  /**
   * Управление LED подсветкой камеры
   */
  async setCameraLed(state) {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    const command = {
      print: {
        led: {
          node: 'chamber_light',
          mode: state ? 'on' : 'off',
        },
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    const message = JSON.stringify(command);

    console.log(`[LED CONTROL] Setting camera LED to ${state ? 'ON' : 'OFF'}`);

    return new Promise((resolve, reject) => {
      this.mqttClient.publish(topic, message, (err) => {
        if (err) {
          console.error('[LED CONTROL] Failed to send LED command:', err);
          reject(err);
        } else {
          console.log('[LED CONTROL] LED command sent successfully');
          resolve(true);
        }
      });
    });
  }

  /**
   * Получение состояния LED подсветки
   */
  getCameraLedState() {
    return this.printerData.print?.led?.chamber_light || 'off';
  }

  /**
   * Управление скоростью печати (1-4)
   */
  async setPrintSpeed(speed) {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    if (speed < 1 || speed > 4) {
      throw new Error('Print speed must be between 1 and 4');
    }

    const speedMap = {
      1: 'silent',
      2: 'normal',
      3: 'sport',
      4: 'ludicrous',
    };

    const command = {
      print: {
        speed: {
          mode: speedMap[speed],
        },
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    const message = JSON.stringify(command);

    console.log(`[SPEED CONTROL] Setting print speed to ${speed} (${speedMap[speed]})`);

    return new Promise((resolve, reject) => {
      this.mqttClient.publish(topic, message, (err) => {
        if (err) {
          console.error('[SPEED CONTROL] Failed to send speed command:', err);
          reject(err);
        } else {
          console.log('[SPEED CONTROL] Speed command sent successfully');
          resolve(true);
        }
      });
    });
  }

  /**
   * Получение текущей скорости печати
   */
  getPrintSpeed() {
    const speedMode = this.printerData.print?.speed?.mode || 'normal';
    const speedMap = {
      silent: 1,
      normal: 2,
      sport: 3,
      ludicrous: 4,
    };
    return speedMap[speedMode] || 2;
  }

  /**
   * Управление температурой сопла
   */
  async setNozzleTemperature(temperature) {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    if (temperature < 0 || temperature > 300) {
      throw new Error('Temperature must be between 0 and 300°C');
    }

    const command = {
      print: {
        nozzle_temper: temperature,
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    const message = JSON.stringify(command);

    console.log(`[TEMP CONTROL] Setting nozzle temperature to ${temperature}°C`);

    return new Promise((resolve, reject) => {
      this.mqttClient.publish(topic, message, (err) => {
        if (err) {
          console.error('[TEMP CONTROL] Failed to send nozzle temp command:', err);
          reject(err);
        } else {
          console.log('[TEMP CONTROL] Nozzle temperature command sent successfully');
          resolve(true);
        }
      });
    });
  }

  /**
   * Управление температурой стола
   */
  async setBedTemperature(temperature) {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    if (temperature < 0 || temperature > 120) {
      throw new Error('Temperature must be between 0 and 120°C');
    }

    const command = {
      print: {
        bed_temper: temperature,
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    const message = JSON.stringify(command);

    console.log(`[TEMP CONTROL] Setting bed temperature to ${temperature}°C`);

    return new Promise((resolve, reject) => {
      this.mqttClient.publish(topic, message, (err) => {
        if (err) {
          console.error('[TEMP CONTROL] Failed to send bed temp command:', err);
          reject(err);
        } else {
          console.log('[TEMP CONTROL] Bed temperature command sent successfully');
          resolve(true);
        }
      });
    });
  }

  /**
   * Управление вентиляторами
   */
  async setFanSpeed(fanType, speed) {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    if (speed < 0 || speed > 100) {
      throw new Error('Fan speed must be between 0 and 100%');
    }

    const fanMap = {
      chamber: 'chamber_fan',
      aux: 'aux_fan',
      cooling: 'cooling_fan',
    };

    const fanNode = fanMap[fanType];
    if (!fanNode) {
      throw new Error('Invalid fan type. Use: chamber, aux, or cooling');
    }

    const command = {
      print: {
        fan: {
          node: fanNode,
          speed: speed,
        },
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    const message = JSON.stringify(command);

    console.log(`[FAN CONTROL] Setting ${fanType} fan speed to ${speed}%`);

    return new Promise((resolve, reject) => {
      this.mqttClient.publish(topic, message, (err) => {
        if (err) {
          console.error('[FAN CONTROL] Failed to send fan command:', err);
          reject(err);
        } else {
          console.log('[FAN CONTROL] Fan command sent successfully');
          resolve(true);
        }
      });
    });
  }

  /**
   * Получение состояния вентиляторов
   */
  getFanStates() {
    return {
      chamber: this.printerData.print?.fan?.chamber_fan || 0,
      aux: this.printerData.print?.fan?.aux_fan || 0,
      cooling: this.printerData.print?.fan?.cooling_fan || 0,
    };
  }

  /**
   * Проверка наличия камеры у принтера
   */
  hasCamera() {
    // Получаем реальную модель принтера из MQTT данных, а не из названия
    const realModel = this.printerData.info?.machine_type || this.printerData.info?.model || '';
    const printerName = this.printer.name || '';

    console.log(
      `[CAMERA CHECK] Real model from MQTT: "${realModel}", Printer name: "${printerName}"`,
    );

    // Если есть реальная модель из MQTT, используем её
    let modelToCheck = realModel;

    // Если реальной модели нет, пытаемся определить по названию принтера
    if (!modelToCheck) {
      const nameLower = printerName.toLowerCase();
      if (nameLower.includes('p1s')) modelToCheck = 'P1S';
      else if (nameLower.includes('h2d')) modelToCheck = 'H2D';
      else if (nameLower.includes('x1') || nameLower.includes('carbon')) modelToCheck = 'X1C';
      else if (nameLower.includes('a1')) modelToCheck = 'A1';
      else modelToCheck = 'UNKNOWN';

      console.log(`[CAMERA CHECK] No MQTT model, guessing from name: "${modelToCheck}"`);
    }

    const modelLower = modelToCheck.toLowerCase();

    // bambu-js поддерживает камеру только для P1S и H2D
    const bambuJsSupportedModels = ['p1s', 'h2d'];

    // Модели без камеры (обычно нет камеры)
    const modelsWithoutCamera = ['a1', 'a1-mini'];

    let hasCamera = false;

    if (modelsWithoutCamera.some((m) => modelLower.includes(m))) {
      console.log(
        `[CAMERA CHECK] Model ${modelToCheck} - camera not typically available (A1 series)`,
      );
      hasCamera = false;
    } else if (bambuJsSupportedModels.some((m) => modelLower.includes(m))) {
      console.log(`[CAMERA CHECK] Model ${modelToCheck} - camera supported by bambu-js`);
      hasCamera = true;
    } else if (modelLower.includes('x1') || modelLower.includes('carbon')) {
      console.log(
        `[CAMERA CHECK] Model ${modelToCheck} - camera not supported by bambu-js (X1 series)`,
      );
      hasCamera = false;
    } else {
      // Неизвестная модель - не показываем камеру
      console.log(`[CAMERA CHECK] Unknown model ${modelToCheck} - camera not supported`);
      hasCamera = false;
    }

    return hasCamera;
  }

  /**
   * Проверка поддержки bambu-js библиотеки для данной модели
   * @returns {boolean} Поддерживается ли модель библиотекой bambu-js
   */
  isBambuJsSupported() {
    const modelToCheck = this.printerData.info?.machine_type || this.printer.name;
    const modelLower = modelToCheck.toLowerCase();

    // bambu-js поддерживает только P1S и H2D
    const bambuJsSupportedModels = ['p1s', 'h2d'];

    return bambuJsSupportedModels.some((m) => modelLower.includes(m));
  }

  /**
   * Получение URL видеопотока камеры
   */
  getCameraStreamUrl() {
    if (!this.hasCamera()) {
      return null;
    }

    // Очищаем IP от порта (если есть)
    const cleanIp = this.printer.ip.split(':')[0];

    // Bambu Lab использует FTP для доступа к снимкам камеры
    // Требуется аутентификация с access code
    // OrcaSlicer использует: ftp://bblp:ACCESS_CODE@IP/ipcam.jpg
    const accessCode = this.printer.accessCode || '';

    if (!accessCode) {
      console.log('[CAMERA URL] No access code - camera requires authentication');
      return null;
    }

    // FTP URL с аутентификацией (как в OrcaSlicer)
    const url = `ftp://bblp:${accessCode}@${cleanIp}/ipcam.jpg`;

    console.log('[CAMERA URL] Generated camera URL (FTP with auth)');
    console.log('[CAMERA URL] Clean IP:', cleanIp);
    console.log('[CAMERA URL] Has access code:', !!accessCode);

    return url;
  }

  /**
   * Закрытие подключения
   */
  async closeConnection() {
    if (this.statusInterval) {
      clearInterval(this.statusInterval);
      this.statusInterval = null;
    }

    if (this.mqttClient) {
      if (this.messageHandler) {
        this.mqttClient.removeListener('message', this.messageHandler);
        this.messageHandler = null;
      }
      this.mqttClient.end();
      this.mqttClient = null;
    }

    this.isConnected = false;
  }

  /**
   * Пауза печати
   */
  async pausePrint() {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    console.log('[BAMBU CONTROL] Sending pause command...');

    // Отправляем команду паузы через MQTT
    const command = {
      print: {
        sequence_id: Date.now(),
        command: 'pause',
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    this.mqttClient.publish(topic, JSON.stringify(command));

    console.log('[BAMBU CONTROL] Pause command sent');
  }

  /**
   * Возобновление печати
   */
  async resumePrint() {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    console.log('[BAMBU CONTROL] Sending resume command...');

    // Отправляем команду возобновления через MQTT
    const command = {
      print: {
        sequence_id: Date.now(),
        command: 'resume',
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    this.mqttClient.publish(topic, JSON.stringify(command));

    console.log('[BAMBU CONTROL] Resume command sent');
  }

  /**
   * Остановка печати
   */
  async stopPrint() {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    console.log('[BAMBU CONTROL] Sending stop command...');

    // Отправляем команду остановки через MQTT
    const command = {
      print: {
        sequence_id: Date.now(),
        command: 'stop',
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    this.mqttClient.publish(topic, JSON.stringify(command));

    console.log('[BAMBU CONTROL] Stop command sent');
  }

  /**
   * Запуск печати существующего файла на принтере
   * @param {string} filename - Имя файла на принтере
   */
  async startPrint(filename) {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    console.log('[BAMBU CONTROL] Starting print of file:', filename);

    // Отправляем команду запуска печати через MQTT
    const command = {
      print: {
        sequence_id: Date.now().toString(),
        command: 'start',
        filename: filename,
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    this.mqttClient.publish(topic, JSON.stringify(command));

    console.log('[BAMBU CONTROL] Print start command sent for file:', filename);
  }

  /**
   * Получение списка файлов на принтере
   * @returns {Promise<Array>} Список файлов
   */
  async getFileList() {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('Printer not connected');
    }

    console.log('[BAMBU CONTROL] Requesting file list...');

    // Запрашиваем список файлов через MQTT
    const command = {
      system: {
        sequence_id: Date.now().toString(),
        command: 'getfilelist',
      },
    };

    const topic = `device/${this.printer.serialNumber}/request`;
    this.mqttClient.publish(topic, JSON.stringify(command));

    console.log('[BAMBU CONTROL] File list request sent');

    // Возвращаем пустой массив, так как ответ придет через MQTT callback
    // В реальной реализации нужно дождаться ответа
    return [];
  }

  /**
   * Загрузка файла через bambu-js FileController
   * @param {File} file - Файл для загрузки
   * @returns {Promise<boolean>} Результат загрузки
   */
  async uploadFile(file) {
    const { ip, accessCode } = this.printer;
    const model = this.printerData.info?.machine_type || 'P1S';

    console.log('[BAMBU UPLOAD] Attempting file upload via bambu-js FileController...');

    try {
      // Импортируем FileController из bambu-js
      const { FileController } = await import('bambu-js');
      console.log('[BAMBU UPLOAD] bambu-js FileController imported successfully');

      // Создаем FileController
      const fileController = FileController.create({
        model: model,
        host: ip,
        accessCode: accessCode,
        options: {
          connectionTimeout: 10000,
          maxFileSize: 100 * 1024 * 1024, // 100MB
        },
      });

      console.log('[BAMBU UPLOAD] FileController created, connecting...');

      // Подключаемся к принтеру
      await fileController.connect();
      console.log('[BAMBU UPLOAD] Connected to printer');

      // Загружаем файл
      console.log('[BAMBU UPLOAD] Uploading file:', file.name, 'Size:', file.size);
      await fileController.uploadFile(file, '/');

      console.log('[BAMBU UPLOAD] ✅ File uploaded successfully via bambu-js');

      // Отключаемся
      await fileController.disconnect();

      return true;
    } catch (error) {
      console.error('[BAMBU UPLOAD] ❌ Error uploading file via bambu-js:', error.message);
      return false;
    }
  }

  /**
   * Запуск печати файла через bambu-js PrinterController
   * @param {string} fileName - Имя файла для печати
   * @returns {Promise<boolean>} Результат запуска печати
   */
  async startPrint(fileName) {
    const { ip, accessCode } = this.printer;
    const model = this.printerData.info?.machine_type || 'P1S';

    console.log('[BAMBU PRINT] Starting print via bambu-js PrinterController...');

    try {
      // Импортируем PrinterController из bambu-js
      const { PrinterController } = await import('bambu-js');
      console.log('[BAMBU PRINT] bambu-js PrinterController imported successfully');

      // Создаем PrinterController
      const printerController = PrinterController.create({
        model: model,
        host: ip,
        accessCode: accessCode,
        options: {
          connectionTimeout: 10000,
        },
      });

      console.log('[BAMBU PRINT] PrinterController created, connecting...');

      // Подключаемся к принтеру
      await printerController.connect();
      console.log('[BAMBU PRINT] Connected to printer');

      // Отправляем команду на запуск печати
      const printCommand = {
        print: {
          file: fileName,
        },
      };

      console.log('[BAMBU PRINT] Sending print command for file:', fileName);
      await printerController.sendCommand(printCommand);

      console.log('[BAMBU PRINT] ✅ Print started successfully via bambu-js');

      // Отключаемся
      await printerController.disconnect();

      return true;
    } catch (error) {
      console.error('[BAMBU PRINT] ❌ Error starting print via bambu-js:', error.message);
      return false;
    }
  }

  /**
   * Попытка загрузки файла через FTP (экспериментальная функция)
   * @param {File} file - Файл для загрузки
   * @returns {Promise<boolean>} Результат загрузки
   */
  async uploadFileViaFTP(file) {
    const { ip, accessCode } = this.printer;

    console.log('[BAMBU FTP] Attempting file upload via FTP...');

    // Bambu Lab может использовать FTP для файлов
    // Это требует дополнительной библиотеки для FTP клиента
    // Пока возвращаем false, так как FTP клиент не реализован

    console.log('[BAMBU FTP] FTP upload not implemented - requires FTP client library');
    console.log('[BAMBU FTP] Potential FTP URL: ftp://bblp:' + accessCode + '@' + ip + '/');

    return false;
  }
}

// Экспорт для использования в других модулях
export default BambuLabAdapter;
