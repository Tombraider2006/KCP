/**
 * Менеджер массовой отправки файлов на печать
 * Поддерживает Klipper и Bambu Lab принтеры
 */

// Глобальные переменные для массовой печати
let massPrintSelectedFile = null;
let massPrintSelectedPrinters = new Set();
let massPrintInProgress = false;

/**
 * Открывает модальное окно массовой печати
 */
async function openMassPrintModal() {
  const modal = document.getElementById('massPrintModal');
  if (!modal) return;

  // Применяем переводы
  applyMassPrintTranslations();

  // Сбрасываем состояние
  resetMassPrintState();

  // Загружаем список принтеров
  await loadMassPrintPrinters();

  modal.style.display = 'block';
  console.log('[Mass Print] Modal opened');
}

/**
 * Закрывает модальное окно массовой печати
 */
function closeMassPrintModal() {
  const modal = document.getElementById('massPrintModal');
  if (!modal) return;

  if (massPrintInProgress) {
    if (!confirm(t('mass_print_cancel_btn') + '? Отправка будет прервана.')) {
      return;
    }
    massPrintInProgress = false;
  }

  resetMassPrintState();
  modal.style.display = 'none';
  console.log('[Mass Print] Modal closed');
}

/**
 * Применяет переводы к элементам модального окна массовой печати
 */
function applyMassPrintTranslations() {
  if (typeof t !== 'function') return;

  // Update all elements with data-i18n attributes in mass print modal
  const massPrintElements = document.querySelectorAll('#massPrintModal [data-i18n]');
  massPrintElements.forEach((element) => {
    const key = element.getAttribute('data-i18n');
    if (key) {
      const translation = t(key);
      if (translation && translation !== key) {
        element.textContent = translation;
      }
    }
  });
}

/**
 * Сбрасывает состояние массовой печати
 */
function resetMassPrintState() {
  massPrintSelectedFile = null;
  massPrintSelectedPrinters.clear();
  massPrintInProgress = false;

  // Сбрасываем UI
  document.getElementById('massPrintFileInput').value = '';
  document.getElementById('massPrintFileInfo').style.display = 'none';
  document.getElementById('massPrintProgress').style.display = 'none';
  document.getElementById('massPrintSendBtn').disabled = true;

  // Скрываем информационные блоки
  const bambuLabInfo = document.getElementById('bambuLabInfo');
  const klipperInfo = document.getElementById('klipperInfo');
  if (bambuLabInfo) bambuLabInfo.style.display = 'none';
  if (klipperInfo) klipperInfo.style.display = 'none';

  updateMassPrintSelectedCount();
}

/**
 * Загружает список принтеров для массовой печати
 */
async function loadMassPrintPrinters() {
  const printerList = document.getElementById('massPrintPrinterList');
  const noPrinters = document.getElementById('massPrintNoPrinters');

  console.log('[Mass Print] DOM elements:', { printerList, noPrinters });

  if (!printerList || !noPrinters) {
    console.error('[Mass Print] Required DOM elements not found');
    return;
  }

  // Получаем список принтеров из глобального массива
  // Используем window.printers если доступен, иначе пробуем получить из renderer.js
  let printers = window.printers || [];

  // Если window.printers пустой, но принтеры есть в системе, получаем их напрямую
  if (printers.length === 0) {
    // Пробуем получить принтеры через глобальную функцию из renderer.js
    if (typeof window.getPrinters === 'function') {
      try {
        const globalPrinters = window.getPrinters();
        if (globalPrinters && globalPrinters.length > 0) {
          printers = globalPrinters;
          console.log('[Mass Print] Loaded printers from global function:', printers.length);
        }
      } catch (error) {
        console.error('[Mass Print] Error loading printers from global function:', error);
      }
    }

    // Если все еще пустой, пробуем через IPC
    if (printers.length === 0 && window.electronAPI) {
      try {
        // Пробуем получить принтеры через IPC
        const storedPrinters = await window.electronAPI.storeGet('printers', []);
        if (storedPrinters && storedPrinters.length > 0) {
          printers = storedPrinters;
          console.log('[Mass Print] Loaded printers from storage:', printers.length);
        }
      } catch (error) {
        console.error('[Mass Print] Error loading printers from storage:', error);
      }
    }
  }

  console.log('[Mass Print] Available printers:', printers.length, printers);

  // Фильтруем принтеры - показываем только готовые к печати (ready или complete)
  const availablePrinters = printers.filter((printer) => {
    return printer.status === 'ready' || printer.status === 'complete';
  });

  console.log(
    '[Mass Print] Available printers for printing:',
    availablePrinters.length,
    availablePrinters,
  );

  if (availablePrinters.length === 0) {
    noPrinters.style.display = 'block';
    printerList.innerHTML = '';
    printerList.appendChild(noPrinters);
    return;
  }

  noPrinters.style.display = 'none';

  // Создаем элементы для каждого принтера
  const printerElements = availablePrinters
    .map((printer) => {
      const statusClass = getPrinterStatusClass(printer.status);
      const statusText = getPrinterStatusText(printer.status);
      const isReady = true; // Все принтеры в списке уже готовы к печати (отфильтрованы)

      return `
            <div class="mass-print-printer-item" style="display: flex; align-items: center; padding: 10px; margin-bottom: 8px; background: rgba(255,255,255,0.05); border-radius: 6px; border: 1px solid rgba(255,255,255,0.1);">
                <input 
                    type="checkbox" 
                    id="massPrint_${printer.id}" 
                    class="mass-print-printer-checkbox" 
                    ${!isReady ? 'disabled' : ''}
                    onchange="handleMassPrintPrinterSelect('${printer.id}', this.checked)"
                    style="margin-right: 12px; transform: scale(1.2);"
                >
                <div style="flex: 1;">
                    <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                        <span class="printer-status-indicator ${statusClass}" style="width: 12px; height: 12px; border-radius: 50%; display: inline-block;"></span>
                        <strong style="color: white;">${printer.name}</strong>
                        <span style="color: #888; font-size: 12px;">(${printer.type.toUpperCase()})</span>
                    </div>
                    <div style="color: #888; font-size: 12px;">
                        ${printer.ip}:${printer.port || (printer.type === 'klipper' ? '7125' : '8883')} • ${statusText}
                        ${!isReady ? '<span style="color: #ff5722; margin-left: 8px;">⚠️ Не готов</span>' : ''}
                    </div>
                </div>
            </div>
        `;
    })
    .join('');

  console.log('[Mass Print] Generated HTML:', printerElements);
  printerList.innerHTML = printerElements;

  // Показываем информационные блоки в зависимости от типов принтеров
  updatePrinterTypeInfo(availablePrinters);
}

/**
 * Обновляет информационные блоки в зависимости от типов принтеров
 */
function updatePrinterTypeInfo(printers) {
  const bambuLabInfo = document.getElementById('bambuLabInfo');
  const klipperInfo = document.getElementById('klipperInfo');

  if (!bambuLabInfo || !klipperInfo) return;

  // Определяем типы принтеров
  const hasBambuPrinters = printers.some((p) => p.type === 'bambu');
  const hasKlipperPrinters = printers.some((p) => p.type === 'klipper');

  // Показываем/скрываем информационные блоки
  bambuLabInfo.style.display = hasBambuPrinters ? 'block' : 'none';
  klipperInfo.style.display = hasKlipperPrinters ? 'block' : 'none';

  console.log('[Mass Print] Printer type info updated:', {
    hasBambuPrinters,
    hasKlipperPrinters,
  });
}

/**
 * Получает CSS класс для статуса принтера
 */
function getPrinterStatusClass(status) {
  const statusClasses = {
    ready: 'status-ready',
    printing: 'status-printing',
    paused: 'status-paused',
    complete: 'status-complete',
    error: 'status-error',
    offline: 'status-offline',
  };
  return statusClasses[status] || 'status-unknown';
}

/**
 * Получает текст статуса принтера
 */
function getPrinterStatusText(status) {
  const statusTexts = {
    ready: t('mass_print_ready'),
    printing: t('mass_print_printing'),
    paused: t('mass_print_printing'),
    complete: t('mass_print_ready'),
    error: t('mass_print_error'),
    offline: t('mass_print_offline'),
  };
  return statusTexts[status] || status;
}

/**
 * Обрабатывает выбор принтера для массовой печати
 */
function handleMassPrintPrinterSelect(printerId, selected) {
  if (selected) {
    massPrintSelectedPrinters.add(printerId);
  } else {
    massPrintSelectedPrinters.delete(printerId);
  }

  updateMassPrintSelectedCount();
  updateMassPrintSendButton();
}

/**
 * Обновляет счетчик выбранных принтеров
 */
function updateMassPrintSelectedCount() {
  const countElement = document.getElementById('massPrintSelectedCount');
  if (countElement) {
    countElement.textContent = massPrintSelectedPrinters.size;
  }
}

/**
 * Обновляет состояние кнопки отправки
 */
function updateMassPrintSendButton() {
  const sendBtn = document.getElementById('massPrintSendBtn');
  if (sendBtn) {
    const canSend =
      massPrintSelectedFile && massPrintSelectedPrinters.size > 0 && !massPrintInProgress;
    sendBtn.disabled = !canSend;
  }
}

/**
 * Обрабатывает выбор файла для массовой печати
 */
function handleMassPrintFileSelect(event) {
  const file = event.target.files[0];

  if (!file) {
    massPrintSelectedFile = null;
    document.getElementById('massPrintFileInfo').style.display = 'none';
    updateMassPrintSendButton();
    return;
  }

  // Проверяем тип файла
  const allowedExtensions = ['.gcode'];
  const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));

  if (!allowedExtensions.includes(fileExtension)) {
    addConsoleMessage('Неподдерживаемый формат файла. Разрешен только: .gcode', 'error');
    event.target.value = '';
    return;
  }

  massPrintSelectedFile = file;

  // Показываем информацию о файле
  document.getElementById('massPrintFileName').textContent = file.name;
  document.getElementById('massPrintFileSize').textContent = formatFileSize(file.size);
  document.getElementById('massPrintFileInfo').style.display = 'block';

  updateMassPrintSendButton();
}

/**
 * Форматирует размер файла
 */
function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Начинает массовую отправку файлов
 */
async function startMassPrint() {
  if (!massPrintSelectedFile || massPrintSelectedPrinters.size === 0 || massPrintInProgress) {
    return;
  }

  massPrintInProgress = true;

  // Показываем прогресс
  document.getElementById('massPrintProgress').style.display = 'block';
  document.getElementById('massPrintSendBtn').disabled = true;

  const progressList = document.getElementById('massPrintProgressList');
  progressList.innerHTML = '';

  // Получаем список принтеров
  const printers = window.printers || [];
  const selectedPrinters = printers.filter((p) => massPrintSelectedPrinters.has(p.id));

  let successCount = 0;
  let errorCount = 0;

  // Отправляем файл на каждый выбранный принтер
  for (const printer of selectedPrinters) {
    const progressItem = createProgressItem(printer);
    progressList.appendChild(progressItem);

    try {
      updateProgressItem(progressItem, 'uploading', 'Загрузка файла...');

      // Отправляем файл в зависимости от типа принтера
      if (printer.type === 'klipper') {
        await uploadFileToKlipper(printer, massPrintSelectedFile);
      } else if (printer.type === 'bambu') {
        await uploadFileToBambu(printer, massPrintSelectedFile);
      } else {
        throw new Error('Неподдерживаемый тип принтера: ' + printer.type);
      }

      updateProgressItem(progressItem, 'success', 'Файл отправлен успешно');
      successCount++;
    } catch (error) {
      console.error(`[Mass Print] Error sending to ${printer.name}:`, error);
      updateProgressItem(progressItem, 'error', 'Ошибка: ' + error.message);
      errorCount++;
    }
  }

  // Показываем результат
  setTimeout(() => {
    if (errorCount === 0) {
      addConsoleMessage(t('mass_print_success'), 'success');
    } else {
      addConsoleMessage(
        `${t('mass_print_success')} ${successCount} из ${selectedPrinters.length}. Ошибок: ${errorCount}`,
        'warning',
      );
    }

    massPrintInProgress = false;
    document.getElementById('massPrintSendBtn').disabled = false;
  }, 1000);
}

/**
 * Создает элемент прогресса для принтера
 */
function createProgressItem(printer) {
  const item = document.createElement('div');
  item.className = 'mass-print-progress-item';
  item.style.cssText = `
        display: flex; 
        align-items: center; 
        padding: 8px; 
        margin-bottom: 6px; 
        background: rgba(255,255,255,0.05); 
        border-radius: 4px;
    `;

  item.innerHTML = `
        <div style="margin-right: 12px;">
            <div class="progress-status-indicator" style="width: 16px; height: 16px; border-radius: 50%; background: #666;"></div>
        </div>
        <div style="flex: 1;">
            <strong style="color: white;">${printer.name}</strong>
            <div class="progress-status-text" style="color: #888; font-size: 12px;">Ожидание...</div>
        </div>
    `;

  return item;
}

/**
 * Обновляет элемент прогресса
 */
function updateProgressItem(item, status, text) {
  const indicator = item.querySelector('.progress-status-indicator');
  const textElement = item.querySelector('.progress-status-text');

  if (textElement) {
    textElement.textContent = text;
  }

  if (indicator) {
    const statusColors = {
      waiting: '#666',
      uploading: '#ffc107',
      success: '#4caf50',
      error: '#f44336',
    };

    indicator.style.background = statusColors[status] || '#666';
  }
}

/**
 * Загружает файл на Klipper принтер через Moonraker API
 */
async function uploadFileToKlipper(printer, file) {
  const { ip, port = 7125 } = printer;
  const url = `http://${ip}:${port}/server/files/upload`;

  const formData = new FormData();
  formData.append('file', file);

  const response = await fetch(url, {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }

  const result = await response.json();

  if (result.error) {
    throw new Error(result.error.message || 'Ошибка загрузки файла');
  }

  // Запускаем печать
  const printUrl = `http://${ip}:${port}/printer/print/start`;
  const printResponse = await fetch(printUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      filename: file.name,
    }),
  });

  if (!printResponse.ok) {
    throw new Error(`Ошибка запуска печати: HTTP ${printResponse.status}`);
  }

  const printResult = await printResponse.json();

  if (printResult.error) {
    throw new Error(printResult.error.message || 'Ошибка запуска печати');
  }
}

/**
 * Отправляет файл на Bambu Lab принтер (экспериментальная функция)
 */
async function uploadFileToBambu(printer, file) {
  console.log('[Mass Print] Attempting Bambu Lab file upload for:', printer.name);

  // Получаем адаптер принтера
  const adapter = await window.electronAPI.getPrinterAdapter(printer.id);
  if (!adapter) {
    throw new Error('Адаптер принтера не найден');
  }

  // Проверяем, что принтер подключен
  if (!adapter.isConnected) {
    throw new Error('Принтер не подключен');
  }

  console.log('[Mass Print] Bambu Lab adapter found, attempting file upload...');

  // Проверяем поддержку bambu-js для P1S
  if (adapter.isBambuJsSupported && adapter.isBambuJsSupported()) {
    console.log('[Mass Print] Using bambu-js for P1S file upload...');
    try {
      // Используем новую функцию загрузки через bambu-js
      const uploadSuccess = await adapter.uploadFile(file);

      if (uploadSuccess) {
        console.log('[Mass Print] ✅ bambu-js upload successful');

        // Запускаем печать через bambu-js
        await adapter.startPrint(file.name);
        console.log('[Mass Print] ✅ Print started for file:', file.name);
        return;
      }
    } catch (error) {
      console.log('[Mass Print] ❌ bambu-js upload failed:', error.message);
    }
  }

  // Попытка 1: HTTP API загрузка (для старых версий)
  try {
    console.log('[Mass Print] Trying HTTP API upload...');
    const httpUploadSuccess = await adapter.uploadFile(file);

    if (httpUploadSuccess) {
      console.log('[Mass Print] ✅ HTTP upload successful');

      // Запускаем печать загруженного файла
      await adapter.startPrint(file.name);
      console.log('[Mass Print] ✅ Print started for file:', file.name);
      return;
    }
  } catch (error) {
    console.log('[Mass Print] ❌ HTTP upload failed:', error.message);
  }

  // Попытка 2: FTP загрузка (для старых версий)
  try {
    console.log('[Mass Print] Trying FTP upload...');
    const ftpUploadSuccess = await adapter.uploadFileViaFTP(file);

    if (ftpUploadSuccess) {
      console.log('[Mass Print] ✅ FTP upload successful');

      // Запускаем печать загруженного файла
      await adapter.startPrint(file.name);
      console.log('[Mass Print] ✅ Print started for file:', file.name);
      return;
    }
  } catch (error) {
    console.log('[Mass Print] ❌ FTP upload failed:', error.message);
  }

  // Если все попытки загрузки не удались, показываем информативное сообщение
  const errorMessage = `
Для Bambu Lab принтеров автоматическая загрузка файлов поддерживается только для P1S и H2D.

Доступные варианты:
1. Загрузите файл через Bambu Studio
2. Используйте Bambu Handy приложение
3. Загрузите файл на SD карту принтера

Файл: ${file.name}
Принтер: ${printer.name}
Модель: ${adapter.isBambuJsSupported ? 'Поддерживается bambu-js' : 'Не поддерживается bambu-js'}

После загрузки файла через официальные средства, 
вы сможете запустить печать через нашу программу.
    `.trim();

  throw new Error(errorMessage);
}

/**
 * Запускает печать уже загруженного файла на Bambu Lab принтере
 * @param {Object} printer - Принтер Bambu Lab
 * @param {string} filename - Имя файла на принтере
 */
async function startBambuPrint(printer, filename) {
  console.log('[Bambu Print] Starting print:', filename, 'on', printer.name);

  try {
    // Получаем адаптер принтера
    const adapter = await window.electronAPI.getPrinterAdapter(printer.id);
    if (!adapter) {
      throw new Error('Адаптер принтера не найден');
    }

    // Проверяем, что принтер подключен
    if (!adapter.isConnected) {
      throw new Error('Принтер не подключен');
    }

    // Запускаем печать файла
    await adapter.startPrint(filename);
    console.log('[Bambu Print] ✅ Print started successfully');

    return true;
  } catch (error) {
    console.error('[Bambu Print] ❌ Error starting print:', error);
    throw error;
  }
}

/**
 * Получает список файлов на Bambu Lab принтере
 * @param {Object} printer - Принтер Bambu Lab
 * @returns {Promise<Array>} Список файлов
 */
async function getBambuFileList(printer) {
  console.log('[Bambu Files] Getting file list for:', printer.name);

  try {
    // Получаем адаптер принтера
    const adapter = await window.electronAPI.getPrinterAdapter(printer.id);
    if (!adapter) {
      throw new Error('Адаптер принтера не найден');
    }

    // Проверяем, что принтер подключен
    if (!adapter.isConnected) {
      throw new Error('Принтер не подключен');
    }

    // Запрашиваем список файлов
    const fileList = await adapter.getFileList();
    console.log('[Bambu Files] ✅ File list retrieved:', fileList);

    return fileList;
  } catch (error) {
    console.error('[Bambu Files] ❌ Error getting file list:', error);
    throw error;
  }
}

// Делаем функции доступными глобально
window.openMassPrintModal = openMassPrintModal;
window.closeMassPrintModal = closeMassPrintModal;
window.handleMassPrintFileSelect = handleMassPrintFileSelect;
window.handleMassPrintPrinterSelect = handleMassPrintPrinterSelect;
window.startMassPrint = startMassPrint;
window.startBambuPrint = startBambuPrint;
window.getBambuFileList = getBambuFileList;
