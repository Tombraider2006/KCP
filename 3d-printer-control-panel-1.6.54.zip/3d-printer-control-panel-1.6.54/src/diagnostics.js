import os from 'os';
import crypto from 'crypto';
import { app } from 'electron';
import fs from 'fs';
import path from 'path';
import https from 'https';
import http from 'http';

class DiagnosticsReporter {
  // Ключ шифрования AES-256 (в production должен быть в безопасном месте)
  static ENCRYPTION_KEY = Buffer.from('3DPC-T3l3m3try-K3y-2025-S3cur3-V1.5.36', 'utf-8').subarray(
    0,
    32,
  );
  static ENCRYPTION_IV_SALT = '3DPC-IV-Salt';

  constructor() {
    const b64 = Buffer.from('aHR0cDovL3RvbWljaC5mdW46MzAwMC9hcGkv', 'base64').toString();

    this.config = {
      active: true,
      endpoint: b64 + 'telemetry',
      interval: 24 * 60 * 60 * 1000,
      timeout: 10000,
    };

    this.uid = this.getUid();
    this.data = this.loadData();

    // Инициализируем миграцию данных ПОСЛЕ загрузки
    this.initializeData();

    this.timer = null;
    this.sessionStartTime = Date.now(); // Время старта текущей сессии
  }

  async initialize() {
    if (!this.config.active) return;

    setTimeout(() => this.sync(true), 2 * 60 * 1000); // Первая синхронизация через 2 минуты
    this.startSync();
  }

  getUid() {
    const store = this.getStore();

    if (store.uid) return store.uid;

    const interfaces = os.networkInterfaces();
    let mac = '';

    for (const name of Object.keys(interfaces)) {
      for (const iface of interfaces[name]) {
        if (iface.mac && iface.mac !== '00:00:00:00:00:00') {
          mac = iface.mac;
          break;
        }
      }
      if (mac) break;
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const uid = crypto
      .createHash('sha256')
      .update(mac + salt + Date.now())
      .digest('hex')
      .substring(0, 32);

    store.uid = uid;
    this.saveStore(store);

    return uid;
  }

  getStore() {
    try {
      const p = path.join(app.getPath('userData'), '.cache');
      if (fs.existsSync(p)) {
        return JSON.parse(fs.readFileSync(p, 'utf8'));
      }
    } catch (e) {}

    return { uid: null, lastSync: null, installed: Date.now() };
  }

  saveStore(data) {
    try {
      const p = path.join(app.getPath('userData'), '.cache');
      fs.writeFileSync(p, JSON.stringify(data, null, 2));
    } catch (e) {}
  }

  loadData() {
    const store = this.getStore();
    return (
      store.data || {
        sessions: 0,
        totalUptime: 0, // Общее время работы в секундах
        printersAdded: 0,
        printersKlipper: 0,
        printersBambu: 0,
        currentPrinters: 0,
        analyticsViews: 0,
        exports: 0,
        features: {},
        lastSession: null,

        // === НОВЫЕ МЕТРИКИ v1.5.36 ===

        // Умные розетки
        smartPlugs: {
          tuyaConfigured: false,
          homeAssistantConfigured: false,
          totalPlugsLinked: 0, // Сколько розеток привязано к принтерам
          tuyaPlugsCount: 0,
          haPlugsCount: 0,
          automationsEnabled: 0, // Сколько принтеров с включенной автоматизацией
          autoShutdownUsed: 0, // Использование автоотключения после печати
          overheatingProtectionUsed: 0, // Использование защиты от перегрева
        },

        // Пакетное добавление принтеров
        batchOperations: {
          batchAddsCount: 0, // Сколько раз использовали пакетное добавление
          totalPrintersBatchAdded: 0, // Сколько принтеров добавлено пакетно
          avgPrintersPerBatch: 0, // Среднее количество принтеров за раз
          networkScansCount: 0, // Сколько раз запускали сканирование сети
        },

        // Температурные данные
        temperatures: {
          maxNozzleTemp: 0, // Максимальная температура сопла
          maxBedTemp: 0, // Максимальная температура стола
          maxMCUTemp: 0, // Максимальная температура MCU
          overheatingEvents: 0, // Сколько раз была превышена критическая температура
        },

        // Ошибки и события
        events: {
          printErrors: 0, // Ошибки печати
          emergencyShutdowns: 0, // Аварийные отключения
          successfulPrints: 0, // Успешные завершения печати
          manualPlugToggles: 0, // Ручное переключение розеток
        },

        // Использование модулей
        modules: {
          webServerUsageCount: 0, // Сколько раз запускали web-сервер
          webServerTotalUptime: 0, // Общее время работы web-сервера (сек)
          analyticsOpenCount: 0, // Сколько раз открывали аналитику
          lastWebServerPort: 0, // Последний использованный порт
          helpPagesOpened: 0, // Сколько раз открывали страницы помощи
        },
      }
    );
  }

  saveData() {
    const store = this.getStore();
    store.data = this.data;
    this.saveStore(store);
  }

  trackSession() {
    this.data.sessions++;
    this.data.lastSession = Date.now();
    this.saveData();
  }

  updatePrintersCount(printers) {
    if (!Array.isArray(printers)) return;

    const oldCount = this.data.currentPrinters || 0;

    this.data.currentPrinters = printers.length;
    this.data.printersKlipper = printers.filter((p) => p.type === 'klipper' || !p.type).length;
    this.data.printersBambu = printers.filter((p) => p.type === 'bambu').length;

    if (this.data.currentPrinters > (this.data.maxPrinters || 0)) {
      this.data.maxPrinters = this.data.currentPrinters;
    }

    this.saveData();

    // Если количество принтеров изменилось - синхронизируем с сервером
    if (oldCount !== this.data.currentPrinters && this.data.currentPrinters > 0) {
      // Синхронизация через 10 секунд (даем время для стабилизации)
      setTimeout(() => this.sync(true), 10000); // force = true
    }
  }

  trackPrinterAdded(type) {
    this.data.printersAdded++;
    if (type === 'klipper') this.data.printersKlipper++;
    else if (type === 'bambu') this.data.printersBambu++;
    this.saveData();
  }

  trackFeatureUsage(name) {
    if (!this.data.features[name]) this.data.features[name] = 0;
    this.data.features[name]++;
    this.saveData();
  }

  trackAnalyticsView() {
    this.data.analyticsViews++;
    this.saveData();
  }

  trackExport(format) {
    this.data.exports++;
    const key = `export_${format}`;
    this.trackFeatureUsage(key);
  }

  /**
   * Инициализация/миграция структуры данных
   * Гарантирует наличие всех полей для новых метрик
   */
  initializeData() {
    // Защита: если this.data не инициализирован, создаём базовый объект
    if (!this.data) {
      console.log('[Diagnostics] Creating new data structure from scratch');
      this.data = {
        sessions: 0,
        totalUptime: 0,
        printersAdded: 0,
        printersKlipper: 0,
        printersBambu: 0,
        currentPrinters: 0,
        analyticsViews: 0,
        exports: 0,
        features: {},
        lastSession: null,
      };
    }

    // Проверяем и создаём отсутствующие поля v1.5.36
    if (!this.data.smartPlugs) {
      console.log('[Diagnostics] Initializing smartPlugs data structure');
      this.data.smartPlugs = {
        tuyaConfigured: false,
        homeAssistantConfigured: false,
        totalPlugsLinked: 0,
        tuyaPlugsCount: 0,
        haPlugsCount: 0,
        automationsEnabled: 0,
        autoShutdownUsed: 0,
        overheatingProtectionUsed: 0,
      };
    }

    if (!this.data.batchOperations) {
      this.data.batchOperations = {
        batchAddsCount: 0,
        networkScansCount: 0,
        avgPrintersPerBatch: 0,
      };
    }

    if (!this.data.temperatures) {
      this.data.temperatures = {
        maxNozzleTemp: 0,
        maxBedTemp: 0,
        maxMCUTemp: 0,
        overheatingEvents: 0,
      };
    }

    if (!this.data.events) {
      this.data.events = {
        printErrors: 0,
        emergencyShutdowns: 0,
        successfulPrints: 0,
        manualPlugToggles: 0,
      };
    }

    if (!this.data.modules) {
      this.data.modules = {
        webServerUsageCount: 0,
        webServerTotalUptime: 0,
        analyticsOpenCount: 0,
        helpPagesOpened: 0,
      };
    }

    // Сохраняем обновлённую структуру
    this.saveData();
  }

  // ====================================================================
  // НОВЫЕ МЕТОДЫ ОТСЛЕЖИВАНИЯ v1.5.36
  // ====================================================================

  /**
   * Отслеживание конфигурации умных розеток
   */
  trackSmartPlugConfig(type, configured) {
    if (!this.data.smartPlugs) this.data.smartPlugs = {};

    if (type === 'tuya') {
      this.data.smartPlugs.tuyaConfigured = configured;
    } else if (type === 'homeassistant') {
      this.data.smartPlugs.homeAssistantConfigured = configured;
    }

    this.saveData();
  }

  /**
   * Обновление статистики привязанных розеток
   */
  updateSmartPlugsStats(printers) {
    if (!Array.isArray(printers) || !this.data.smartPlugs) {
      return;
    }

    let tuyaCount = 0;
    let haCount = 0;
    let automationsCount = 0;
    let autoShutdownCount = 0;
    let overheatingProtectionCount = 0;

    printers.forEach((printer) => {
      // Проверяем реальную структуру данных розеток
      if (printer.tuyaDeviceId) {
        tuyaCount++;
      } else if (printer.haEntityId) {
        haCount++;

        // Проверяем настройки автоматизации Home Assistant
        if (
          printer.autoShutdownEnabled ||
          printer.autoShutdownError ||
          printer.autoShutdownOverheat
        ) {
          automationsCount++;
        }
        if (printer.autoShutdownEnabled) autoShutdownCount++;
        if (printer.autoShutdownOverheat) overheatingProtectionCount++;
      }
    });

    this.data.smartPlugs.totalPlugsLinked = tuyaCount + haCount;
    this.data.smartPlugs.tuyaPlugsCount = tuyaCount;
    this.data.smartPlugs.haPlugsCount = haCount;
    this.data.smartPlugs.automationsEnabled = automationsCount;
    this.data.smartPlugs.autoShutdownUsed = autoShutdownCount;
    this.data.smartPlugs.overheatingProtectionUsed = overheatingProtectionCount;

    this.saveData();
  }

  /**
   * Отслеживание пакетного добавления принтеров
   */
  trackBatchAdd(printersCount) {
    if (!this.data.batchOperations) this.data.batchOperations = {};

    this.data.batchOperations.batchAddsCount = (this.data.batchOperations.batchAddsCount || 0) + 1;
    this.data.batchOperations.totalPrintersBatchAdded =
      (this.data.batchOperations.totalPrintersBatchAdded || 0) + printersCount;

    // Вычисляем среднее
    this.data.batchOperations.avgPrintersPerBatch = Math.round(
      this.data.batchOperations.totalPrintersBatchAdded / this.data.batchOperations.batchAddsCount,
    );

    this.saveData();
  }

  /**
   * Отслеживание сканирования сети
   */
  trackNetworkScan() {
    if (!this.data.batchOperations) this.data.batchOperations = {};

    this.data.batchOperations.networkScansCount =
      (this.data.batchOperations.networkScansCount || 0) + 1;
    this.saveData();
  }

  /**
   * Обновление температурных данных
   */
  updateTemperatures(printerData) {
    if (!this.data.temperatures) this.data.temperatures = {};

    // Обновляем максимальные температуры с валидацией
    if (printerData.temps) {
      // Валидация температуры сопла: 20-460°C (реальные значения для 3D принтеров)
      if (printerData.temps.nozzle > 20 && printerData.temps.nozzle <= 460) {
        if (printerData.temps.nozzle > (this.data.temperatures.maxNozzleTemp || 0)) {
          this.data.temperatures.maxNozzleTemp = Math.round(printerData.temps.nozzle);
        }
      }

      // Валидация температуры стола: 20-200°C (реальные значения)
      if (printerData.temps.bed > 20 && printerData.temps.bed <= 200) {
        if (printerData.temps.bed > (this.data.temperatures.maxBedTemp || 0)) {
          this.data.temperatures.maxBedTemp = Math.round(printerData.temps.bed);
        }
      }
    }

    // Для Klipper - температура MCU (валидация: 0-300°C)
    if (printerData.mcu_temp > 0 && printerData.mcu_temp <= 300) {
      if (printerData.mcu_temp > (this.data.temperatures.maxMCUTemp || 0)) {
        this.data.temperatures.maxMCUTemp = Math.round(printerData.mcu_temp);
      }
    }

    // Критическая температура MCU > 70
    if (printerData.mcu_temp && printerData.mcu_temp > 70) {
      this.data.temperatures.overheatingEvents =
        (this.data.temperatures.overheatingEvents || 0) + 1;
    }

    this.saveData();
  }

  /**
   * Отслеживание событий печати
   */
  trackPrintEvent(eventType) {
    if (!this.data.events) this.data.events = {};

    switch (eventType) {
      case 'error':
        this.data.events.printErrors = (this.data.events.printErrors || 0) + 1;
        break;
      case 'emergency_shutdown':
        this.data.events.emergencyShutdowns = (this.data.events.emergencyShutdowns || 0) + 1;
        break;
      case 'success':
        this.data.events.successfulPrints = (this.data.events.successfulPrints || 0) + 1;
        break;
    }

    this.saveData();
  }

  /**
   * Отслеживание ручного переключения розетки
   */
  trackManualPlugToggle() {
    if (!this.data.events) this.data.events = {};

    this.data.events.manualPlugToggles = (this.data.events.manualPlugToggles || 0) + 1;
    this.saveData();
  }

  /**
   * Отслеживание использования web-сервера
   */
  trackWebServerStart(port) {
    if (!this.data.modules) this.data.modules = {};

    this.data.modules.webServerUsageCount = (this.data.modules.webServerUsageCount || 0) + 1;
    this.data.modules.lastWebServerPort = port;
    this.data.modules.webServerStartTime = Date.now();

    this.saveData();
  }

  /**
   * Обновление времени работы web-сервера
   */
  updateWebServerUptime() {
    if (!this.data.modules || !this.data.modules.webServerStartTime) return;

    const uptime = Math.floor((Date.now() - this.data.modules.webServerStartTime) / 1000);
    this.data.modules.webServerTotalUptime = (this.data.modules.webServerTotalUptime || 0) + uptime;

    // Сбрасываем таймер
    this.data.modules.webServerStartTime = Date.now();
    this.saveData();
  }

  /**
   * Отслеживание открытия аналитики
   */
  trackAnalyticsOpen() {
    if (!this.data.modules) this.data.modules = {};

    this.data.modules.analyticsOpenCount = (this.data.modules.analyticsOpenCount || 0) + 1;
    this.saveData();
  }

  /**
   * Отслеживание открытия страниц помощи
   */
  trackHelpPageOpen() {
    if (!this.data.modules) this.data.modules = {};

    this.data.modules.helpPagesOpened = (this.data.modules.helpPagesOpened || 0) + 1;
    this.saveData();
  }

  // ====================================================================
  // ШИФРОВАНИЕ ДАННЫХ
  // ====================================================================

  /**
   * Шифрует данные с использованием AES-256-CBC
   */
  encryptData(data) {
    try {
      const jsonData = JSON.stringify(data);

      // Генерируем IV на основе timestamp для уникальности
      const timestamp = Date.now().toString();
      const iv = crypto
        .createHash('md5')
        .update(DiagnosticsReporter.ENCRYPTION_IV_SALT + timestamp)
        .digest()
        .subarray(0, 16);

      // Шифруем
      const cipher = crypto.createCipheriv('aes-256-cbc', DiagnosticsReporter.ENCRYPTION_KEY, iv);
      let encrypted = cipher.update(jsonData, 'utf8', 'hex');
      encrypted += cipher.final('hex');

      // Возвращаем зашифрованные данные + IV для расшифровки на сервере
      return {
        encrypted: encrypted,
        iv: iv.toString('hex'),
        timestamp: timestamp,
        version: '1.0',
      };
    } catch (error) {
      console.error('[Telemetry] Encryption error:', error);
      return null;
    }
  }

  /**
   * Дешифрует данные (для проверки на клиенте, опционально)
   */
  decryptData(encryptedPacket) {
    try {
      const iv = Buffer.from(encryptedPacket.iv, 'hex');
      const decipher = crypto.createDecipheriv(
        'aes-256-cbc',
        DiagnosticsReporter.ENCRYPTION_KEY,
        iv,
      );

      let decrypted = decipher.update(encryptedPacket.encrypted, 'hex', 'utf8');
      decrypted += decipher.final('utf8');

      return JSON.parse(decrypted);
    } catch (error) {
      console.error('[Telemetry] Decryption error:', error);
      return null;
    }
  }

  collectData() {
    const store = this.getStore();

    // Вычисляем время текущей сессии в секундах
    const currentSessionUptime = Math.floor((Date.now() - this.sessionStartTime) / 1000);

    return {
      id: this.uid,
      version: app.getVersion(),
      platform: os.platform(),
      arch: os.arch(),
      locale: app.getLocale(),
      installDate: store.installed,
      currentTheme: this.data.currentTheme || 'dark',
      webServerEnabled: this.data.webServerEnabled || false,
      metrics: {
        sessions: this.data.sessions,
        totalUptime: this.data.totalUptime || 0,
        sessionUptime: currentSessionUptime,
        printersAdded: this.data.printersAdded,
        currentPrinters: this.data.currentPrinters,
        maxPrinters: this.data.maxPrinters || this.data.currentPrinters,
        printersKlipper: this.data.printersKlipper,
        printersBambu: this.data.printersBambu,
        analyticsViews: this.data.analyticsViews,
        exportsCount: this.data.exports,
        featureUsage: this.data.features,
        lastSession: this.data.lastSession,

        // === НОВЫЕ МЕТРИКИ v1.5.36 ===
        smartPlugs: this.data.smartPlugs || {},
        batchOperations: this.data.batchOperations || {},
        temperatures: this.data.temperatures || {},
        events: this.data.events || {},
        modules: this.data.modules || {},
      },
      timestamp: Date.now(),
    };
  }

  async sync(force = false) {
    if (!this.config.active) return;

    const store = this.getStore();
    if (!force && store.lastSync) {
      const elapsed = Date.now() - store.lastSync;
      if (elapsed < this.config.interval) {
        return;
      }
    }

    const payload = this.collectData();

    // ШИФРУЕМ ДАННЫЕ перед отправкой
    const encryptedPacket = this.encryptData(payload);
    if (!encryptedPacket) {
      console.error('[Telemetry] Failed to encrypt data, aborting sync');
      return;
    }

    try {
      const url = new URL(this.config.endpoint);
      const protocol = url.protocol === 'https:' ? https : http;

      // Отправляем зашифрованный пакет
      const data = JSON.stringify(encryptedPacket);

      const options = {
        hostname: url.hostname,
        port: url.port || (url.protocol === 'https:' ? 443 : 80),
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(data),
          'User-Agent': '3DPC/' + app.getVersion(),
        },
        timeout: this.config.timeout,
      };

      await new Promise((resolve, reject) => {
        const req = protocol.request(options, (res) => {
          let response = '';

          res.on('data', (chunk) => {
            response += chunk;
          });

          res.on('end', () => {
            if (res.statusCode === 200) {
              store.lastSync = Date.now();
              this.saveStore(store);

              // Добавляем время текущей сессии к общему времени работы
              const sessionTime = Math.floor((Date.now() - this.sessionStartTime) / 1000);
              this.data.totalUptime = (this.data.totalUptime || 0) + sessionTime;
              this.saveData();

              // Сбрасываем таймер сессии для следующей синхронизации
              this.sessionStartTime = Date.now();

              resolve();
            } else {
              console.error('[Telemetry] Server returned status:', res.statusCode);
              reject(new Error(`HTTP ${res.statusCode}`));
            }
          });
        });

        req.on('error', (error) => {
          console.error('[Telemetry] Request error:', error.message);
          reject(error);
        });

        req.on('timeout', () => {
          req.destroy();
          console.error('[Telemetry] Request timeout');
          reject(new Error('Timeout'));
        });

        req.write(data);
        req.end();
      });
    } catch (e) {
      console.error('[Telemetry] Sync exception:', e.message);
    }
  }

  startSync() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.sync(), this.config.interval);
  }

  stopSync() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  setEnabled(enabled) {
    this.config.active = enabled;
    if (enabled) this.startSync();
    else this.stopSync();
  }

  setCurrentTheme(theme) {
    this.data.currentTheme = theme; // 'light' или 'dark'
    this.saveData();
  }

  setWebServerEnabled(enabled) {
    this.data.webServerEnabled = enabled;
    this.saveData();
  }
}

export default DiagnosticsReporter;
