/**
 * ============================================================================
 * HARDWARE ID GENERATOR
 * ============================================================================
 * Генерирует уникальный идентификатор компьютера на основе:
 * - CPU информации (модель, ядра)
 * - MAC адреса сетевой карты
 * - Hostname
 * - UUID материнской платы (Windows)
 *
 * Используется для привязки лицензии к конкретной машине.
 */

import os from 'os';
import crypto from 'crypto';
import { execSync } from 'child_process';

// Кэш для Hardware ID на время сессии
let cachedHWID = null;

// ============================================================================
// СБОР ИНФОРМАЦИИ О СИСТЕМЕ
// ============================================================================

/**
 * Получает информацию о CPU
 * @returns {string} Хэш информации о процессоре
 */
function getCpuInfo() {
  const cpus = os.cpus();
  if (cpus.length === 0) return 'unknown-cpu';

  const firstCpu = cpus[0];
  const cpuString = `${firstCpu.model}-${cpus.length}-${firstCpu.speed}`;

  return crypto.createHash('sha256').update(cpuString).digest('hex').substring(0, 16);
}

/**
 * Получает MAC адрес первого активного сетевого интерфейса
 * @returns {string} MAC адрес или 'unknown-mac'
 */
function getMacAddress() {
  const interfaces = os.networkInterfaces();

  for (const name of Object.keys(interfaces)) {
    const iface = interfaces[name];
    for (const addr of iface) {
      // Пропускаем loopback и виртуальные адаптеры
      if (!addr.internal && addr.mac !== '00:00:00:00:00:00') {
        return addr.mac.replace(/:/g, '').toUpperCase();
      }
    }
  }

  return 'unknown-mac';
}

/**
 * Получает hostname компьютера
 * @returns {string} Hostname
 */
function getHostname() {
  return os.hostname() || 'unknown-host';
}

/**
 * Получает UUID материнской платы (только Windows)
 * @returns {string} UUID или 'unknown-uuid'
 */
function getMotherboardUUID() {
  try {
    if (process.platform === 'win32') {
      const output = execSync('wmic csproduct get uuid', { encoding: 'utf8' });
      const lines = output
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => l);
      if (lines.length >= 2) {
        return lines[1].trim();
      }
    } else if (process.platform === 'darwin') {
      // macOS
      const output = execSync("ioreg -rd1 -c IOPlatformExpertDevice | grep 'IOPlatformUUID'", {
        encoding: 'utf8',
      });
      const match = output.match(/"([^"]+)"/);
      if (match) return match[1];
    } else {
      // Linux
      const output = execSync('cat /sys/class/dmi/id/product_uuid 2>/dev/null || echo unknown', {
        encoding: 'utf8',
      });
      return output.trim();
    }
  } catch (error) {
    console.error('[HWID] Failed to get motherboard UUID:', error.message);
  }

  return 'unknown-uuid';
}

// ============================================================================
// ГЕНЕРАЦИЯ HARDWARE ID
// ============================================================================

/**
 * Генерирует уникальный Hardware ID для текущей машины
 * @returns {string} Hardware ID в формате XXXXXXXXXXXXXXXX (16 символов hex)
 */
export function generateHWID() {
  if (cachedHWID) return cachedHWID;
  const cpu = getCpuInfo();
  const mac = getMacAddress();
  const hostname = getHostname();
  const uuid = getMotherboardUUID();

  // Комбинируем всю информацию
  const combined = `${cpu}-${mac}-${hostname}-${uuid}`;

  // Генерируем SHA-256 хэш и берем первые 32 символа (16 байт)
  const hash = crypto
    .createHash('sha256')
    .update(combined)
    .digest('hex')
    .substring(0, 32)
    .toUpperCase();

  console.log('[HWID] Generated Hardware ID:', hash);
  console.log('[HWID] Components:', { cpu, mac, hostname, uuid: uuid.substring(0, 8) + '...' });

  cachedHWID = hash;
  return cachedHWID;
}

/**
 * Получает детальную информацию о системе (для отображения пользователю)
 * @returns {Object} Информация о системе
 */
export function getSystemInfo() {
  return {
    hwid: generateHWID(),
    platform: process.platform,
    arch: process.arch,
    hostname: getHostname(),
    cpuModel: os.cpus()[0]?.model || 'Unknown',
    cpuCores: os.cpus().length,
    totalMemory: Math.round(os.totalmem() / 1024 / 1024 / 1024) + ' GB',
    osVersion: `${os.type()} ${os.release()}`,
  };
}

/**
 * Форматирует HWID для отображения (добавляет дефисы)
 * @param {string} hwid - Hardware ID
 * @returns {string} Отформатированный HWID (XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX)
 */
export function formatHWID(hwid) {
  if (!hwid || hwid.length !== 32) return hwid;

  return hwid.match(/.{1,4}/g).join('-');
}

/**
 * Проверяет, совпадает ли HWID с текущей машиной
 * @param {string} expectedHWID - Ожидаемый HWID
 * @returns {boolean} true если HWID совпадает
 */
export function verifyHWID(expectedHWID) {
  // Защита от некорректного входа
  if (!expectedHWID || typeof expectedHWID !== 'string') {
    return false;
  }
  const currentHWID = generateHWID();
  const cleanExpected = expectedHWID.replace(/-/g, '').toUpperCase();
  const cleanCurrent = currentHWID.replace(/-/g, '').toUpperCase();

  return cleanExpected === cleanCurrent;
}
