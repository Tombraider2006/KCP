/**
 * ============================================================================
 * LICENSING SYSTEM
 * ============================================================================
 * Управление лицензиями KCP:
 * - FREE (до 10 принтеров - бесплатно навсегда)
 * - Trial (14 дней с неограниченным количеством принтеров)
 * - Professional (пожизненная, перенос 2 раза/год, без ограничений)
 *
 * Проверка: локально + онлайн раз в 30 дней (grace period 90 дней)
 */

import Store from 'electron-store';
import crypto from 'crypto';
import { generateHWID, verifyHWID } from './hwid.js';

const store = new Store();

// ============================================================================
// КОНСТАНТЫ
// ============================================================================

const LICENSE_API_URL = 'http://tomich.fun:3000/api/license';

const PLAN_TYPES = {
  FREE: 'free', // До 10 принтеров - бесплатно
  TRIAL: 'trial', // 14 дней без ограничений
  PROFESSIONAL: 'professional', // Платная, с переносом
};

const LICENSE_STATUS = {
  VALID: 'valid',
  EXPIRED: 'expired',
  INVALID: 'invalid',
  TRIAL_EXPIRED: 'trial_expired',
  NEEDS_ACTIVATION: 'needs_activation',
  FREE_LIMIT: 'free_limit', // Превышен лимит бесплатных принтеров
  EXPIRING_SOON: 'expiring_soon', // Осталось меньше 5 дней
};

const TRIAL_DAYS = 14;
const FREE_MAX_PRINTERS = 10; // До 10 принтеров - бесплатно
const ONLINE_CHECK_INTERVAL = 30 * 24 * 60 * 60 * 1000; // 30 дней
const GRACE_PERIOD = 90 * 24 * 60 * 60 * 1000; // 90 дней grace period

// ============================================================================
// СТРУКТУРА ЛИЦЕНЗИИ
// ============================================================================

/**
 * @typedef {Object} License
 * @property {string} key - Ключ лицензии (3DCP-XXXX-XXXX-...)
 * @property {string} plan - Тип плана (trial, professional)
 * @property {string} hwid - Hardware ID
 * @property {number} activatedAt - Дата активации (timestamp)
 * @property {number|null} expiresAt - Дата истечения (null для lifetime)
 * @property {number} lastOnlineCheck - Последняя онлайн проверка
 * @property {string} status - Статус лицензии
 * @property {string|null} email - Email владельца
 * @property {number} printerLimit - Лимит принтеров для лицензии
 */

// ============================================================================
// ИНИЦИАЛИЗАЦИЯ
// ============================================================================

/**
 * Инициализирует систему лицензирования
 * Создает Trial лицензию если нет активной
 */
export function initLicensing() {
  let license = store.get('license');

  if (!license) {
    console.log('[License] No license found, creating FREE license (up to 10 printers)');
    license = createFreeLicense();
    store.set('license', license);
  }

  console.log('[License] Current license:', {
    plan: license.plan,
    status: license.status,
    key: license.key ? license.key.substring(0, 15) + '...' : 'none',
  });

  return license;
}

/**
 * Создает FREE лицензию (до 10 принтеров)
 * @returns {License}
 */
function createFreeLicense() {
  const now = Date.now();

  return {
    key: null,
    plan: PLAN_TYPES.FREE,
    hwid: generateHWID(),
    activatedAt: now,
    expiresAt: null, // Бессрочно
    lastOnlineCheck: now,
    status: LICENSE_STATUS.VALID,
    email: null,
    printerLimit: 10, // FREE лицензия - до 10 принтеров
  };
}

/**
 * Получает лимит принтеров по умолчанию для типа лицензии
 * @param {string} plan - Тип плана
 * @returns {number} Лимит принтеров
 */
function getDefaultPrinterLimit(plan) {
  switch (plan) {
    case PLAN_TYPES.FREE:
      return 10;
    case PLAN_TYPES.TRIAL:
      return 500; // Trial без ограничений
    case PLAN_TYPES.PROFESSIONAL:
      return 100; // По умолчанию для Professional (если сервер не вернул)
    default:
      return 10;
  }
}

// ============================================================================
// ПРОВЕРКА ЛИЦЕНЗИИ
// ============================================================================

/**
 * Проверяет текущую лицензию
 * @param {number} printerCount - Текущее количество принтеров
 * @returns {Object} Результат проверки
 */
export function checkLicense(printerCount = 0) {
  const license = store.get('license');

  if (!license) {
    return {
      valid: false,
      status: LICENSE_STATUS.NEEDS_ACTIVATION,
      message: 'Лицензия не активирована',
      trialDaysLeft: 0,
      canAddPrinter: false,
    };
  }

  const now = Date.now();

  // === FREE ЛИЦЕНЗИЯ (до 10 принтеров) ===
  if (license.plan === PLAN_TYPES.FREE) {
    // Проверка лимита принтеров
    const printerLimit = license.printerLimit || 10;
    if (printerCount >= printerLimit) {
      license.status = LICENSE_STATUS.FREE_LIMIT;
      store.set('license', license);

      return {
        valid: false,
        status: LICENSE_STATUS.FREE_LIMIT,
        message: `Достигнут лимит бесплатной версии (${printerLimit} принтеров). Приобретите лицензию для добавления новых принтеров.`,
        trialDaysLeft: null,
        canAddPrinter: false,
        isFree: true,
      };
    }

    return {
      valid: true,
      status: LICENSE_STATUS.VALID,
      message: `Бесплатная версия: ${printerCount}/${printerLimit} принтеров`,
      trialDaysLeft: null,
      canAddPrinter: printerCount < printerLimit,
      isFree: true,
    };
  }

  // === TRIAL ЛИЦЕНЗИЯ (14 дней, с лимитом принтеров) ===
  if (license.plan === PLAN_TYPES.TRIAL) {
    const daysUsed = Math.floor((now - license.activatedAt) / (1000 * 60 * 60 * 24));
    const daysLeft = TRIAL_DAYS - daysUsed;
    const printerLimit = license.printerLimit || 50;

    // Проверка лимита принтеров
    if (printerCount >= printerLimit) {
      return {
        valid: false,
        status: LICENSE_STATUS.TRIAL_LIMIT,
        message: `Достигнут лимит Trial версии (${printerLimit} принтеров). Приобретите лицензию для добавления новых принтеров.`,
        trialDaysLeft: daysLeft,
        canAddPrinter: false,
      };
    }

    // Проверка по дням
    if (daysLeft <= 0) {
      license.status = LICENSE_STATUS.TRIAL_EXPIRED;
      store.set('license', license);

      return {
        valid: false,
        status: LICENSE_STATUS.TRIAL_EXPIRED,
        message: `Trial период истек (${TRIAL_DAYS} дней). Приобретите лицензию или используйте бесплатную версию (до 10 принтеров).`,
        trialDaysLeft: 0,
        canAddPrinter: false,
      };
    }

    return {
      valid: true,
      status: LICENSE_STATUS.VALID,
      message: `Trial: ${daysLeft} дней осталось (до ${printerLimit} принтеров)`,
      trialDaysLeft: daysLeft,
      canAddPrinter: printerCount < printerLimit,
    };
  }

  // === ПЛАТНАЯ ЛИЦЕНЗИЯ ===

  // Проверка HWID
  if (!verifyHWID(license.hwid)) {
    return {
      valid: false,
      status: LICENSE_STATUS.INVALID,
      message: 'Лицензия привязана к другому компьютеру',
      trialDaysLeft: 0,
      canAddPrinter: false,
    };
  }

  // Проверка срока действия (если не lifetime)
  if (license.expiresAt) {
    const daysLeft = Math.ceil((license.expiresAt - now) / (1000 * 60 * 60 * 24));

    if (daysLeft <= 0) {
      license.status = LICENSE_STATUS.EXPIRED;
      store.set('license', license);

      return {
        valid: false,
        status: LICENSE_STATUS.EXPIRED,
        message: 'Срок действия лицензии истек',
        daysLeft: 0,
        canAddPrinter: false,
      };
    }

    // Предупреждение за 5 дней
    if (daysLeft <= 5) {
      return {
        valid: true,
        status: LICENSE_STATUS.EXPIRING_SOON,
        message: `⚠️ Лицензия истекает через ${daysLeft} ${daysLeft === 1 ? 'день' : daysLeft < 5 ? 'дня' : 'дней'}! Обновите лицензию.`,
        daysLeft: daysLeft,
        canAddPrinter: true,
        plan: license.plan,
        expiringSoon: true,
      };
    }
  }

  // Проверка онлайн (раз в 30 дней)
  const timeSinceLastCheck = now - license.lastOnlineCheck;
  if (timeSinceLastCheck > ONLINE_CHECK_INTERVAL) {
    // Если прошло > 90 дней без онлайн проверки - блокируем
    if (timeSinceLastCheck > GRACE_PERIOD) {
      return {
        valid: false,
        status: LICENSE_STATUS.INVALID,
        message: 'Требуется подключение к интернету для проверки лицензии',
        trialDaysLeft: 0,
        canAddPrinter: false,
        needsOnlineCheck: true,
      };
    }

    // Пытаемся проверить онлайн (не блокируем если не получилось)
    validateLicenseOnline(license.key).catch((err) => {
      console.warn('[License] Online validation failed:', err.message);
    });
  }

  // === ПЛАТНАЯ ЛИЦЕНЗИЯ ВАЛИДНА ===
  let message = 'Professional лицензия';
  let daysLeft = null;

  // Если есть срок истечения - показываем оставшиеся дни
  if (license.expiresAt) {
    daysLeft = Math.ceil((license.expiresAt - now) / (1000 * 60 * 60 * 24));
    message += ` (осталось ${daysLeft} ${daysLeft === 1 ? 'день' : daysLeft < 5 ? 'дня' : 'дней'})`;
  } else {
    message += ' (бессрочная)';
  }

  return {
    valid: true,
    status: LICENSE_STATUS.VALID,
    message: message,
    daysLeft: daysLeft,
    canAddPrinter: true,
    plan: license.plan,
  };
}

/**
 * Проверяет можно ли добавить принтер
 * @returns {boolean}
 */
export function canAddPrinter() {
  const printerCount = store.get('printers', []).length;
  const result = checkLicense(printerCount + 1);
  return result.canAddPrinter;
}

// ============================================================================
// АКТИВАЦИЯ ЛИЦЕНЗИИ
// ============================================================================

/**
 * Активирует лицензию по ключу
 * @param {string} licenseKey - Ключ лицензии
 * @returns {Promise<Object>} Результат активации
 */
export async function activateLicense(licenseKey) {
  try {
    // Валидация и нормализация ключа
    if (!licenseKey) {
      throw new Error(t('license_error_enter_key'));
    }

    // Убираем пробелы и приводим к верхнему регистру
    const normalizedKey = licenseKey.trim().toUpperCase();

    if (!normalizedKey.startsWith('3DCP-')) {
      throw new Error(t('license_error_invalid_format'));
    }

    // Проверяем общий формат ключа (3DCP-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX)
    // Поддерживаем как 4-символьные, так и 8-символьные группы
    const keyPattern4 = /^3DCP-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
    const keyPattern8 = /^3DCP-[A-Z0-9]{8}-[A-Z0-9]{8}-[A-Z0-9]{8}-[A-Z0-9]{8}-[A-Z0-9]{8}$/;
    if (!keyPattern4.test(normalizedKey) && !keyPattern8.test(normalizedKey)) {
      throw new Error(t('license_error_invalid_pattern'));
    }

    const hwid = generateHWID();

    console.log('[License] Attempting activation:', {
      key: normalizedKey.substring(0, 20) + '...',
      hwid: hwid.substring(0, 16) + '...',
      version: process.env.npm_package_version || '1.0.0',
      platform: process.platform,
    });

    // Отправляем запрос на активацию
    const response = await fetch(`${LICENSE_API_URL}/activate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': '3DCP/' + (process.env.npm_package_version || '1.0.0'),
      },
      body: JSON.stringify({
        key: normalizedKey,
        hwid: hwid,
        version: process.env.npm_package_version || '1.0.0',
        platform: process.platform,
      }),
    });

    const responseText = await response.text();
    console.log('[License] Raw response:', responseText);
    console.log('[License] Response status:', response.status);
    console.log('[License] Response headers:', Object.fromEntries(response.headers.entries()));

    let data;

    try {
      // Очищаем ответ от возможных лишних символов
      const cleanResponse = responseText.trim();
      data = JSON.parse(cleanResponse);
    } catch (parseError) {
      console.error('[License] Invalid JSON response:', responseText);
      console.error('[License] Parse error:', parseError);
      throw new Error(t('license_error_server_response'));
    }

    if (!response.ok) {
      throw new Error(
        data.message || t('license_error_activation_status').replace('{status}', response.status),
      );
    }

    if (!data.success) {
      throw new Error(data.message || t('license_error_activation'));
    }

    // Сохраняем лицензию
    const license = {
      key: normalizedKey,
      plan: data.plan,
      hwid: hwid,
      activatedAt: Date.now(),
      expiresAt: data.expiresAt || null,
      lastOnlineCheck: Date.now(),
      status: LICENSE_STATUS.VALID,
      email: data.email || null,
      printerLimit: data.printerLimit || getDefaultPrinterLimit(data.plan),
    };

    store.set('license', license);

    console.log('[License] License activated successfully:', {
      plan: license.plan,
      expiresAt: license.expiresAt ? new Date(license.expiresAt).toISOString() : 'never',
    });

    return {
      success: true,
      plan: license.plan,
      message: data.message || 'Лицензия успешно активирована!',
    };
  } catch (error) {
    console.error('[License] Activation failed:', error.message);

    // Улучшенные сообщения об ошибках
    let errorMessage = error.message;

    if (error.message.includes('fetch')) {
      errorMessage = 'Ошибка подключения к серверу. Проверьте интернет-соединение.';
    } else if (error.message.includes('timeout')) {
      errorMessage = 'Превышено время ожидания ответа сервера. Попробуйте позже.';
    } else if (error.message.includes('404')) {
      errorMessage = 'Лицензия не найдена. Проверьте правильность ключа.';
    } else if (error.message.includes('403')) {
      errorMessage = 'Лицензия неактивна или привязана к другому компьютеру.';
    }

    return {
      success: false,
      message: errorMessage,
    };
  }
}

/**
 * Валидирует лицензию онлайн
 * @param {string} licenseKey - Ключ лицензии
 * @returns {Promise<boolean>}
 */
async function validateLicenseOnline(licenseKey) {
  try {
    const response = await fetch(`${LICENSE_API_URL}/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        key: licenseKey,
        hwid: generateHWID(),
      }),
    });

    if (!response.ok) {
      throw new Error(t('license_error_validation_failed'));
    }

    const data = await response.json();

    if (data.valid) {
      // Обновляем время последней проверки
      const license = store.get('license');
      license.lastOnlineCheck = Date.now();
      store.set('license', license);

      console.log('[License] Online validation successful');
      return true;
    }

    return false;
  } catch (error) {
    console.error('[License] Online validation error:', error.message);
    throw error;
  }
}

// ============================================================================
// ЗАПРОС ЛИЦЕНЗИИ ЧЕРЕЗ TELEGRAM BOT
// ============================================================================

/**
 * Отправляет запрос на лицензию через Telegram Bot
 * @param {Object} params - Параметры запроса
 * @param {string} params.plan - Тип плана
 * @param {string} params.email - Email (опционально)
 * @returns {Promise<Object>}
 */
export async function requestLicense(params) {
  try {
    const hwid = generateHWID();

    const response = await fetch(`${LICENSE_API_URL}/request`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hwid: hwid,
        plan: params.plan,
        email: params.email || null,
        version: process.env.npm_package_version || '1.0.0',
        platform: process.platform,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || t('license_error_request_failed'));
    }

    const data = await response.json();

    return {
      success: true,
      message: 'Запрос отправлен! Ожидайте ключ в Telegram',
      requestId: data.requestId,
    };
  } catch (error) {
    console.error('[License] Request failed:', error);
    return {
      success: false,
      message: error.message,
    };
  }
}

// ============================================================================
// ПОЛУЧЕНИЕ ИНФОРМАЦИИ
// ============================================================================

/**
 * Получает текущую лицензию
 * @returns {License|null}
 */
export function getCurrentLicense() {
  return store.get('license');
}

/**
 * Получает статус лицензии для UI
 * @returns {Object}
 */
export function getLicenseStatus() {
  const license = store.get('license');
  if (!license) {
    return {
      hasLicense: false,
      plan: PLAN_TYPES.TRIAL,
      status: LICENSE_STATUS.NEEDS_ACTIVATION,
      message: 'Лицензия не активирована',
    };
  }

  const printerCount = store.get('printers', []).length;
  const result = checkLicense(printerCount);

  return {
    hasLicense: license.key !== null,
    plan: license.plan,
    status: result.status,
    message: result.message,
    valid: result.valid,
    trialDaysLeft: result.trialDaysLeft,
    activatedAt: license.activatedAt,
    expiresAt: license.expiresAt,
  };
}

/**
 * Экспорт констант
 */
export { PLAN_TYPES, LICENSE_STATUS, TRIAL_DAYS, FREE_MAX_PRINTERS };
