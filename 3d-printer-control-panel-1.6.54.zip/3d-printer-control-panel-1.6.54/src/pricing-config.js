/**
 * ============================================================================
 * PRICING CONFIGURATION
 * ============================================================================
 * Централизованное управление ценами и периодами лицензий
 * Изменяйте только здесь - автоматически применится везде!
 */

export const PRICING = {
  // Русские цены (рубли)
  RU: {
    STANDARD: {
      price: '2990 ₽',
      period: '3 месяца',
      months: 3,
    },
    PROFESSIONAL: {
      price: '9990 ₽',
      period: '1 год',
      months: 12,
    },
  },

  // Английские цены (доллары)
  EN: {
    STANDARD: {
      price: '$29',
      period: '3 months',
      months: 3,
    },
    PROFESSIONAL: {
      price: '$99',
      period: '1 year',
      months: 12,
    },
  },
};

/**
 * Получить цену для текущего языка
 * @param {string} plan - 'STANDARD' или 'PROFESSIONAL'
 * @param {string} lang - 'ru' или 'en'
 * @returns {object} {price, period, months}
 */
export function getPrice(plan, lang = 'ru') {
  const language = lang.toLowerCase() === 'en' ? 'EN' : 'RU';
  return PRICING[language][plan.toUpperCase()] || PRICING.RU.STANDARD;
}

/**
 * Форматирует описание тарифа для сообщений
 * @param {string} plan - 'standard' или 'professional'
 * @param {string} lang - 'ru' или 'en'
 * @returns {string} Например: "2990₽ (3 месяца)" или "$29 (3 months)"
 */
export function formatPlanDescription(plan, lang = 'ru') {
  const pricing = getPrice(plan, lang);
  return `${pricing.price} (${pricing.period})`;
}

console.log('[Pricing] Configuration loaded');
