/**
 * МИГРАЦИЯ ДАННЫХ ДЛЯ ВЕРСИИ 1.6.51
 * Решает проблемы с поврежденными данными от предыдущих версий
 */

import Store from 'electron-store';
import { existsSync, renameSync, copyFileSync } from 'fs';
import path from 'path';
import os from 'os';

const STORE_VERSION = '1.6.51';
const MIGRATION_LOG_PREFIX = '[DataMigration]';

/**
 * Основной класс миграции данных
 */
export class DataMigration {
  constructor() {
    this.store = new Store();
    this.migrationLog = [];
    this.backupPath = this.getBackupPath();
  }

  /**
   * Получить путь для бэкапа данных
   */
  getBackupPath() {
    const userData = this.store.path;
    const backupDir = path.dirname(userData);
    return path.join(backupDir, '3dpc-backup-' + Date.now());
  }

  /**
   * Создать бэкап текущих данных
   */
  async createBackup() {
    try {
      const userData = this.store.path;
      if (existsSync(userData)) {
        copyFileSync(userData, this.backupPath);
        this.log(`✅ Backup created: ${this.backupPath}`);
        return true;
      }
    } catch (error) {
      this.log(`❌ Backup failed: ${error.message}`);
      return false;
    }
    return false;
  }

  /**
   * Проверить целостность данных
   */
  validateData() {
    const issues = [];

    try {
      // Проверяем основные ключи
      const printers = this.store.get('printers', []);
      if (!Array.isArray(printers)) {
        issues.push('printers: not an array');
      }

      const license = this.store.get('license');
      if (license && typeof license !== 'object') {
        issues.push('license: invalid format');
      }

      const analytics = this.store.get('analytics');
      if (analytics && typeof analytics !== 'object') {
        issues.push('analytics: invalid format');
      }

      // Проверяем структуру принтеров
      if (Array.isArray(printers)) {
        printers.forEach((printer, index) => {
          if (!printer.id || !printer.name || !printer.ip) {
            issues.push(`printer[${index}]: missing required fields`);
          }
        });
      }
    } catch (error) {
      issues.push(`validation error: ${error.message}`);
    }

    return {
      isValid: issues.length === 0,
      issues,
    };
  }

  /**
   * Очистить поврежденные данные
   */
  cleanCorruptedData() {
    try {
      const printers = this.store.get('printers', []);
      if (!Array.isArray(printers)) {
        this.store.set('printers', []);
        this.log('🧹 Cleaned corrupted printers array');
      }

      const license = this.store.get('license');
      if (license && typeof license !== 'object') {
        this.store.delete('license');
        this.log('🧹 Cleaned corrupted license data');
      }

      const analytics = this.store.get('analytics');
      if (analytics && typeof analytics !== 'object') {
        this.store.delete('analytics');
        this.log('🧹 Cleaned corrupted analytics data');
      }

      // Очищаем старые неиспользуемые ключи
      const oldKeys = ['oldPrinters', 'legacyData', 'tempData'];
      oldKeys.forEach((key) => {
        if (this.store.has(key)) {
          this.store.delete(key);
          this.log(`🧹 Removed old key: ${key}`);
        }
      });

      return true;
    } catch (error) {
      this.log(`❌ Cleanup failed: ${error.message}`);
      return false;
    }
  }

  /**
   * Мигрировать данные принтеров
   */
  migratePrinters() {
    try {
      const printers = this.store.get('printers', []);
      if (!Array.isArray(printers)) {
        this.store.set('printers', []);
        return true;
      }

      let migrated = 0;
      const cleanPrinters = printers.map((printer) => {
        // Убеждаемся, что все обязательные поля присутствуют
        const cleanPrinter = {
          id: printer.id || `printer-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: printer.name || 'Unnamed Printer',
          ip: printer.ip || '',
          port: printer.port || '7125',
          type: printer.type || 'klipper',
          order: typeof printer.order === 'number' ? printer.order : 0,
          addedAt: printer.addedAt || Date.now(),
          licenseDisabled: printer.licenseDisabled || false,
        };

        // Очищаем недопустимые поля
        const allowedFields = [
          'id',
          'name',
          'ip',
          'port',
          'type',
          'order',
          'addedAt',
          'licenseDisabled',
          'tuyaDeviceId',
          'haEntityId',
          'autoShutdownEnabled',
          'autoShutdownDelay',
          'autoShutdownError',
          'autoShutdownOverheat',
        ];
        Object.keys(cleanPrinter).forEach((key) => {
          if (!allowedFields.includes(key)) {
            delete cleanPrinter[key];
          }
        });

        if (JSON.stringify(printer) !== JSON.stringify(cleanPrinter)) {
          migrated++;
        }

        return cleanPrinter;
      });

      this.store.set('printers', cleanPrinters);
      this.log(`✅ Migrated ${migrated} printers`);
      return true;
    } catch (error) {
      this.log(`❌ Printer migration failed: ${error.message}`);
      return false;
    }
  }

  /**
   * Мигрировать лицензионные данные
   */
  migrateLicense() {
    try {
      const license = this.store.get('license');
      if (!license) {
        // Создаем FREE лицензию по умолчанию
        const defaultLicense = {
          key: null,
          plan: 'FREE',
          status: 'ACTIVE',
          printerLimit: 10,
          activatedAt: Date.now(),
          expiresAt: null,
          lastOnlineCheck: Date.now(),
        };
        this.store.set('license', defaultLicense);
        this.log('✅ Created default FREE license');
        return true;
      }

      // Валидируем существующую лицензию
      const cleanLicense = {
        key: license.key || null,
        plan: license.plan || 'FREE',
        status: license.status || 'ACTIVE',
        printerLimit: typeof license.printerLimit === 'number' ? license.printerLimit : 10,
        activatedAt: typeof license.activatedAt === 'number' ? license.activatedAt : Date.now(),
        expiresAt: license.expiresAt || null,
        lastOnlineCheck:
          typeof license.lastOnlineCheck === 'number' ? license.lastOnlineCheck : Date.now(),
      };

      this.store.set('license', cleanLicense);
      this.log('✅ Migrated license data');
      return true;
    } catch (error) {
      this.log(`❌ License migration failed: ${error.message}`);
      return false;
    }
  }

  /**
   * Мигрировать аналитические данные
   */
  migrateAnalytics() {
    try {
      const analytics = this.store.get('analytics', {});
      if (typeof analytics !== 'object') {
        this.store.set('analytics', {});
        this.log('✅ Created default analytics');
        return true;
      }

      // Очищаем аналитику от недопустимых значений
      const cleanAnalytics = {};
      const allowedKeys = [
        'sessions',
        'printers_added',
        'printers_removed',
        'network_scans',
        'exports',
        'imports',
      ];

      allowedKeys.forEach((key) => {
        if (typeof analytics[key] === 'number' && analytics[key] >= 0) {
          cleanAnalytics[key] = analytics[key];
        }
      });

      this.store.set('analytics', cleanAnalytics);
      this.log('✅ Migrated analytics data');
      return true;
    } catch (error) {
      this.log(`❌ Analytics migration failed: ${error.message}`);
      return false;
    }
  }

  /**
   * Установить версию данных
   */
  setDataVersion() {
    this.store.set('dataVersion', STORE_VERSION);
    this.log(`✅ Set data version to ${STORE_VERSION}`);
  }

  /**
   * Выполнить полную миграцию
   */
  async performMigration() {
    this.log('🚀 Starting data migration...');

    // 1. Создаем бэкап
    await this.createBackup();

    // 2. Проверяем целостность
    const validation = this.validateData();
    if (!validation.isValid) {
      this.log(`⚠️ Data issues found: ${validation.issues.join(', ')}`);
    }

    // 3. Очищаем поврежденные данные
    this.cleanCorruptedData();

    // 4. Мигрируем данные
    this.migratePrinters();
    this.migrateLicense();
    this.migrateAnalytics();

    // 5. Устанавливаем версию
    this.setDataVersion();

    this.log('✅ Migration completed successfully');
    return {
      success: true,
      backupPath: this.backupPath,
      log: this.migrationLog,
    };
  }

  /**
   * Проверить, нужна ли миграция
   */
  needsMigration() {
    const currentVersion = this.store.get('dataVersion');
    return currentVersion !== STORE_VERSION;
  }

  /**
   * Логирование (тихое)
   */
  log(message) {
    const timestamp = new Date().toISOString();
    const logMessage = `${timestamp} ${MIGRATION_LOG_PREFIX} ${message}`;
    this.migrationLog.push(logMessage);
    // Убираем console.log для тихой работы
  }

  /**
   * Получить лог миграции
   */
  getLog() {
    return this.migrationLog;
  }
}

/**
 * Быстрая функция для автоматической миграции
 */
export async function autoMigrate() {
  const migration = new DataMigration();

  if (migration.needsMigration()) {
    return await migration.performMigration();
  } else {
    return { success: true, skipped: true };
  }
}

/**
 * Функция для принудительной очистки данных
 */
export async function forceCleanup() {
  const migration = new DataMigration();

  // Создаем бэкап
  await migration.createBackup();

  // Очищаем все данные
  migration.store.clear();

  // Устанавливаем версию
  migration.setDataVersion();

  return {
    success: true,
    backupPath: migration.backupPath,
    message: 'All data cleared and reset to defaults',
  };
}
