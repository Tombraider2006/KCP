/**
 * ============================================================================
 * LICENSING UI FUNCTIONS
 * ============================================================================
 * UI функции для работы с системой лицензирования
 */

// Все функции работы с лицензией и HWID доступны через window.electronAPI

// ============================================================================
// МОДАЛЬНОЕ ОКНО
// ============================================================================

/**
 * Открывает модальное окно лицензирования
 */
window.openLicensingModal = async function () {
  const modal = document.getElementById('licensingModal');
  if (!modal) return;

  // Применяем переводы к элементам лицензирования
  applyLicenseTranslations();

  // Загружаем статус лицензии (после переводов, чтобы не перезаписывать динамические значения)
  await updateLicenseStatusUI();

  // Автоматически отправляем HWID боту для регистрации
  await registerHWIDWithBot();

  modal.style.display = 'block';
  console.log('[License UI] Modal opened');
};

/**
 * Применяет переводы к элементам модального окна лицензирования
 */
function applyLicenseTranslations() {
  if (typeof t !== 'function') return;

  // Update all elements with data-i18n attributes in licensing and contact modals
  const licenseElements = document.querySelectorAll(
    '#licensingModal [data-i18n], #contactMethodModal [data-i18n]',
  );
  licenseElements.forEach((element) => {
    const key = element.getAttribute('data-i18n');
    if (key) {
      const translation = t(key);
      if (translation && translation !== key) {
        // Для элементов с HTML содержимым (br теги, bold)
        if (
          key === 'license_how_to_request_steps' ||
          key === 'license_disclaimer_text' ||
          key === 'contact_telegram_desc' ||
          key === 'contact_email_desc'
        ) {
          element.innerHTML = translation;
        } else {
          element.textContent = translation;
        }
      }
    }
  });

  // Update all elements with data-i18n-placeholder attributes
  const placeholderElements = document.querySelectorAll(
    '#licensingModal [data-i18n-placeholder], #contactMethodModal [data-i18n-placeholder]',
  );
  placeholderElements.forEach((element) => {
    const key = element.getAttribute('data-i18n-placeholder');
    if (key) {
      const translation = t(key);
      if (translation && translation !== key) {
        element.placeholder = translation;
      }
    }
  });

  // Update all elements with data-i18n-title attributes
  const titleElements = document.querySelectorAll(
    '#licensingModal [data-i18n-title], #contactMethodModal [data-i18n-title]',
  );
  titleElements.forEach((element) => {
    const key = element.getAttribute('data-i18n-title');
    if (key) {
      const translation = t(key);
      if (translation && translation !== key) {
        element.title = translation;
      }
    }
  });

  // Специальная обработка для элементов с HTML (если не обработались выше)
  const stepsEl = document.getElementById('licenseHowToRequestSteps');
  if (stepsEl && typeof t === 'function') {
    stepsEl.innerHTML = t('license_how_to_request_steps');
  }

  const disclaimerEl = document.getElementById('licenseDisclaimerText');
  if (disclaimerEl && typeof t === 'function') {
    disclaimerEl.innerHTML = t('license_disclaimer_text');
  }
}

/**
 * Регистрирует HWID у бота (для связи Hardware ID → Telegram username)
 */
async function registerHWIDWithBot() {
  try {
    const hwidData = await window.electronAPI.licensing.getHWID();

    // Отправляем HWID на сервер для регистрации
    const response = await fetch('http://tomich.fun:3000/api/license/register-hwid', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hwid: hwidData.hwid,
        platform: navigator.platform,
        version: '1.6.1',
      }),
    });

    if (response.ok) {
      console.log('[License] HWID registered with server');
    }
  } catch (error) {
    console.log('[License] HWID registration failed (offline?):', error.message);
    // Не критично, просто логируем
  }
}

/**
 * Закрывает модальное окно лицензирования
 */
window.closeLicensingModal = function () {
  const modal = document.getElementById('licensingModal');
  if (modal) {
    modal.style.display = 'none';
  }
};

/**
 * Обновляет UI статуса лицензии
 */
async function updateLicenseStatusUI() {
  const status = await window.electronAPI.licensing.getStatus();
  const hwidData = await window.electronAPI.licensing.getHWID();

  // Иконка и заголовок
  const iconEl = document.getElementById('licenseStatusIcon');
  const titleEl = document.getElementById('licenseStatusTitle');
  const messageEl = document.getElementById('licenseStatusMessage');
  const hwidEl = document.getElementById('licenseHwid');

  if (!iconEl || !titleEl || !messageEl || !hwidEl) return;

  // Устанавливаем HWID (уже отформатирован на сервере)
  hwidEl.textContent = hwidData.formatted;

  // Устанавливаем статус в зависимости от плана
  switch (status.plan) {
    case 'free':
      iconEl.textContent = '🆓';
      titleEl.textContent = t('license_status_free');
      messageEl.textContent = status.message;
      break;

    case 'trial':
      iconEl.textContent = '⏱️';
      titleEl.textContent = t('license_status_trial');
      messageEl.textContent = status.message;
      break;

    case 'professional':
      iconEl.textContent = '👑';
      titleEl.textContent = t('license_status_professional');
      messageEl.textContent = status.message;
      break;
  }

  // Обновляем цвет блока статуса
  const statusBlock = document.getElementById('licenseStatusBlock');
  if (statusBlock) {
    if (status.expiringSoon) {
      // Предупреждение - жёлтый
      statusBlock.style.background = 'rgba(255, 193, 7, 0.15)';
      statusBlock.style.borderColor = 'rgba(255, 193, 7, 0.5)';
    } else if (status.valid) {
      // Валидная - зелёный
      statusBlock.style.background = 'rgba(76, 175, 80, 0.1)';
      statusBlock.style.borderColor = 'rgba(76, 175, 80, 0.3)';
    } else {
      // Невалидная - красный
      statusBlock.style.background = 'rgba(255, 107, 107, 0.1)';
      statusBlock.style.borderColor = 'rgba(255, 107, 107, 0.3)';
    }
  }

  // Скрываем/показываем элементы в зависимости от наличия активной лицензии
  updateLicenseActionsUI(status);
}

/**
 * Обновляет действия (кнопки продления/улучшения) в зависимости от статуса
 */
function updateLicenseActionsUI(status) {
  const licenseActionsEl = document.getElementById('licenseActions');
  if (!licenseActionsEl) return;

  // Если активна платная лицензия (Trial, Professional)
  if (status.plan !== 'free' && status.valid) {
    let actionsHTML =
      '<div style="margin-top: 20px; padding: 20px; background: rgba(255, 255, 255, 0.03); border-radius: 8px; border-top: 1px solid rgba(255,255,255,0.1);">';

    // Для Trial - предложить купить Professional
    if (status.plan === 'trial') {
      actionsHTML += `
                <h4 style="margin: 0 0 15px 0; color: #ffc107;">💡 Переход на полную лицензию</h4>
                <p style="color: #b0b0b0; margin-bottom: 15px; font-size: 0.95em;">Сохраните настройки и получите лицензию без ограничений по времени:</p>
                <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                    <button class="btn btn-primary" onclick="requestLicensePlan('professional')" style="flex: 1; min-width: 180px; background: linear-gradient(135deg, #ffc107, #ff9800); border-color: #ffc107;">
                        👑 Professional (бессрочная)
                    </button>
                </div>
            `;
    }
    // Для Professional - только продление (если срок истекает)
    else if (status.plan === 'professional' && status.daysLeft && status.daysLeft < 30) {
      actionsHTML += `
                <h4 style="margin: 0 0 15px 0; color: #ffc107;">🔄 Продление лицензии</h4>
                <button class="btn btn-primary" onclick="requestLicensePlan('professional')" style="width: 100%; background: linear-gradient(135deg, #ffc107, #ff9800); border-color: #ffc107;">
                    Продлить Professional
                </button>
            `;
    }

    actionsHTML += '</div>';
    licenseActionsEl.innerHTML = actionsHTML;
    licenseActionsEl.style.display = 'block';
  } else {
    licenseActionsEl.style.display = 'none';
  }
}

// ============================================================================
// ВКЛАДКИ
// ============================================================================

/**
 * Переключает вкладки
 */
window.showLicenseTab = function (tabName) {
  // Убираем активный класс со всех вкладок
  document.querySelectorAll('.license-tab').forEach((tab) => {
    tab.classList.remove('active');
  });

  document.querySelectorAll('.license-tab-content').forEach((content) => {
    content.classList.remove('active');
  });

  // Активируем нужную вкладку
  const tabBtn = document.getElementById(
    `tab${tabName.charAt(0).toUpperCase() + tabName.slice(1)}`,
  );
  const tabContent = document.getElementById(
    `tabContent${tabName.charAt(0).toUpperCase() + tabName.slice(1)}`,
  );

  if (tabBtn) tabBtn.classList.add('active');
  if (tabContent) tabContent.classList.add('active');
};

// ============================================================================
// КОПИРОВАНИЕ HWID
// ============================================================================

/**
 * Копирует HWID в буфер обмена
 */
window.copyHWID = async function () {
  const hwidEl = document.getElementById('licenseHwid');
  if (!hwidEl) return;

  const hwid = hwidEl.textContent;

  try {
    await navigator.clipboard.writeText(hwid);

    // Показываем уведомление
    const originalText = hwidEl.textContent;
    hwidEl.textContent = '✅ Скопировано!';
    hwidEl.style.color = '#4caf50';

    setTimeout(() => {
      hwidEl.textContent = originalText;
      hwidEl.style.color = '#00d4ff';
    }, 2000);

    console.log('[License UI] HWID copied to clipboard');
  } catch (error) {
    console.error('[License UI] Failed to copy HWID:', error);
    alert(t('license_error_copy_hwid').replace('{hwid}', hwid));
  }
};

// ============================================================================
// ЗАПРОС ЛИЦЕНЗИИ
// ============================================================================

/**
 * Запрос платной лицензии (Professional)
 */
window.requestLicensePlan = async function (plan) {
  // Показываем модальное окно выбора способа связи
  showContactMethodModal(plan);
};

/**
 * Открывает Telegram бота для связи
 */
window.openTelegramBot = async function (plan) {
  // Если это Trial, вызываем специальную функцию
  if (plan === 'trial') {
    requestTrialViaTelegram();
    return;
  }

  const hwidData = await window.electronAPI.licensing.getHWID();

  // Открываем Telegram бота
  await window.electronAPI.shell.openExternal('https://t.me/CP_licensing_bot');

  // Показываем инструкцию
  alert(
    t('license_telegram_opened')
      .replace('{hwid}', hwidData.formatted)
      .replace('{plan}', plan.toUpperCase()),
  );

  closeContactMethodModal();
};

/**
 * Открывает окно отправки email запроса
 */
window.openEmailRequest = async function (plan) {
  closeContactMethodModal();

  // Получаем план (параметр или из глобальной переменной)
  const selectedPlan = plan || window._selectedPlan || window.currentRequestPlan || 'unknown';

  console.log(
    '[Email Request] Plan:',
    selectedPlan,
    'from parameter:',
    plan,
    'from _selectedPlan:',
    window._selectedPlan,
  );

  // Получаем HWID
  const hwidData = await window.electronAPI.licensing.getHWID();

  // Формируем текст для email (без email пользователя, он сам впишет)
  const emailSubject = `3DCP License Request: ${selectedPlan.toUpperCase()}`;
  const emailBody = `
ЗАПРОС ЛИЦЕНЗИИ 3DCP
====================

Тарифный план: ${selectedPlan.toUpperCase()}
Hardware ID: ${hwidData.formatted}
Email для связи: [ВПИШИТЕ ВАШ EMAIL]
Платформа: ${navigator.platform}
Версия: 1.6.0

⚠️ ВАЖНО - DISCLAIMER:
Я понимаю и соглашаюсь, что принтеры Bambu Lab имеют закрытую прошивку.
Их работа с программой НЕ ГАРАНТИРОВАНА и может быть прекращена
в любой момент по независящим от нас причинам (обновления прошивки,
блокировка протоколов и т.д.).

---
Организация: Общество с ограниченной ответственностью «АЙТИ КРАФТ»
ИНН: 9718018360
КПП: 771801001
ОГРН: 1167746680628
Адрес: 123308 Москва, 1ая Магистральна 25А офис 19Н

Пожалуйста, свяжитесь со мной для уточнения способа оплаты.
    `.trim();

  // Показываем окно с информацией для отправки
  const modal = document.getElementById('emailRequestModal');
  if (modal) {
    document.getElementById('emailRequestSubject').value = emailSubject;
    document.getElementById('emailRequestBody').value = emailBody;
    document.getElementById('emailRequestTo').textContent = 'utolyna@ya.ru';
    modal.style.display = 'block';
  }
};

/**
 * Копирует email текст в буфер обмена
 */
window.copyEmailRequest = async function () {
  const subject = document.getElementById('emailRequestSubject').value;
  const body = document.getElementById('emailRequestBody').value;
  const fullText = `Тема: ${subject}\n\n${body}`;

  try {
    await navigator.clipboard.writeText(fullText);
    alert(t('license_email_copied'));
  } catch (error) {
    console.error('[License UI] Failed to copy email text:', error);
    alert(t('license_email_copy_error'));
  }
};

/**
 * Закрывает модальное окно email запроса
 */
window.closeEmailRequestModal = function () {
  const modal = document.getElementById('emailRequestModal');
  if (modal) {
    modal.style.display = 'none';
  }
};

/**
 * Показывает модальное окно выбора способа связи
 */
function showContactMethodModal(plan) {
  const modal = document.getElementById('contactMethodModal');
  if (!modal) return;

  // Сохраняем выбранный план
  window._selectedPlan = plan;

  // Применяем переводы к модальному окну
  applyLicenseTranslations();

  // Обновляем заголовок с переводом
  const titleEl = document.getElementById('contactMethodTitle');
  if (titleEl) {
    const baseTitle = t('contact_modal_title');
    titleEl.textContent = `${baseTitle}: ${plan.toUpperCase()}`;
  }

  modal.style.display = 'block';
}

/**
 * Закрывает модальное окно выбора способа связи
 */
window.closeContactMethodModal = function () {
  const modal = document.getElementById('contactMethodModal');
  if (modal) {
    modal.style.display = 'none';
  }
};

/**
 * Запрос Trial лицензии
 */
window.requestTrialLicense = async function () {
  // Показываем модальное окно выбора способа связи (как для платных тарифов)
  window.currentRequestPlan = 'trial';
  const modal = document.getElementById('contactMethodModal');
  if (modal) {
    modal.style.display = 'block';
  }
};

/**
 * Запрос Trial лицензии через Telegram (старая функция, теперь вызывается из модального окна)
 */
window.requestTrialViaTelegram = async function () {
  closeContactMethodModal();

  const resultEl = document.getElementById('trialResult');
  if (!resultEl) return;

  // Проверка /start
  const confirmStart = confirm(t('license_trial_process'));

  if (!confirmStart) {
    return;
  }

  try {
    showTrialResult(t('license_trial_sending'), 'info');

    const result = await window.electronAPI.licensing.requestLicense({
      plan: 'trial',
      email: null,
    });

    if (result.success) {
      showTrialResult(t('license_trial_success').replace('{message}', result.message), 'success');
    } else {
      showTrialResult(t('license_trial_error').replace('{message}', result.message), 'error');
    }
  } catch (error) {
    console.error('[License UI] Trial request failed:', error);
    showTrialResult(t('license_trial_error').replace('{message}', error.message), 'error');
  }
};

/**
 * Показывает результат запроса Trial
 */
function showTrialResult(message, type) {
  const resultEl = document.getElementById('trialResult');
  if (!resultEl) return;

  resultEl.textContent = message;
  resultEl.style.display = 'block';

  if (type === 'success') {
    resultEl.style.background = 'rgba(76, 175, 80, 0.2)';
    resultEl.style.borderColor = 'rgba(76, 175, 80, 0.5)';
    resultEl.style.color = '#4caf50';
  } else if (type === 'error') {
    resultEl.style.background = 'rgba(255, 107, 107, 0.2)';
    resultEl.style.borderColor = 'rgba(255, 107, 107, 0.5)';
    resultEl.style.color = '#ff6b6b';
  } else {
    resultEl.style.background = 'rgba(0, 212, 255, 0.2)';
    resultEl.style.borderColor = 'rgba(0, 212, 255, 0.5)';
    resultEl.style.color = '#00d4ff';
  }

  resultEl.style.border = '1px solid';
}

// ============================================================================
// АКТИВАЦИЯ ЛИЦЕНЗИИ
// ============================================================================

/**
 * Активирует лицензионный ключ
 */
window.activateLicenseKey = async function () {
  const keyInput = document.getElementById('licenseKeyInput');
  const resultEl = document.getElementById('activationResult');

  if (!keyInput || !resultEl) return;

  const key = keyInput.value.trim().toUpperCase();

  if (!key) {
    showActivationResult('❌ Введите лицензионный ключ', 'error');
    return;
  }

  if (!key.startsWith('3DCP-')) {
    showActivationResult('❌ Неверный формат ключа. Ключ должен начинаться с 3DCP-', 'error');
    return;
  }

  try {
    showActivationResult('⏳ Активация лицензии...', 'info');

    const result = await window.electronAPI.licensing.activateLicense(key);

    if (result.success) {
      showActivationResult('✅ ' + result.message, 'success');
      keyInput.value = '';

      // Обновляем статус лицензии
      await updateLicenseStatusUI();

      // ТРИГГЕР: проверяем соответствие количества принтеров лимиту
      if (window.checkLicenseOnStartup) {
        await window.checkLicenseOnStartup();
      }

      // Перезагружаем страницу через 2 секунды
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } else {
      showActivationResult('❌ ' + result.message, 'error');
    }
  } catch (error) {
    console.error('[License UI] Activation failed:', error);
    showActivationResult('❌ Ошибка активации: ' + error.message, 'error');
  }
};

/**
 * Показывает результат активации
 */
function showActivationResult(message, type) {
  const resultEl = document.getElementById('activationResult');
  if (!resultEl) return;

  resultEl.textContent = message;
  resultEl.style.display = 'block';

  if (type === 'success') {
    resultEl.style.background = 'rgba(76, 175, 80, 0.2)';
    resultEl.style.borderColor = 'rgba(76, 175, 80, 0.5)';
    resultEl.style.color = '#4caf50';
  } else if (type === 'error') {
    resultEl.style.background = 'rgba(255, 107, 107, 0.2)';
    resultEl.style.borderColor = 'rgba(255, 107, 107, 0.5)';
    resultEl.style.color = '#ff6b6b';
  } else {
    resultEl.style.background = 'rgba(0, 212, 255, 0.2)';
    resultEl.style.borderColor = 'rgba(0, 212, 255, 0.5)';
    resultEl.style.color = '#00d4ff';
  }

  resultEl.style.border = '1px solid';
}

/**
 * Обработка вставки лицензионного ключа
 */
window.handleLicenseKeyPaste = function (event) {
  // Получаем данные из буфера обмена
  const pastedData = (event.clipboardData || window.clipboardData).getData('text');

  // Нормализуем данные (убираем пробелы, приводим к верхнему регистру)
  const normalizedKey = pastedData.trim().toUpperCase();

  // Проверяем формат ключа (поддерживаем 4 и 8-символьные группы)
  const keyPattern4 = /^3DCP-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
  const keyPattern8 = /^3DCP-[A-Z0-9]{8}-[A-Z0-9]{8}-[A-Z0-9]{8}-[A-Z0-9]{8}-[A-Z0-9]{8}$/;

  if (keyPattern4.test(normalizedKey) || keyPattern8.test(normalizedKey)) {
    // Ключ валидный - вставляем нормализованную версию
    event.preventDefault();
    const input = event.target;
    input.value = normalizedKey;

    // Показываем уведомление об успешной вставке
    showPasteNotification('✅ Ключ вставлен и проверен', 'success');
  } else {
    // Ключ невалидный - показываем предупреждение, но разрешаем вставку
    showPasteNotification('⚠️ Неверный формат ключа. Проверьте правильность.', 'warning');
  }
};

/**
 * Показывает уведомление о вставке
 */
function showPasteNotification(message, type) {
  // Создаем элемент уведомления
  const notification = document.createElement('div');
  notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 6px;
        color: white;
        font-size: 14px;
        font-weight: 500;
        z-index: 10000;
        max-width: 300px;
        word-wrap: break-word;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        transition: opacity 0.3s ease;
    `;

  if (type === 'success') {
    notification.style.background = 'linear-gradient(135deg, #4caf50, #45a049)';
  } else if (type === 'warning') {
    notification.style.background = 'linear-gradient(135deg, #ff9800, #f57c00)';
  } else {
    notification.style.background = 'linear-gradient(135deg, #2196f3, #1976d2)';
  }

  notification.textContent = message;
  document.body.appendChild(notification);

  // Удаляем уведомление через 3 секунды
  setTimeout(() => {
    notification.style.opacity = '0';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 3000);
}

console.log('[License UI] Functions loaded');
