@echo off
chcp 65001 >nul
echo.
echo ========================================
echo   3D Printer Control Panel v1.6.51
echo   Data Cleanup Utility
echo ========================================
echo.
echo This utility will clear all application data and reset to defaults.
echo A backup will be created before clearing data.
echo.
echo WARNING: This will remove all your printer configurations!
echo.
set /p confirm="Are you sure you want to continue? (y/N): "
if /i not "%confirm%"=="y" (
    echo Operation cancelled.
    pause
    exit /b 0
)

echo.
echo Starting data cleanup...
echo.

REM Find the application data directory
set "APPDATA_PATH=%APPDATA%\3d-printer-control-panel"
if not exist "%APPDATA_PATH%" (
    echo Application data directory not found.
    echo The application may not have been run yet.
    pause
    exit /b 0
)

REM Create backup
set "BACKUP_PATH=%APPDATA_PATH%-backup-%date:~-4,4%%date:~-10,2%%date:~-7,2%-%time:~0,2%%time:~3,2%%time:~6,2%"
set "BACKUP_PATH=%BACKUP_PATH: =0%"

echo Creating backup at: %BACKUP_PATH%
xcopy "%APPDATA_PATH%" "%BACKUP_PATH%" /E /I /H /Y >nul 2>&1
if %errorlevel% equ 0 (
    echo ✅ Backup created successfully
) else (
    echo ⚠️ Backup creation failed, but continuing...
)

echo.
echo Clearing application data...
rmdir /s /q "%APPDATA_PATH%" 2>nul
if %errorlevel% equ 0 (
    echo ✅ Application data cleared
) else (
    echo ⚠️ Some files may not have been cleared
)

echo.
echo ========================================
echo   Data cleanup completed!
echo ========================================
echo.
echo Backup location: %BACKUP_PATH%
echo.
echo You can now start the application with fresh data.
echo If you need to restore your data, copy the backup back to:
echo %APPDATA_PATH%
echo.
pause
